<?php 
session_start();
include '0.1_dbconnect.php';

$user_role = $_SESSION['com_role'] ?? ''; 
ini_set('display_errors', 1);
error_reporting(E_ALL);

/* ================= 1. LOGIK PENAPISAN (FILTER) ================= */
$selected_month = isset($_GET['month']) ? $_GET['month'] : '';
$selected_year = isset($_GET['year']) ? $_GET['year'] : date('Y');

// Bina klausa WHERE untuk SQL
$where_clauses = [];
if (!empty($selected_month)) {
    $where_clauses[] = "MONTH(prog_rep_submitted) = '$selected_month'";
}
if (!empty($selected_year)) {
    $where_clauses[] = "YEAR(prog_rep_submitted) = '$selected_year'";
}
$where_sql = count($where_clauses) > 0 ? "WHERE " . implode(' AND ', $where_clauses) : "";

/* ================= 2. PENGIRAAN KPI CARDS (DITAPIS) ================= */
$kpi_query = mysqli_query($conn, "
    SELECT 
        SUM(prog_act_income) as total_penerimaan, 
        SUM(prog_act_expenses) as total_pembelanjaan 
    FROM programme_report
    $where_sql
");
$kpi = mysqli_fetch_assoc($kpi_query);
$total_penerimaan = $kpi['total_penerimaan'] ?: 0;
$total_pembelanjaan = $kpi['total_pembelanjaan'] ?: 0;
$total_untung = $total_penerimaan - $total_pembelanjaan;

/* ================= 3. DATA GRAF (DITAPIS) ================= */
$prog_names = []; $budget_amt = []; $actual_amt = [];
$q_comparison = mysqli_query($conn, "
    SELECT pr.proposal_id, pr.prog_name, 
           (SELECT SUM(income_amt) FROM programme_budget WHERE proposal_id = pr.proposal_id) as bajet,
           pr.prog_act_expenses as sebenar
    FROM programme_report pr
    $where_sql
    LIMIT 10
");
while($r = mysqli_fetch_assoc($q_comparison)) {
    $prog_names[] = $r['prog_name'];
    $budget_amt[] = $r['bajet'] ?: 0;
    $actual_amt[] = $r['sebenar'] ?: 0;
}

// Data Untung Tertinggi
$q_top_profit = mysqli_query($conn, "SELECT prog_name, (prog_act_income - prog_act_expenses) as untung FROM programme_report $where_sql ORDER BY untung DESC LIMIT 5");
$profit_labels = []; $profit_values = [];
while($r = mysqli_fetch_assoc($q_top_profit)) { $profit_labels[] = $r['prog_name']; $profit_values[] = $r['untung']; }

// Data Belanja Tertinggi
$q_top_exp = mysqli_query($conn, "SELECT prog_name, prog_act_expenses FROM programme_report $where_sql ORDER BY prog_act_expenses DESC LIMIT 5");
$exp_labels = []; $exp_values = [];
while($r = mysqli_fetch_assoc($q_top_exp)) { $exp_labels[] = $r['prog_name']; $exp_values[] = $r['prog_act_expenses']; }
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>Analisis Kewangan</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root { --primary: #0061f2; --success: #10b981; --danger: #ef4444; }
        body { font-family: 'Segoe UI', sans-serif; background: #f0f2f5; margin: 0; }
        .main-content { margin-left: 260px; padding: 100px 30px 30px 30px; transition: all 0.3s ease; }
        .glass-card { background: white; padding: 25px; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); margin-bottom: 25px; }
        
        /* Filter Styling */
        .filter-section { display: flex; gap: 15px; margin-bottom: 25px; align-items: flex-end; background: white; padding: 20px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .filter-group { display: flex; flex-direction: column; gap: 5px; }
        .filter-group label { font-size: 0.85rem; font-weight: 600; color: #64748b; }
        .filter-group select { padding: 8px 12px; border-radius: 6px; border: 1px solid #ddd; outline: none; min-width: 150px; }
        .btn-filter { background: var(--primary); color: white; border: none; padding: 9px 20px; border-radius: 6px; cursor: pointer; font-weight: 600; transition: 0.2s; }
        .btn-filter:hover { opacity: 0.9; }

        .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 20px; border-radius: 12px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); border-left: 5px solid; }
        .chart-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px; }
        .chart-container { position: relative; height: 350px; background: white; padding: 15px; border-radius: 12px; border: 1px solid #eee; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 0.9rem; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8fafc; color: #64748b; }
    </style>
</head>
<body id="body-layout">

<?php 
if ($user_role === 'Village Head') { include '0.2_ketua_navbar.php'; } 
else { include '0.3_committee_navbar.php'; } 
?>

<div class="main-content">
    <div class="glass-card">
        <h2><i class='bx bx-money-withdraw'></i> Analisis Kewangan Program</h2>
        
        <form method="GET" class="filter-section">
            <div class="filter-group">
                <label>Bulan</label>
                <select name="month">
                    <option value="">Semua Bulan</option>
                    <?php
                    $months = ["Januari", "Februari", "Mac", "April", "Mei", "Jun", "Julai", "Ogos", "September", "Oktober", "November", "Disember"];
                    foreach($months as $index => $m) {
                        $val = $index + 1;
                        $sel = ($selected_month == $val) ? 'selected' : '';
                        echo "<option value='$val' $sel>$m</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="filter-group">
                <label>Tahun</label>
                <select name="year">
                    <?php
                    $currentYear = date('Y');
                    for($y = $currentYear; $y >= $currentYear - 5; $y--) {
                        $sel = ($selected_year == $y) ? 'selected' : '';
                        echo "<option value='$y' $sel>$y</option>";
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn-filter"><i class='bx bx-filter-alt'></i> Tapis Data</button>
            <a href="financial_analysis.php" style="text-decoration:none; color:#64748b; font-size:0.85rem; padding-bottom:10px;">Reset</a>
        </form>

        <div class="stats-grid">
            <div class="stat-card" style="border-left-color: var(--success);">
                <div style="font-size:0.8rem; color:#64748b;">TOTAL PENERIMAAN</div>
                <div style="font-size:1.6rem; font-weight:700;">RM <?= number_format((float)$total_penerimaan, 2) ?></div>
            </div>
            <div class="stat-card" style="border-left-color: var(--danger);">
                <div style="font-size:0.8rem; color:#64748b;">TOTAL PEMBELANJAAN</div>
                <div style="font-size:1.6rem; font-weight:700;">RM <?= number_format((float)$total_pembelanjaan, 2) ?></div>
            </div>
            <div class="stat-card" style="border-left-color: var(--primary);">
                <div style="font-size:0.8rem; color:#64748b;">JUMLAH UNTUNG</div>
                <div style="font-size:1.6rem; font-weight:700;">RM <?= number_format((float)$total_untung, 2) ?></div>
            </div>
        </div>

        <div class="chart-container" style="height:400px; margin-bottom:25px;">
            <canvas id="budgetActualChart"></canvas>
        </div>

        <div class="chart-grid">
            <div class="chart-container"><canvas id="profitChart"></canvas></div>
            <div class="chart-container"><canvas id="expenseChart"></canvas></div>
        </div>
    </div>
</div>

<script>
// Logic Chart.js dikekalkan sama...
Chart.defaults.responsive = true;
Chart.defaults.maintainAspectRatio = false;

new Chart(document.getElementById('budgetActualChart'), {
    type: 'bar',
    data: {
        labels: <?= json_encode($prog_names) ?>,
        datasets: [
            { label: 'Bajet', data: <?= json_encode($budget_amt) ?>, backgroundColor: '#cbd5e1' },
            { label: 'Belanja Sebenar', data: <?= json_encode($actual_amt) ?>, backgroundColor: '#0061f2' }
        ]
    },
    options: { plugins: { title: { display: true, text: 'Bajet vs Perbelanjaan Sebenar' } } }
});

new Chart(document.getElementById('profitChart'), {
    type: 'bar',
    data: {
        labels: <?= json_encode($profit_labels) ?>,
        datasets: [{ label: 'Untung (RM)', data: <?= json_encode($profit_values) ?>, backgroundColor: '#10b981' }]
    },
    options: { indexAxis: 'y', plugins: { title: { display: true, text: 'Program Paling Menguntungkan' } } }
});

new Chart(document.getElementById('expenseChart'), {
    type: 'bar',
    data: {
        labels: <?= json_encode($exp_labels) ?>,
        datasets: [{ label: 'Belanja (RM)', data: <?= json_encode($exp_values) ?>, backgroundColor: '#ef4444' }]
    },
    options: { indexAxis: 'y', plugins: { title: { display: true, text: 'Program Paling Berbelanja' } } }
});
</script>
</body>
</html>