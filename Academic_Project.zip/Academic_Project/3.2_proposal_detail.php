<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

include '0.1_dbconnect.php';

// 1. Get proposal_id
$id = $_GET['id'] ?? 0;
if ($id == 0) die("ID Kertas Kerja tidak sah");

// 2. Get main proposal data
$result = $conn->query("SELECT * FROM programme_proposal WHERE proposal_id = $id");
if (!$result || $result->num_rows == 0) die("Kertas kerja tidak dijumpai");

$p = $result->fetch_assoc();

$category_map = [
    'Education' => 'Pendidikan',
    'Religious' => 'Keagamaan',
    'Corporate Social Responsibility' => 'Tanggungjawab Sosial Korporat',
    'Entrepreneurship' => 'Keusahawanan'
];

$category_bm = $category_map[$p['prog_category']] ?? $p['prog_category'];

// 3. Fetch budget items
$income_items = [];
$expense_items = [];
$budget_query = "SELECT * FROM programme_budget WHERE proposal_id = $id";
$budget_result = $conn->query($budget_query);

if ($budget_result) {
    while ($row = $budget_result->fetch_assoc()) {
        if (!empty($row['income_name'])) $income_items[] = $row;
        if (!empty($row['expense_name'])) $expense_items[] = $row;
    }
}

// 4. Fetch Collaborators
$collab_list = [];
$collab_query = "
    SELECT c.coll_organisation_name FROM collaboratorsproposal pc
    JOIN collaborators c ON pc.coll_id = c.coll_id
    WHERE pc.proposal_id = $id
";
$collab_result = $conn->query($collab_query);
if ($collab_result) {
    while ($row = $collab_result->fetch_assoc()) { $collab_list[] = $row; }
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>Butiran Kertas Kerja | Sistem Kampung</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: var(--text-dark);
            margin: 0;
        }

        .main-content {
            margin-left: 260px;
            padding: 40px;
            padding-top: 110px;
            transition: all 0.3s ease;
        }

        #mySidebar.collapsed ~ .main-content { margin-left: 0; }

        .container {
            max-width: 1000px;
            margin: auto;
        }

        /* Glass Card */
        .glass-card {
            background: var(--glass-bg);
            padding: 40px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid var(--border-color);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        h2, h3 { color: var(--primary-blue); display: flex; align-items: center; gap: 10px; }
        h2 { font-size: 1.8rem; margin-bottom: 25px; }
        h3 { font-size: 1.3rem; margin-top: 30px; border-bottom: 2px solid #e2e8f0; padding-bottom: 10px; }

        /* Status Badges */
        .status-badge {
            display: inline-block;
            padding: 6px 16px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 0.85rem;
            text-transform: uppercase;
        }
        .status-pending { background: #fff4e6; color: #f6ad55; border: 1px solid #fbd38d; }
        .status-approved { background: #f0fff4; color: #68d391; border: 1px solid #c6f6d5; }
        .status-rejected { background: #fff5f5; color: #fc8181; border: 1px solid #fed7d7; }
        .status-draft { background: #edf2f7; color: #718096; border: 1px solid #e2e8f0; }

        /* Grid Info */
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-top: 20px;
        }

        .info-group { display: flex; flex-direction: column; gap: 5px; }
        .info-group.full { grid-column: span 2; }
        .info-group label { font-weight: 700; color: #4a5568; font-size: 0.9rem; }
        .info-value {
            padding: 12px;
            background: rgba(255,255,255,0.5);
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            min-height: 45px;
        }

        /* Table Styling */
        .table-wrapper { overflow-x: auto; margin-top: 15px; }
        table { width: 100%; border-collapse: collapse; background: white; border-radius: 10px; overflow: hidden; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #edf2f7; }
        th { background: #f8fafc; color: var(--primary-blue); font-weight: 700; }

        /* File Link */
        .file-box {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 15px;
            background: #f0f7ff;
            border-radius: 12px;
            border: 1px dashed var(--primary-blue);
            margin-top: 10px;
        }
        .file-box a { color: var(--primary-blue); text-decoration: none; font-weight: 600; }
        .file-box a:hover { text-decoration: underline; }

        @media (max-width: 768px) {
            .main-content { margin-left: 0; padding: 20px; padding-top: 100px; }
            .info-grid { grid-template-columns: 1fr; }
            .info-group.full { grid-column: span 1; }
        }
    </style>
</head>
<body>

<?php
if (isset($_SESSION['com_role'])) {
    if ($_SESSION['com_role'] === 'Village Head') { include '0.2_ketua_navbar.php'; } 
    else { include '0.3_committee_navbar.php'; }
} else { die('Unauthorized access'); }

// Assigning dynamic status class
$status = $p['prog_status'];
$status_class = 'status-draft';
if ($status === 'Pending') $status_class = 'status-pending';
if ($status === 'Approved') $status_class = 'status-approved';
if ($status === 'Rejected' || $status === 'Returned') $status_class = 'status-rejected';
?>

<div class="main-content">
    <div class="container">
        
        <div class="glass-card">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 30px;">
                <h2><i class='bx bx-file-find'></i> Butiran Kertas Kerja</h2>
                <span class="status-badge <?= $status_class ?>"><?= htmlspecialchars($status) ?></span>
            </div>

            <div class="info-grid">
                <div class="info-group full">
                    <label>Tajuk Program</label>
                    <div class="info-value"><strong><?= htmlspecialchars($p['prog_name']) ?></strong></div>
                </div>

                <div class="info-group full">
                    <label>Objektif Program</label>
                    <div class="info-value" style="white-space: pre-wrap;"><?= htmlspecialchars($p['prog_objectives']) ?></div>
                </div>

                <div class="info-group">
                    <label>Kategori</label>
                    <div class="info-value"><?= htmlspecialchars($category_bm) ?></div>
                </div>

                <div class="info-group">
                    <label>Lokasi (Venue)</label>
                    <div class="info-value"><?= htmlspecialchars($p['prog_venue']) ?></div>
                </div>

                <div class="info-group">
                    <label>Tarikh Program</label>
                    <div class="info-value"><i class='bx bx-calendar'></i> <?= date('d/m/Y', strtotime($p['prog_date'])) ?></div>
                </div>

                <div class="info-group">
                    <label>Masa</label>
                    <div class="info-value"><i class='bx bx-time'></i> <?= date('h:i A', strtotime($p['prog_time'])) ?></div>
                </div>

                <div class="info-group">
                    <label>Anggaran Peserta</label>
                    <div class="info-value"><?= htmlspecialchars($p['prog_est_participants']) ?> Orang</div>
                </div>

                <div class="info-group">
                    <label>Dokumen Sokongan</label>
                    <?php if (!empty($p['prog_docs'])): ?>
                        <div class="file-box">
                            <i class='bx bxs-file-pdf' style="font-size: 1.5rem;"></i>
                            <a href="<?= $p['prog_docs'] ?>" target="_blank">Buka Dokumen Lampiran</a>
                        </div>
                    <?php else: ?>
                        <div class="info-value" style="color: #a0aec0;">Tiada dokumen dimuat naik.</div>
                    <?php endif; ?>
                </div>
            </div>

            <h3><i class='bx bx-money'></i> Ringkasan Bajet</h3>
            
            <div class="info-grid">
                <div class="info-group">
                    <label>Sumber Pendapatan</label>
                    <div class="table-wrapper">
                        <table>
                            <thead><tr><th>Item</th><th>Jumlah (RM)</th></tr></thead>
                            <tbody>
                                <?php if (!empty($income_items)): foreach ($income_items as $item): ?>
                                    <tr><td><?= htmlspecialchars($item['income_name']) ?></td><td><?= number_format($item['income_amt'], 2) ?></td></tr>
                                <?php endforeach; else: ?>
                                    <tr><td colspan="2" style="text-align:center;">Tiada data</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="info-group">
                    <label>Anggaran Perbelanjaan</label>
                    <div class="table-wrapper">
                        <table>
                            <thead><tr><th>Item</th><th>Jumlah (RM)</th></tr></thead>
                            <tbody>
                                <?php if (!empty($expense_items)): foreach ($expense_items as $item): ?>
                                    <tr><td><?= htmlspecialchars($item['expense_name']) ?></td><td><?= number_format($item['expense_amt'], 2) ?></td></tr>
                                <?php endforeach; else: ?>
                                    <tr><td colspan="2" style="text-align:center;">Tiada data</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <h3><i class='bx bx-group'></i> Rakan Kolaborasi</h3>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th width="50">No.</th><th>Nama Organisasi</th></tr></thead>
                    <tbody>
                        <?php if (!empty($collab_list)): foreach ($collab_list as $index => $c): ?>
                            <tr><td><?= $index + 1 ?>.</td><td><?= htmlspecialchars($c['coll_organisation_name']) ?></td></tr>
                        <?php endforeach; else: ?>
                            <tr><td colspan="2" style="text-align:center;">Tiada rakan kolaborasi direkod.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div style="margin-top: 40px; text-align: center;">
    <a href="5.0_programme_list.php" class="btn-update" style="display: inline-block; text-decoration: none; background: #e2e8f0; color: #4a5568; padding: 12px 25px; border-radius: 10px; cursor: pointer; border: none; font-weight: 600;">
        <i class='bx bx-arrow-back'></i> Kembali ke Senarai
    </a>
</div>

        </div>
    </div>
</div>

</body>
</html>