<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '0.1_dbconnect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Invalid request.");
}

$proposal_id = intval($_POST['proposal_id']);
$com_id      = $_SESSION['com_id'];

$prog_name    = $_POST['prog_name'];
$summary      = $_POST['prog_summary'];
$improvement  = $_POST['prog_improvement'];
$participants = $_POST['prog_act_participants'];
$income       = $_POST['prog_act_income'];
$expenses     = $_POST['prog_act_expenses'];

/* ✅ Report status */
$report_status = "Pending";

/* Handle file upload */
$doc_path = null;
if (!empty($_FILES['prog_rep_docs']['name'])) {
    $folder = "uploads/reports/";
    if (!is_dir($folder)) {
        mkdir($folder, 0777, true);
    }

    $doc_path = $folder . time() . "_" . basename($_FILES['prog_rep_docs']['name']);
    move_uploaded_file($_FILES['prog_rep_docs']['tmp_name'], $doc_path);
}

/* ✅ Insert report with status */
$sql = "INSERT INTO programme_report (
            proposal_id,
            com_id,
            prog_name,
            prog_summary,
            prog_improvement,
            prog_act_participants,
            prog_act_income,
            prog_act_expenses,
            prog_rep_docs,
            prog_rep_status,
            prog_rep_submitted
        ) VALUES (
            '$proposal_id',
            '$com_id',
            '$prog_name',
            '$summary',
            '$improvement',
            '$participants',
            '$income',
            '$expenses',
            " . ($doc_path ? "'$doc_path'" : "NULL") . ",
            '$report_status',
            NOW()
        )";

if (!$conn->query($sql)) {
    die("Error saving report: " . $conn->error);
}

/* ✅ Get newly created report_id */
$report_id = $conn->insert_id;

/* ✅ Redirect to actual budget (REPORT-based, correct design) */
header("Location: 7.3_budget_report.php?report_id=$report_id");
exit();
