<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require_once "0.1_dbconnect.php";

// Logik Toggle Status
if (isset($_POST['toggle_status'])) {
    $com_id = (int)$_POST['com_id'];
    $current_status = $_POST['current_status'];
    $new_status = ($current_status === 'Active') ? 'Inactive' : 'Active';

    $update_sql = "UPDATE committee SET com_status = ? WHERE com_id = ?";
    $stmt = mysqli_prepare($conn, $update_sql);
    mysqli_stmt_bind_param($stmt, "si", $new_status, $com_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Ambil Data
$sql = "SELECT com_id, com_name, com_gender, com_phone, com_role, com_position, 
               com_email, com_dob, com_address, com_username, com_status, 
               com_passwordstatus, com_date_created 
        FROM committee 
        WHERE com_id != 1 
        ORDER BY com_date_created DESC";

$result = mysqli_query($conn, $sql);
$total_members = mysqli_num_rows($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Committee Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary: #4f46e5;
            --success: #22c55e;
            --danger: #ef4444;
            --bg-body: #f8fafc;
            --text-dark: #1e293b;
            --text-light: #64748b;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-body);
            margin: 0;
            color: var(--text-dark);
        }

        .main-content {
            margin-left: 260px; /* Laraskan mengikut lebar navbar anda */
            padding: 40px;
            transition: all 0.3s;
        }

        /* Header Styles */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .page-header h2 {
            margin: 0;
            font-weight: 700;
            color: var(--text-dark);
            letter-spacing: -0.5px;
        }

        /* Stats Card */
        .stats-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            display: inline-flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 25px;
        }

        .stats-icon {
            background: #eef2ff;
            color: var(--primary);
            width: 45px;
            height: 45px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        /* Table Container */
        .table-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        th {
            background-color: #f1f5f9;
            padding: 15px 20px;
            font-size: 12px;
            text-transform: uppercase;
            font-weight: 600;
            color: var(--text-light);
            border-bottom: 1px solid #e2e8f0;
        }

        td {
            padding: 16px 20px;
            font-size: 14px;
            border-bottom: 1px solid #f1f5f9;
            color: var(--text-dark);
            vertical-align: middle;
        }

        tr:hover {
            background-color: #f8fafc;
        }

        /* Badge Status Styles */
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: transform 0.2s, opacity 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .status-badge:hover {
            transform: translateY(-1px);
            opacity: 0.9;
        }

        .status-active {
            background-color: #dcfce7;
            color: #166534;
        }

        .status-inactive {
            background-color: #fee2e2;
            color: #991b1b;
        }

        /* Utility Styles */
        .text-bold { font-weight: 600; }
        .text-muted { color: var(--text-light); font-size: 12px; }
        
        .empty-state {
            padding: 40px;
            text-align: center;
            color: var(--text-light);
        }
    </style>
</head>
<body>

<?php
if ($_SESSION['com_role'] === 'Village Head') {
    include '0.2_ketua_navbar.php';
} else {
    include '0.3_committee_navbar.php';
}
?>

<div class="main-content">
    <div class="page-header">
        <div>
            <h2>Senarai Jawatankuasa</h2>
            <p style="color: var(--text-light); margin-top: 5px;">Urus maklumat dan status keahlian jawatankuasa kampung.</p>
        </div>
    </div>

    <div class="stats-card">
        <div class="stats-icon"><i class="fas fa-users"></i></div>
        <div>
            <div style="font-size: 13px; color: var(--text-light);">Jumlah Ahli</div>
            <div style="font-size: 20px; font-weight: 700;"><?php echo $total_members; ?> Orang</div>
        </div>
    </div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Ahli Jawatankuasa</th>
                    <th>Hubungi & Peranan</th>
                    <th>Maklumat Peribadi</th>
                    <th>Status Akaun</th>
                    <th>Tarikh Daftar</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result && mysqli_num_rows($result) > 0) { ?>
                    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                        <tr>
                            <td>
                                <div class="text-bold"><?php echo htmlspecialchars($row['com_name']); ?></div>
                                <div class="text-muted">@<?php echo htmlspecialchars($row['com_username']); ?> (ID: <?php echo $row['com_id']; ?>)</div>
                            </td>

                            <td>
                                <div><i class="fas fa-user-tag" style="width: 20px; color: var(--primary);"></i> <?php echo htmlspecialchars($row['com_role']); ?></div>
                                <div style="font-size: 13px; color: var(--text-light);"><?php echo htmlspecialchars($row['com_position']); ?></div>
                                <div style="margin-top: 5px;"><i class="fas fa-phone" style="width: 20px; color: var(--success);"></i> <?php echo htmlspecialchars($row['com_phone']); ?></div>
                            </td>

                            <td>
                                <div style="font-size: 13px;"><i class="fas fa-envelope" style="width: 20px;"></i> <?php echo htmlspecialchars($row['com_email']); ?></div>
                                <div style="font-size: 13px; margin-top: 4px;"><i class="fas fa-map-marker-alt" style="width: 20px;"></i> <?php echo htmlspecialchars($row['com_address']); ?></div>
                                <div class="text-muted" style="margin-top: 4px; padding-left: 20px;">Jantina: <?php echo htmlspecialchars($row['com_gender']); ?></div>
                            </td>

                            <td>
                                <form method="POST" style="margin-bottom: 8px;">
                                    <input type="hidden" name="com_id" value="<?= $row['com_id']; ?>">
                                    <input type="hidden" name="current_status" value="<?= $row['com_status']; ?>">
                                    <button type="submit" name="toggle_status" 
                                            class="status-badge <?= $row['com_status'] === 'Active' ? 'status-active' : 'status-inactive'; ?>">
                                        <i class="fas <?= $row['com_status'] === 'Active' ? 'fa-check-circle' : 'fa-times-circle'; ?>"></i>
                                        <?= strtoupper($row['com_status']); ?>
                                    </button>
                                </form>
                                <div class="text-muted">Katalaluan: <?php echo htmlspecialchars($row['com_passwordstatus']); ?></div>
                            </td>

                            <td class="text-muted">
                                <i class="far fa-calendar-alt"></i> <?php echo date('d M Y', strtotime($row['com_date_created'])); ?>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } else { ?>
                    <tr>
                        <td colspan="5" class="empty-state">
                            <i class="fas fa-folder-open fa-3x" style="display:block; margin-bottom: 15px; opacity: 0.3;"></i>
                            Tiada rekod jawatankuasa dijumpai.
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>