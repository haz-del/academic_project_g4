<!DOCTYPE html>
<html>
<head>
<title>My Activities</title>
</head>
<body>

<?php include '0.4_guest_navbar.php'; ?>

<div class="content">
<h2>My Activity List</h2>
<table border="1" width="100%">
<tr><th>No</th><th>Title</th><th>Implementation Date</th><th>Submission Date</th><th>Status</th></tr>
<tr><td>1</td><td>Clean Village</td><td>2024-01-02</td><td>2023-12-30</td><td>Pending</td></tr>
<tr><td>2</td><td>Tree Planting</td><td>2024-02-15</td><td>2024-02-01</td><td>Approved</td></tr>
</table>
</div>

</body>
</html>



