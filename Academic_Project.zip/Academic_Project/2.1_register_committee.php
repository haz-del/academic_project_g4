<?php 
session_start();
include "0.1_dbconnect.php";

// Pastikan hanya pengguna log masuk boleh akses
if (!isset($_SESSION['com_id'])) {
    header("Location: 2.0_login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Pengurusan | Pendaftaran AJK</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.95);
            --text-main: #2c3e50;
        }

        body { 
            font-family: 'Inter', sans-serif; 
            background: url('uploads/Bg/Background.jpg') no-repeat center center fixed; 
            background-size: cover;
            margin: 0;
        }

        .main-content { 
            margin-left: 260px; 
            padding: 40px; 
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: flex-start;
        }

        .container { 
            background: var(--glass-bg); 
            width: 100%; 
            max-width: 850px; 
            padding: 40px; 
            border-radius: 20px; 
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            backdrop-filter: blur(10px);
        }

        h2 { 
            color: var(--primary-blue); 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            margin-top: 0;
            border-bottom: 2px solid #eee;
            padding-bottom: 15px;
        }

        .form-grid { 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 20px; 
            margin-top: 20px; 
        }

        .input-box { margin-bottom: 15px; }
        .input-box label { 
            display: block; 
            font-weight: 600; 
            margin-bottom: 8px; 
            font-size: 0.9rem;
            color: var(--text-main);
        }

        .input-box input, .input-box select { 
            width: 100%; 
            padding: 12px; 
            border: 1px solid #dcdde1; 
            border-radius: 10px; 
            box-sizing: border-box;
            transition: 0.3s;
        }

        .input-box input:focus { border-color: var(--primary-blue); outline: none; }

        .full-width { grid-column: span 2; }

        .pwd-wrapper { position: relative; display: flex; align-items: center; }
        .toggle-pwd { 
            position: absolute; 
            right: 15px; 
            cursor: pointer; 
            color: #7f8c8d; 
            font-size: 1.2rem;
        }

        .alert { padding: 15px; border-radius: 10px; margin-bottom: 25px; font-weight: 500; text-align: center; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }

        .btn-submit { 
            background: var(--primary-blue); 
            color: white; 
            padding: 15px 30px; 
            border: none; 
            border-radius: 10px; 
            width: 100%; 
            font-size: 1rem; 
            font-weight: 700; 
            cursor: pointer; 
            margin-top: 10px;
            transition: 0.3s;
        }

        .btn-submit:hover { background: #004dc2; transform: translateY(-2px); }

        @media (max-width: 768px) {
            .main-content { margin-left: 0; padding: 20px; }
            .form-grid { grid-template-columns: 1fr; }
            .full-width { grid-column: span 1; }
        }
    </style>
</head>
<body>

    <?php include '0.2_ketua_navbar.php'; ?>

    <div class="main-content">
        <div class="container">
            <h2><i class='bx bx-user-plus'></i> Pendaftaran AJK Baharu</h2>

            <?php
            if (isset($_POST['submit'])){
                // Sanitasi Input
                $cname     = mysqli_real_escape_string($conn, $_POST['cn']);
                $cphone    = mysqli_real_escape_string($conn, $_POST['cp']);
                $cmail     = mysqli_real_escape_string($conn, $_POST['ce']);
                $cgender   = $_POST['cg'];
                $cbirth    = $_POST['cbd'];
                $caddress  = mysqli_real_escape_string($conn, $_POST['cadd']);
                $crole     = $_POST['cr'];
                $cposition = mysqli_real_escape_string($conn, $_POST['cpo']);
                $cusername = mysqli_real_escape_string($conn, $_POST['cun']);
                $cpassword = password_hash($_POST['cpw'], PASSWORD_DEFAULT);
                $creator   = $_SESSION['com_id']; // ID Ketua Kampung (cth: 12)

                // Semakan Duplikasi No Telefon / Username
                $check = mysqli_query($conn, "SELECT * FROM committee WHERE com_username='$cusername' OR com_phone='$cphone'");
                
                if (mysqli_num_rows($check) > 0) {
                    echo "<div class='alert error'><i class='bx bx-error-circle'></i> Ralat: Nama Pengguna atau No. Telefon sudah didaftarkan!</div>";
                } else {
                    // SQL Insert berdasarkan ERD anda
                    $sql = "INSERT INTO committee (com_name, com_gender, com_phone, com_role, com_position, com_email, com_dob, com_address, com_username, com_password, creator_id, com_status, com_passwordstatus, com_date_created) 
                            VALUES ('$cname', '$cgender', '$cphone', '$crole', '$cposition', '$cmail', '$cbirth', '$caddress', '$cusername', '$cpassword', '$creator', 'Active', 'Old', NOW())";
                    
                    if(mysqli_query($conn, $sql)){
                        echo "<div class='alert success'><i class='bx bx-check-double'></i> Tahniah! Akaun AJK berjaya didaftarkan.</div>";
                    } else {
                        echo "<div class='alert error'><i class='bx bx-bug'></i> Ralat Sistem: " . mysqli_error($conn) . "</div>";
                    }
                }
            }
            ?>

            <form action="" method="POST">
                <div class="form-grid">
                    <div class="input-box">
                        <label>Nama Penuh</label>
                        <input type="text" name="cn" required placeholder="Masukkan nama penuh">
                    </div>
                    <div class="input-box">
                        <label>No. Telefon</label>
                        <input type="number" name="cp" required placeholder="Spt: 0123456789">
                    </div>

                    <div class="input-box">
                        <label>Alamat Emel</label>
                        <input type="email" name="ce" required placeholder="nama@emel.com">
                    </div>
                    <div class="input-box">
                        <label>Tarikh Lahir</label>
                        <input type="date" name="cbd" required>
                    </div>

                    <div class="input-box">
                        <label>Jantina</label>
                        <select name="cg">
                            <option value="Male">Lelaki</option>
                            <option value="Female">Perempuan</option>
                        </select>
                    </div>
                    <div class="input-box">
                        <label>Peranan Sistem</label>
                        <select name="cr">
                            <option value="Exco">Exco</option>
                            <option value="Village Head">Ketua Kampung</option>
                        </select>
                    </div>

                    <div class="input-box full-width">
                        <label>Jawatan Dalam Organisasi</label>
                        <input type="text" name="cpo" required placeholder="Spt: Biro Pendidikan / Setiausaha">
                    </div>

                    <div class="input-box full-width">
                        <label>Alamat Tetap</label>
                        <input type="text" name="cadd" required placeholder="Alamat rumah lengkap">
                    </div>

                    <div class="input-box">
                        <label>Nama Pengguna (Username)</label>
                        <input type="text" name="cun" required placeholder="Username unik">
                    </div>
                    <div class="input-box">
                        <label>Kata Laluan Sementara</label>
                        <div class="pwd-wrapper">
                            <input type="password" name="cpw" id="pwdInput" required placeholder="Min 6 aksara">
                            <i class='bx bx-hide toggle-pwd' id="eyeIcon" onclick="togglePassword()"></i>
                        </div>
                    </div>
                </div>

                <button type="submit" name="submit" class="btn-submit">
                    <i class='bx bx-save'></i> Sahkan & Daftar AJK
                </button>
            </form>
        </div>
    </div>

    <script>
        function togglePassword() {
            const pwd = document.getElementById('pwdInput');
            const icon = document.getElementById('eyeIcon');
            if (pwd.type === 'password') {
                pwd.type = 'text';
                icon.classList.replace('bx-hide', 'bx-show');
            } else {
                pwd.type = 'password';
                icon.classList.replace('bx-show', 'bx-hide');
            }
        }
    </script>
</body>
</html>