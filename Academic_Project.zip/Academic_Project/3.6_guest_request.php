<?php
session_start();
require_once "0.1_dbconnect.php";

// Kawalan Akses
if (!isset($_SESSION['guest_id'])) {
    header("Location: 2.0_login_guest.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borang Permohonan Aktiviti | Sistem Kampung</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: var(--text-dark);
        }

        .main-content {
            margin-left: 260px;
            padding: 40px;
            padding-top: 110px;
            transition: all 0.3s ease;
        }

        #mySidebar.collapsed ~ .main-content { margin-left: 0; }

        .container { max-width: 850px; margin: auto; }

        .glass-card {
            background: var(--glass-bg);
            padding: 40px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid var(--border-color);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        h2 {
            font-size: 1.8rem;
            color: var(--primary-blue);
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 5px;
        }

        .subtitle { color: #718096; margin-bottom: 30px; font-size: 0.95rem; }

        /* Form Styling */
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .form-group { display: flex; flex-direction: column; gap: 8px; margin-bottom: 15px; }
        .full-width { grid-column: span 2; }

        label { 
            font-weight: 700; 
            font-size: 0.85rem; 
            color: #4a5568; 
            text-transform: uppercase; 
            letter-spacing: 0.5px;
        }

        input, textarea, select {
            padding: 12px 15px;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            font-size: 1rem;
            transition: 0.3s;
            background: white;
            width: 100%;
            font-family: inherit;
        }

        input:focus, textarea:focus {
            outline: none;
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(0, 97, 242, 0.1);
        }

        textarea { resize: vertical; }

        .btn-submit {
            background: var(--primary-blue);
            color: white;
            padding: 15px;
            border: none;
            border-radius: 12px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
            margin-top: 20px;
            font-size: 1rem;
        }

        .btn-submit:hover { 
            transform: translateY(-2px); 
            box-shadow: 0 5px 15px rgba(0, 97, 242, 0.3); 
            background: #0052cc;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            margin-top: 25px;
            color: #718096;
            text-decoration: none;
            font-weight: 600;
            transition: 0.2s;
        }

        .back-link:hover { color: var(--primary-blue); }

        /* File Upload Styling */
        input[type="file"] {
            padding: 10px;
            background: #f8fafc;
            border: 1px dashed #cbd5e0;
        }

        @media (max-width: 768px) {
            .main-content { margin-left: 0; padding: 20px; padding-top: 100px; }
            .form-grid { grid-template-columns: 1fr; }
            .full-width { grid-column: span 1; }
        }
    </style>
</head>
<body>

<?php include '0.4_guest_navbar.php'; ?>

<div class="main-content">
    <div class="container">
        <div class="glass-card">
            <h2><i class='bx bx-edit-alt'></i> Borang Permohonan Aktiviti</h2>
            <p class="subtitle">Sila lengkapkan maklumat di bawah untuk memohon penganjuran aktiviti di kampung kami.</p>

            <form action="3.7_guest_request_save.php" method="POST" enctype="multipart/form-data">
                <div class="form-grid">
                    
                    <div class="form-group full-width">
                        <label>Nama Aktiviti / Program *</label>
                        <input type="text" name="req_name" placeholder="Contoh: Program Sukaneka Komuniti" required>
                    </div>

                    <div class="form-group full-width">
                        <label>Objektif & Tujuan *</label>
                        <textarea name="req_objectives" rows="4" placeholder="Nyatakan tujuan utama program diadakan..." required></textarea>
                    </div>

                    <div class="form-group">
                        <label>Kategori</label>
                        <select name="req_category">
                            <option value="">Pilih Kategori</option>
                            <option value="Sukan">Sukan & Rekreasi</option>
                            <option value="Pendidikan">Pendidikan</option>
                            <option value="Keagamaan">Keagamaan</option>
                            <option value="Kebajikan">Kebajikan / CSR</option>
                            <option value="Lain-lain">Lain-lain</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Cadangan Lokasi (Venue)</label>
                        <input type="text" name="req_venue" placeholder="Contoh: Padang Awam / Balai Raya">
                    </div>

                    <div class="form-group">
                        <label>Tarikh Cadangan</label>
                        <input type="date" name="req_date">
                    </div>

                    <div class="form-group">
                        <label>Masa Cadangan</label>
                        <input type="time" name="req_time">
                    </div>

                    <div class="form-group">
                        <label>Anggaran Bilangan Peserta</label>
                        <input type="number" name="req_est_participants" placeholder="0">
                    </div>

                    <div class="form-group">
                        <label>Anggaran Bajet (RM)</label>
                        <input type="number" step="0.01" name="req_est_budget" placeholder="0.00">
                    </div>

                    <div class="form-group full-width">
                        <label><i class='bx bx-cloud-upload'></i> Dokumen Sokongan (PDF/Gambar)</label>
                        <input type="file" name="req_docs">
                        <small style="color: #a0aec0;">Muat naik kertas kerja atau surat iringan jika ada.</small>
                    </div>

                </div>

                <button type="submit" class="btn-submit">
                    <i class='bx bx-send'></i> Hantar Permohonan
                </button>
            </form>

            <a href="1.3_guest_dashboard.php" class="back-link">
                <i class='bx bx-left-arrow-alt'></i> Kembali ke Dashboard
            </a>
        </div>
    </div>
</div>

</body>
</html>