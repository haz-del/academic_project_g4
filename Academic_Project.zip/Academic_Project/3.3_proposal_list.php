<?php
session_start(); // Required to access the logged-in user's role
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '0.1_dbconnect.php';

// 1. Determine Dashboard Link based on Role
$dashboard_link = "3.0_proposal_index.php"; // Default fallback

if (isset($_SESSION['com_role'])) {
    if ($_SESSION['com_role'] === 'Village Head') {
        $dashboard_link = "1.1_head_dashboard.php"; // Change to your actual file
    } elseif ($_SESSION['com_role'] === 'Exco') {
        $dashboard_link = "1.2_committee_dashboard.php"; // Change to your actual file
    }
}

// 2. Search and Filter Logic
$search = $_GET['search'] ?? "";
$status = $_GET['status'] ?? "";

/* Base SQL */
$sql = "SELECT * FROM programme_proposal WHERE 1";

/* Search by programme name */
if ($search != "") {
    $sql .= " AND prog_name LIKE '%$search%'";
}

/* Filter by status */
if ($status != "") {
    $sql .= " AND prog_status = '$status'";
}

$sql .= " ORDER BY proposal_id DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Programme Proposal List</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f6f8; padding: 20px; }
        .container { max-width: 1000px; margin: auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }
        th { background-color: #e9ecef; }
        .status-tag { font-weight: bold; text-transform: capitalize; }
        .btn-view { color: #007bff; text-decoration: none; font-weight: bold; }
        input, select { padding: 6px; border-radius: 4px; border: 1px solid #ccc; }
        button { padding: 6px 14px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; }
    </style>
</head>
<body>

<div class="container">
    <h2>Programme Proposal List</h2>

    <form method="GET" style="margin-bottom: 20px;">
        Search: 
        <input type="text" name="search" placeholder="Programme Name" value="<?= htmlspecialchars($search); ?>">

        Status:
        <select name="status">
            <option value="">All</option>
            <option value="Draft" <?= $status=="Draft"?"selected":""; ?>>Draft</option>
            <option value="Pending Approval" <?= $status=="Pending Approval"?"selected":""; ?>>Pending Approval</option>
            <option value="Returned" <?= $status=="Returned"?"selected":""; ?>>Returned</option>
            <option value="Approved" <?= $status=="Approved"?"selected":""; ?>>Approved</option>
        </select>

        <button type="submit">Filter</button>
    </form>

    <table>
        <tr>
            <th>Programme Name</th>
            <th>Date</th>
            <th>Status</th>
            <th>Action</th>
        </tr>

        <?php if ($result && $result->num_rows > 0) { ?>
            <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?= htmlspecialchars($row['prog_name']); ?></td>
                <td><?= htmlspecialchars($row['prog_date'] ?? 'N/A'); ?></td>
                <td class="status-tag"><?= htmlspecialchars($row['prog_status']); ?></td>
                <td>
                    <a href="3.2_proposal_detail.php?id=<?= $row['proposal_id']; ?>" class="btn-view">View</a>
                </td>
            </tr>
            <?php } ?>
        <?php } else { ?>
            <tr>
                <td colspan="4" style="text-align:center;">No proposals found.</td>
            </tr>
        <?php } ?>
    </table>

    <br>
    <a href="<?= $dashboard_link; ?>" style="text-decoration: none; color:blue ;">← Back to Home</a>
</div>

</body>
</html>