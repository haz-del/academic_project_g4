<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '0.1_dbconnect.php';

// Semakan akses: Pastikan pengguna sudah log masuk
if (!isset($_SESSION['com_id'])) {
    header("Location: 2.0_login.php");
    exit();
}

// 1. Dapatkan report_id dari URL
$report_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($report_id == 0) die("ID Laporan tidak sah.");

// 2. JOIN jadual untuk dapatkan maklumat proposal melalui report_id
$sql = "SELECT p.*, r.report_id, r.prog_summary, r.prog_improvement, r.prog_act_participants 
        FROM programme_proposal p
        JOIN programme_report r ON p.proposal_id = r.proposal_id
        WHERE r.report_id = $report_id";

$result = $conn->query($sql);

if (!$result || $result->num_rows == 0) {
    // Fallback: Jika ID yang dihantar sebenarnya proposal_id
    $result = $conn->query("SELECT * FROM programme_proposal WHERE proposal_id = $report_id");
    if (!$result || $result->num_rows == 0) die("Rekod tidak dijumpai.");
}

$p = $result->fetch_assoc();
$proposal_id = $p['proposal_id'];

// 3. Ambil data bajet
$income_items = [];
$expense_items = [];
$budget_query = "SELECT * FROM programme_budget WHERE proposal_id = $proposal_id";
$budget_result = $conn->query($budget_query);

if ($budget_result) {
    while ($row = $budget_result->fetch_assoc()) {
        if (!empty($row['income_name'])) $income_items[] = $row;
        if (!empty($row['expense_name'])) $expense_items[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Butiran Program | <?= htmlspecialchars($p['prog_name']); ?></title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.95);
            --text-dark: #1a2a3a;
        }

        body { 
            font-family: 'Segoe UI', sans-serif;
            background: url('uploads/Bg/Background.jpg') no-repeat center fixed;
            background-size: cover;
            margin: 0;
        }

        .main-content {
            margin-left: 260px;
            padding: 40px;
            padding-top: 100px;
            display: flex;
            justify-content: center;
        }

        .container {
            background: var(--glass-bg);
            padding: 40px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 950px;
        }

        h2, h3 { color: var(--primary-blue); margin-bottom: 20px; }
        
        .status-badge {
            padding: 6px 15px;
            border-radius: 8px;
            font-weight: bold;
            font-size: 0.9rem;
            background: #e0e7ff;
            color: #4338ca;
            display: inline-block;
            margin-bottom: 25px;
        }

        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }

        .form-group { margin-bottom: 15px; }
        .full-width { grid-column: span 2; }

        label { font-weight: 600; color: #555; display: block; margin-bottom: 5px; font-size: 0.9rem; }
        
        input, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #d1d5db;
            border-radius: 10px;
            background: #f9fafb;
            color: #333;
            font-size: 1rem;
            box-sizing: border-box;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
            background: white;
            border-radius: 10px;
            overflow: hidden;
        }

        th { background: #f1f5f9; padding: 12px; text-align: left; color: #475569; font-size: 0.85rem; }
        td { padding: 12px; border-bottom: 1px solid #f1f5f9; font-size: 0.95rem; }

        .section-divider {
            border-top: 2px solid #e5e7eb;
            margin: 40px 0 20px 0;
            padding-top: 20px;
        }

        .btn-back {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #64748b;
            text-decoration: none;
            font-weight: 600;
            margin-bottom: 20px;
            transition: 0.2s;
        }
        .btn-back:hover { color: var(--primary-blue); }

        @media (max-width: 768px) {
            .main-content { margin-left: 0; padding: 20px; padding-top: 80px; }
            .info-grid { grid-template-columns: 1fr; }
            .full-width { grid-column: span 1; }
        }
    </style>
</head>
<body>

<?php 
// Logik Navibar Dinamik
if (isset($_SESSION['com_role'])) {
    if ($_SESSION['com_role'] === 'Village Head') {
        include '0.2_ketua_navbar.php';
    } else {
        include '0.3_committee_navbar.php';
    }
}
?>

<div class="main-content">
    <div class="container">
        <a href="6.3_report_approval.php" class="btn-back"><i class='bx bx-left-arrow-alt'></i> Kembali ke Sejarah</a>
        
        <h2><i class='bx bx-info-circle'></i> Butiran Penuh Program</h2>
        <div class="status-badge">Status: <?= htmlspecialchars($p['prog_status']); ?></div>

        <div class="info-grid">
            <div class="form-group full-width">
                <label>Tajuk Program</label>
                <input type="text" value="<?= htmlspecialchars($p['prog_name']); ?>" disabled>
            </div>
            
            <div class="form-group full-width">
                <label>Objektif</label>
                <textarea rows="3" disabled><?= htmlspecialchars($p['prog_objectives']); ?></textarea>
            </div>

            <div class="form-group">
                <label>Kategori</label>
                <input type="text" value="<?= htmlspecialchars($p['prog_category']); ?>" disabled>
            </div>

            <div class="form-group">
                <label>Lokasi</label>
                <input type="text" value="<?= htmlspecialchars($p['prog_venue']); ?>" disabled>
            </div>

            <div class="form-group">
                <label>Tarikh & Masa</label>
                <input type="text" value="<?= date('d/m/Y', strtotime($p['prog_date'])); ?> | <?= $p['prog_time']; ?>" disabled>
            </div>

            <div class="form-group">
                <label>Anggaran Peserta</label>
                <input type="text" value="<?= $p['prog_est_participants']; ?> orang" disabled>
            </div>
        </div>

        <div class="section-divider">
            <h3><i class='bx bx-money'></i> Perincian Bajet</h3>
            
            <div class="info-grid">
                <div>
                    <label>Sumber Pendapatan</label>
                    <table>
                        <thead><tr><th>Sumber</th><th>Jumlah (RM)</th></tr></thead>
                        <tbody>
                            <?php foreach ($income_items as $item): ?>
                                <tr>
                                    <td><?= htmlspecialchars($item['income_name']) ?></td>
                                    <td><?= number_format($item['income_amt'], 2) ?></td>
                                </tr>
                            <?php endforeach; if(empty($income_items)) echo "<tr><td colspan='2'>Tiada data</td></tr>"; ?>
                        </tbody>
                    </table>
                </div>
                <div>
                    <label>Anggaran Perbelanjaan</label>
                    <table>
                        <thead><tr><th>Item</th><th>Jumlah (RM)</th></tr></thead>
                        <tbody>
                            <?php foreach ($expense_items as $item): ?>
                                <tr>
                                    <td><?= htmlspecialchars($item['expense_name']) ?></td>
                                    <td><?= number_format($item['expense_amt'], 2) ?></td>
                                </tr>
                            <?php endforeach; if(empty($expense_items)) echo "<tr><td colspan='2'>Tiada data</td></tr>"; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php if (isset($p['prog_summary'])): ?>
        <div class="section-divider">
            <h3><i class='bx bx-task'></i> Laporan Pasca-Program</h3>
            <div class="info-grid">
                <div class="form-group full-width">
                    <label>Ringkasan Aktiviti</label>
                    <textarea rows="4" disabled><?= htmlspecialchars($p['prog_summary']); ?></textarea>
                </div>
                <div class="form-group">
                    <label>Penambahbaikan</label>
                    <textarea rows="3" disabled><?= htmlspecialchars($p['prog_improvement']); ?></textarea>
                </div>
                <div class="form-group">
                    <label>Peserta Sebenar</label>
                    <input type="text" value="<?= $p['prog_act_participants']; ?> orang" disabled>
                </div>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>

</body>
</html>