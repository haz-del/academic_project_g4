<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
include '0.1_dbconnect.php';

// Semakan Sesi
if (!isset($_SESSION['com_role'])) {
    die('Unauthorized access');
}

$current_user_id = $_SESSION['com_id']; 
$role = $_SESSION['com_role'];

/* ================= 1. LOGIK FILTER & CARIAN ================= */
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$status_filter = isset($_GET['status_filter']) ? mysqli_real_escape_string($conn, $_GET['status_filter']) : '';

// Query Base
$sql = "SELECT p.*, r.report_id 
        FROM programme_proposal p 
        LEFT JOIN programme_report r ON p.proposal_id = r.proposal_id";

$conditions = [];

// Filter Nama
if (!empty($search)) {
    $conditions[] = "p.prog_name LIKE '%$search%'";
}

// Filter Status
if (!empty($status_filter)) {
    $conditions[] = "p.prog_status = '$status_filter'";
}

if (count($conditions) > 0) {
    $sql .= " WHERE " . implode(' AND ', $conditions);
}

$sql .= " ORDER BY p.prog_date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Senarai Program</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --border-color: rgba(255, 255, 255, 0.5);
            --sidebar-width: 260px;
            --highlight-gold: #fff9db; /* Warna highlight untuk program user */
            --highlight-border: #fcc419;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { 
            font-family: 'Segoe UI', Arial, sans-serif; 
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover; background-attachment: fixed;
            min-height: 100vh;
            transition: all 0.3s ease;
        }

        /* --- AUTOCORRECT LAYOUT --- */
        .main-content { margin-left: var(--sidebar-width); padding: 40px; padding-top: 100px; transition: all 0.3s ease-in-out; }
        body.sidebar-closed .main-content { margin-left: 0; }

        .container { 
            width: 100%; max-width: 1200px; margin: auto; background: var(--glass-bg); 
            padding: 30px; border-radius: 20px; backdrop-filter: blur(15px);
            border: 1px solid var(--border-color); box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        h2 { color: var(--primary-blue); margin-bottom: 25px; font-size: 1.8rem; }

        /* --- FILTER BAR --- */
        .filter-wrapper {
            display: flex; gap: 15px; margin-bottom: 25px; flex-wrap: wrap;
            background: rgba(255,255,255,0.5); padding: 15px; border-radius: 12px;
        }
        .filter-wrapper input, .filter-wrapper select {
            padding: 10px 15px; border-radius: 8px; border: 1px solid #ddd; outline: none;
        }
        .btn-filter { background: var(--primary-blue); color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-weight: 600; }
        .btn-reset { background: #64748b; color: white; text-decoration: none; padding: 10px 20px; border-radius: 8px; font-size: 14px; }

        /* --- HIGHLIGHT ROW --- */
        .user-program-row { 
            background-color: var(--highlight-gold) !important; 
            border-left: 5px solid var(--highlight-border) !important;
        }
        .owner-tag {
            background: var(--highlight-border); color: #856404; font-size: 10px; 
            padding: 2px 8px; border-radius: 4px; font-weight: bold; margin-left: 10px;
        }

        /* --- TABLE STYLE --- */
        .table-responsive { overflow-x: auto; border-radius: 12px; }
        table { width: 100%; border-collapse: collapse; background: #fff; }
        th { background: #f8f9fa; color: var(--primary-blue); padding: 15px; border-bottom: 2px solid #eee; text-align: center; font-size: 14px; }
        td { padding: 15px; border-bottom: 1px solid #eee; vertical-align: middle; text-align: center; font-size: 14px; }
        
        .status-badge { font-weight: bold; text-transform: uppercase; font-size: 11px; padding: 4px 10px; border-radius: 12px; }
        .approved { background: #e6fffa; color: #10b981; }
        .pending { background: #fff9db; color: #f59e0b; }
        .rejected { background: #fff5f5; color: #ef4444; }

        .btn { padding: 8px 15px; border-radius: 8px; text-decoration: none; color: #fff; font-size: 12px; font-weight: 600; transition: 0.3s; display: inline-flex; align-items: center; gap: 5px; }
        .view { background: var(--primary-blue); }
        .report { background: #10b981; }
        .disabled { background: #cbd5e1; color: #64748b; cursor: not-allowed; }
    </style>
</head>
<body id="body-layout">

    <?php include ($_SESSION['com_role'] === 'Village Head') ? '0.2_ketua_navbar.php' : '0.3_committee_navbar.php'; ?>

    <div class="main-content">
        <div class="container">
            <h2><i class='bx bx-spreadsheet'></i> Senarai Program</h2>

            <form action="" method="GET" class="filter-wrapper">
                <input type="text" name="search" placeholder="Cari nama program..." value="<?= htmlspecialchars($search); ?>" style="flex: 2;">
                
                <select name="status_filter" style="flex: 1;">
                    <option value="">-- Semua Status --</option>
                    <option value="Pending" <?= $status_filter == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="Approved" <?= $status_filter == 'Approved' ? 'selected' : ''; ?>>Approved</option>
                    <option value="Returned" <?= $status_filter == 'Returned' ? 'selected' : ''; ?>>Returned</option>
                    <option value="Rejected" <?= $status_filter == 'Rejected' ? 'selected' : ''; ?>>Rejected</option>
                </select>

                <button type="submit" class="btn-filter"><i class='bx bx-filter-alt'></i> Tapis</button>
                <a href="5.0_programme_list.php" class="btn-reset">Reset</a>
            </form>

            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Nama Program</th>
                            <th>Tarikh</th>
                            <th>Lokasi</th>
                            <th>Status</th>
                            <th>Tindakan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && $result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <?php 
                                    // Highlight jika program ini milik user yang login (berdasarkan com_id / committee_id)
                                    // Sila tukar 'com_id' mengikut nama kolum penganjur di DB anda
                                    $isMyProgram = (isset($row['com_id']) && $row['com_id'] == $current_user_id); 
                                    $rowClass = $isMyProgram ? 'user-program-row' : '';
                                ?>
                                <tr class="<?= $rowClass; ?>">
                                    <td style="text-align: left; font-weight: 600;">
                                        <?= htmlspecialchars($row['prog_name']); ?>
                                        <?php if($isMyProgram): ?><span class="owner-tag">PROGRAM SAYA</span><?php endif; ?>
                                    </td>
                                    <td><?= date("d/m/Y", strtotime($row['prog_date'])); ?></td>
                                    <td><?= htmlspecialchars($row['prog_venue']); ?></td>
                                    <td>
                                        <span class="status-badge <?= strtolower($row['prog_status']); ?>">
                                            <?= htmlspecialchars($row['prog_status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a class="btn view" href="3.2_proposal_detail.php?id=<?= $row['proposal_id']; ?>&source=AJK">
                                            <i class='bx bx-show'></i> Lihat
                                        </a>

                                        <?php if (($row['prog_status'] === 'Approved' || $row['prog_status'] === 'Accept')): ?>
                                            <?php if (!empty($row['report_id'])): ?>
                                                <span class="btn" style="background: #059669; cursor: default;"><i class='bx bx-check-circle'></i> Selesai</span>
                                            <?php elseif ($isMyProgram || $role === 'Village Head'): ?>
                                                <a class="btn report" href="6.0_programme_report.php?proposal_id=<?= $row['proposal_id']; ?>">
                                                    <i class='bx bx-file'></i> Laporan
                                                </a>
                                            <?php else: ?>
                                                <span class="btn disabled" title="Hanya penganjur boleh hantar laporan"><i class='bx bx-lock'></i> Laporan</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="5" style="padding: 40px; color: #999;">Tiada rekod ditemui.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Logik Autocorrect Navbar
        document.addEventListener("DOMContentLoaded", function() {
            const toggleBtn = document.querySelector('.header_toggle') || document.getElementById('header-toggle');
            const body = document.getElementById('body-layout');

            if(toggleBtn) {
                toggleBtn.addEventListener('click', () => {
                    body.classList.toggle('sidebar-closed');
                });
            }
        });
    </script>
</body>
</html>