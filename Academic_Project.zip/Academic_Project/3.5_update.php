<?php
session_start();
include '0.1_dbconnect.php';

$proposal_id = (int)$_POST['proposal_id'];

$sql = "
UPDATE programme_proposal SET
    prog_title = '{$conn->real_escape_string($_POST['title'])}',
    prog_objectives = '{$conn->real_escape_string($_POST['objectives'])}',
    prog_category = '{$conn->real_escape_string($_POST['category'])}',
    prog_venue = '{$conn->real_escape_string($_POST['venue'])}',
    prog_date = '{$conn->real_escape_string($_POST['programme_date'])}',
    prog_time = '{$conn->real_escape_string($_POST['programme_time'])}',
    prog_participants = '{$conn->real_escape_string($_POST['participants'])}',
    prog_status = 'Pending',
    prog_status_comment = NULL,
    prog_status_by = NULL,
    prog_status_doc = NULL
WHERE proposal_id = $proposal_id
";

$conn->query($sql);

header("Location: 3.0_proposal_list.php");
exit;
