<?php
include '0.1_dbconnect.php';

if (isset($_GET['id']) && isset($_GET['new_status'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $status = mysqli_real_escape_string($conn, $_GET['new_status']);

    // Update the request_status in the database
    $sql = "UPDATE guest_requests SET request_status = '$status' WHERE request_id = '$id'";

    if ($conn->query($sql)) {
        echo "<script>alert('Request has been marked as $status.'); window.location.href='3.9_guest_request_list.php';</script>";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>