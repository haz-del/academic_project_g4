<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '0.1_dbconnect.php';

// --------------------
// 1. Get IDs and Data
// --------------------
$com_id = $_SESSION['com_id'] ?? null;

if (!$com_id) {
    die("Error: No Committee ID found. Please log in first.");
}

$request_id = $_POST['request_id'] ?? NULL;
$prog_name = $_POST['title'] ?? '';
$prog_objectives = $_POST['objectives'] ?? '';
$prog_category = $_POST['category'] ?? '';
$prog_venue = $_POST['venue'] ?? '';
$prog_date = $_POST['programme_date'] ?: NULL;
$prog_time = $_POST['programme_time'] ?: NULL;
$prog_est_participants = $_POST['participants'] ?: NULL;
$action = $_POST['action'] ?? 'draft';

// --------------------
// 2. Status logic
// --------------------
if ($action === 'next') {
    $prog_status = 'Pending Approval';
    $prog_prop_submitted = date('Y-m-d H:i:s');
} else {
    $prog_status = 'Draft';
    $prog_prop_submitted = NULL;
}

// --------------------
// 3. File upload
// --------------------
$prog_docs = NULL;
if (!empty($_FILES['document']['name'])) {
    $file_name = time() . "_" . preg_replace("/[^a-zA-Z0-9.]/", "_", $_FILES['document']['name']);
    $tmp = $_FILES['document']['tmp_name'];
    $path = "upload/" . $file_name;
    if (move_uploaded_file($tmp, $path)) {
        $prog_docs = $path;
    }
}

// --------------------
// 4. Insert Programme Proposal
// --------------------
$sql = "INSERT INTO programme_proposal (
    com_id, request_id, prog_name, prog_objectives, prog_category,
    prog_venue, prog_date, prog_time, prog_est_participants,
    prog_docs, prog_prop_submitted, prog_status
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
}

$db_request_id = (!empty($request_id)) ? $request_id : NULL;

$stmt->bind_param(
    "iisssssissss",
    $com_id,
    $db_request_id,
    $prog_name,
    $prog_objectives,
    $prog_category,
    $prog_venue,
    $prog_date,
    $prog_time,
    $prog_est_participants,
    $prog_docs,
    $prog_prop_submitted,
    $prog_status
);

if (!$stmt->execute()) {
    die("Execute failed: (" . $stmt->errno . ") " . $stmt->error);
}

$proposal_id = $conn->insert_id;
$stmt->close();

// --------------------
// 5. Save Collaborators (Junction Table)
// --------------------
$collaborators = $_POST['collaborators'] ?? [];

if (!empty($collaborators)) {

    $coll_sql = "
        INSERT INTO collaboratorsproposal
        (proposal_id, coll_id, coll_quantity, coll_role, coll_amount)
        VALUES (?, ?, ?, ?, ?)
    ";

    $coll_stmt = $conn->prepare($coll_sql);

    foreach ($collaborators as $coll_id) {

        $coll_id = (int)$coll_id;
        $coll_quantity = 1;
        $coll_role = 'Collaborator';
        $coll_amount = NULL;

        $coll_stmt->bind_param(
            "iiisd",
            $proposal_id,
            $coll_id,
            $coll_quantity,
            $coll_role,
            $coll_amount
        );

        $coll_stmt->execute();
    }

    $coll_stmt->close();
}

// --------------------
// 6. Update Guest Request Status
// --------------------
if (!empty($db_request_id)) {
    $update_sql = "UPDATE guest_requests SET request_status = 'Approved' WHERE request_id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("i", $db_request_id);
    $update_stmt->execute();
    $update_stmt->close();
}

// --------------------
// 7. Redirect
// --------------------
if ($action === 'next') {
    header("Location: 7.1_budget_proposal.php?proposal_id=$proposal_id");
    exit;
}

header("Location: 3.0_proposal_index.php");
exit;
?>
