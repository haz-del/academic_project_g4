<?php
session_start();
require_once "0.1_dbconnect.php";

$user_role = $_SESSION['com_role'] ?? ''; 
$guest_id = isset($_GET['guest_id']) ? intval($_GET['guest_id']) : 0;

// Fetch guest profile
$sql_guest = "SELECT * FROM guest WHERE guest_id = $guest_id";
$result_guest = mysqli_query($conn, $sql_guest);
$guest = mysqli_fetch_assoc($result_guest);

// Fetch guest activity history
$sql_activity = "SELECT * FROM guest_requests WHERE guest_id = $guest_id ORDER BY req_date DESC";
$result_activity = mysqli_query($conn, $sql_activity);
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil & Sejarah Aktiviti Tetamu</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary: #0061f2;
            --secondary: #6900f2;
            --glass: rgba(255, 255, 255, 0.9);
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background: url('uploads/Bg/Background.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 40px 20px;
            color: #1e293b;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Glass Card Effect */
        .glass-card {
            background: var(--glass);
            backdrop-filter: blur(15px);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            border: 1px solid rgba(255,255,255,0.4);
            margin-bottom: 30px;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: white;
            text-decoration: none;
            font-weight: 600;
            margin-bottom: 20px;
            background: rgba(0,0,0,0.3);
            padding: 10px 20px;
            border-radius: 50px;
            transition: 0.3s;
        }

        .back-link:hover {
            background: var(--primary);
            transform: translateX(-5px);
        }

        h2 {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.5rem;
            margin-top: 0;
            color: #0f172a;
        }

        /* Profile Grid */
        .profile-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .profile-item {
            background: rgba(255,255,255,0.5);
            padding: 15px;
            border-radius: 12px;
            border: 1px solid rgba(0,0,0,0.05);
        }

        .profile-item label {
            display: block;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #64748b;
            font-weight: 700;
        }

        .profile-item span {
            font-size: 1.05rem;
            font-weight: 500;
        }

        /* Table Styling */
        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            background: rgba(255,255,255,0.3);
            border-radius: 12px;
        }

        th {
            background: rgba(0, 97, 242, 0.1);
            color: var(--primary);
            text-align: left;
            padding: 15px;
            font-size: 0.85rem;
            text-transform: uppercase;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            font-size: 0.9rem;
        }

        tr:hover {
            background: rgba(255,255,255,0.6);
        }

        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            background: var(--primary);
            color: white;
        }

        .btn-view {
            color: var(--primary);
            text-decoration: none;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .budget {
            font-weight: 700;
            color: #059669;
        }

        .empty-state {
            text-align: center;
            padding: 40px;
            color: #64748b;
        }
    </style>
</head>
<body>

<div class="container">
    <a href="10.3_guest_list.php" class="back-link">
        <i class='bx bx-left-arrow-alt'></i> Kembali ke Senarai Tetamu
    </a>

    <?php if ($guest) { ?>
        <div class="glass-card">
            <h2><i class='bx bx-user-circle' style="color: var(--primary);"></i> Profil Tetamu</h2>
            <div class="profile-grid">
                <div class="profile-item">
                    <label>Nama Penuh</label>
                    <span><?= htmlspecialchars($guest['guest_name']); ?></span>
                </div>
                <div class="profile-item">
                    <label>Organisasi (Jenis)</label>
                    <span><?= htmlspecialchars($guest['guest_organisation']); ?> (<?= htmlspecialchars($guest['guest_org_type']); ?>)</span>
                </div>
                <div class="profile-item">
                    <label>No. Telefon</label>
                    <span><?= htmlspecialchars($guest['guest_phone']); ?></span>
                </div>
                <div class="profile-item">
                    <label>E-mel</label>
                    <span><?= htmlspecialchars($guest['guest_email']); ?></span>
                </div>
                <div class="profile-item" style="grid-column: span 2;">
                    <label>Alamat</label>
                    <span><?= htmlspecialchars($guest['guest_address']); ?></span>
                </div>
            </div>
        </div>

        <div class="glass-card">
            <h2><i class='bx bx-history' style="color: var(--secondary);"></i> Sejarah Aktiviti</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama Aktiviti</th>
                            <th>Kategori</th>
                            <th>Lokasi</th>
                            <th>Tarikh & Masa</th>
                            <th>Peserta</th>
                            <th>Bajet (RM)</th>
                            <th>Dokumen</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result_activity && mysqli_num_rows($result_activity) > 0) { ?>
                            <?php while ($row = mysqli_fetch_assoc($result_activity)) { ?>
                                <tr>
                                    <td>#<?= htmlspecialchars($row['request_id']); ?></td>
                                    <td>
                                        <strong><?= htmlspecialchars($row['req_name']); ?></strong><br>
                                        <small style="color: #64748b;"><?= substr(htmlspecialchars($row['req_objectives']), 0, 50); ?>...</small>
                                    </td>
                                    <td><span class="status-badge"><?= htmlspecialchars($row['req_category']); ?></span></td>
                                    <td><?= htmlspecialchars($row['req_venue']); ?></td>
                                    <td>
                                        <i class='bx bx-calendar'></i> <?= htmlspecialchars($row['req_date']); ?><br>
                                        <i class='bx bx-time'></i> <?= htmlspecialchars($row['req_time']); ?>
                                    </td>
                                    <td><?= htmlspecialchars($row['req_est_participants']); ?></td>
                                    <td class="budget"><?= number_format((float)$row['req_est_budget'], 2); ?></td>
                                    <td>
                                        <?php if(!empty($row['req_docs'])) { ?>
                                            <a href="uploads/<?= htmlspecialchars($row['req_docs']); ?>" target="_blank" class="btn-view">
                                                <i class='bx bx-file'></i> Lihat
                                            </a>
                                        <?php } else { echo '-'; } ?>
                                    </td>
                                </tr>
                            <?php } ?>
                        <?php } else { ?>
                            <tr>
                                <td colspan="8" class="empty-state">
                                    <i class='bx bx-folder-open' style="font-size: 3rem; opacity: 0.2;"></i>
                                    <p>Tiada rekod aktiviti ditemui untuk tetamu ini.</p>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php } else { ?>
        <div class="glass-card" style="text-align: center;">
            <i class='bx bx-error-circle' style="font-size: 4rem; color: #ef4444;"></i>
            <p>Tetamu tidak dijumpai dalam sistem.</p>
        </div>
    <?php } ?>
</div>

</body>
</html>