<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();   

include '0.1_dbconnect.php';

/* 1. Initialize default values */
$p_title = "";
$p_objectives = "";
$p_category = "";
$p_venue = "";
$p_date = "";
$p_time = "";
$p_participants = "";
$request_id_val = "";

/* 2. Auto-fill from guest_requests */
if (isset($_GET['request_id'])) {
    $request_id = (int)$_GET['request_id'];
    $query = "SELECT * FROM guest_requests WHERE request_id = $request_id";
    $result = $conn->query($query);

    if ($result && $row = $result->fetch_assoc()) {
        $p_title        = $row['req_name'];
        $p_objectives   = $row['req_objectives'];
        $p_category     = $row['req_category'];
        $p_venue        = $row['req_venue'];
        $p_date         = $row['req_date'];
        $p_time         = $row['req_time'];
        $p_participants = $row['req_est_participants'];
        $request_id_val = $row['request_id'];
    }
}

/* 3. Get collaborators list */
$collaborators = [];
$coll_sql = "SELECT coll_id, coll_organisation_name FROM collaborators ORDER BY coll_organisation_name";
$coll_result = $conn->query($coll_sql);
if ($coll_result) {
    while ($c = $coll_result->fetch_assoc()) {
        $collaborators[] = $c;
    }
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>Create Programme Proposal</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body { 
            font-family: 'Segoe UI', Arial, sans-serif; 
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            min-height: 100vh;
        }

        /* DYNAMIC LAYOUT LOGIC */
        .main-content {
            margin-left: 260px;
            padding: 40px;
            padding-top: 100px;
            transition: all 0.3s ease;
        }

        #mySidebar.collapsed ~ .main-content { margin-left: 0; }

        /* GLASS CONTAINER */
        .container {
            width: 100%;
            max-width: 850px;
            margin: auto;
            background: var(--glass-bg);
            padding: 40px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid var(--border-color);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        h2 { color: var(--primary-blue); margin-bottom: 30px; font-size: 1.8rem; border-bottom: 2px solid #e2e8f0; padding-bottom: 10px; }

        .form-group { margin-bottom: 20px; }
        label { font-weight: 600; display: block; margin-bottom: 8px; color: var(--text-dark); font-size: 14px;}
        
        input, textarea, select {
            width: 100%;
            padding: 12px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.8);
            font-size: 14px;
            transition: border-color 0.2s;
        }

        input:focus, textarea:focus, select:focus {
            outline: none;
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(0, 97, 242, 0.1);
        }

        /* Multiselect Dropdown */
        .multiselect-container { position: relative; width: 100%; }
        .selectBox {
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            padding: 12px;
            background: #fff;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 14px;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: white;
            border: 1px solid #cbd5e1;
            width: 100%;
            z-index: 1000;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.1);
            border-radius: 8px;
            margin-top: 5px;
        }

        .search-input { border: none; border-bottom: 1px solid #f1f1f1; border-radius: 0; }

        /* Buttons */
        .btn-container { text-align: center; margin-top: 35px; display: flex; justify-content: center; gap: 15px; }
        
        button {
            padding: 12px 25px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 15px;
            font-weight: 600;
            transition: 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .draft-btn { background: #64748b; color: #fff; }
        .submit-btn { background: var(--primary-blue); color: #fff; }
        button:hover { opacity: 0.9; transform: translateY(-1px); }

        .checkbox-item { display: flex; align-items: center; padding: 10px; cursor: pointer; transition: 0.2s; }
        .checkbox-item:hover { background: #f8fafc; }
        .checkbox-item input { width: auto; margin-right: 12px; }
    </style>
</head>

<body>
<?php
if (isset($_SESSION['com_role'])) {
    if ($_SESSION['com_role'] === 'Village Head') {
        include '0.2_ketua_navbar.php';
    } else {
        include '0.3_committee_navbar.php';
    }
} else {
    die('Unauthorized access');
}
?>

<div class="main-content">
    <div class="container">
        <h2><i class='bx bx-edit-alt'></i> Borang Kertas Kerja</h2>

        <form action="3.4_save.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="request_id" value="<?= htmlspecialchars($request_id_val) ?>">

            <div class="form-group">
                <label>Nama Program</label>
                <input type="text" name="title" value="<?= htmlspecialchars($p_title) ?>" required placeholder="Contoh: Gotong Royong Perdana">
            </div>

            <div class="form-group">
                <label>Objektif</label>
                <textarea name="objectives" rows="4" required placeholder="Nyatakan objektif utama program..."><?= htmlspecialchars($p_objectives) ?></textarea>
            </div>

            <div class="form-group">
                <label>Kategori</label>
                <select name="category" required>
                    <option value="">-- Pilih Kategori --</option>
                    <?php
                    $categories = [
                        "Education" => "Pendidikan",
                        "Religious" => "Keagamaan",
                        "Corporate Social Responsibility" => "Tanggungjawab Sosial Korporat",
                        "Entrepreneurship" => "Keusahawanan",
                        "Others" => "Lain-lain"
                    ];
                    foreach ($categories as $eng => $bm) {
                        $selected = ($p_category === $eng) ? "selected" : "";
                        echo "<option value=\"$eng\" $selected>$bm</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label>Tempat</label>
                <input type="text" name="venue" value="<?= htmlspecialchars($p_venue) ?>" placeholder="Contoh: Dewan Serbaguna">
            </div>

            <div style="display: flex; gap: 20px;">
                <div class="form-group" style="flex: 1;">
                    <label>Tarikh</label>
                    <input type="date" name="programme_date" value="<?= htmlspecialchars($p_date) ?>">
                </div>
                <div class="form-group" style="flex: 1;">
                    <label>Masa</label>
                    <input type="time" name="programme_time" value="<?= htmlspecialchars($p_time) ?>">
                </div>
            </div>

            <div class="form-group">
                <label>Anggaran Peserta</label>
                <input type="number" name="participants" value="<?= htmlspecialchars($p_participants) ?>" placeholder="0">
            </div>

            <div class="form-group">
                <label>Rakan Kolaborasi</label>
                <div class="multiselect-container">
                    <div class="selectBox" onclick="toggleDropdown()">
                        <span id="selectedCount">Pilih Rakan Kolaborasi (0 dipilih)</span>
                        <i class='bx bx-chevron-down'></i>
                    </div>
                    <div id="checkboxes" class="dropdown-content">
                        <input type="text" id="collabSearch" onkeyup="filterCollaborators()" placeholder="Cari organisasi..." class="search-input">
                        <div style="max-height: 200px; overflow-y: auto;">
                            <?php if (count($collaborators) > 0): ?>
                                <?php foreach ($collaborators as $c): ?>
                                    <label class="checkbox-item">
                                        <input type="checkbox" name="collaborators[]" value="<?= $c['coll_id'] ?>" onchange="updateCount()">
                                        <span class="org-name"><?= htmlspecialchars($c['coll_organisation_name']) ?></span>
                                    </label>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p style="padding: 10px; color:#888;">Tiada rekod kolaborator.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label>Dokumen Tambahan (PDF/Imej)</label>
                <input type="file" name="document" style="padding: 8px;">
            </div>

            <div class="btn-container">
                <button type="submit" name="action" value="draft" class="draft-btn">
                    <i class='bx bx-save'></i> Simpan Draf
                </button>
                <button type="submit" name="action" value="next" class="submit-btn">
                    Seterusnya <i class='bx bx-right-arrow-alt'></i>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function toggleDropdown() {
    const checkboxes = document.getElementById("checkboxes");
    checkboxes.style.display = (checkboxes.style.display === "block") ? "none" : "block";
}

function updateCount() {
    const checkboxes = document.querySelectorAll('input[name="collaborators[]"]:checked');
    const label = document.getElementById("selectedCount");
    label.innerText = (checkboxes.length > 0) 
        ? `Rakan Kolaborasi (${checkboxes.length} dipilih)` 
        : "Pilih Rakan Kolaborasi (0 dipilih)";
}

function filterCollaborators() {
    const input = document.getElementById("collabSearch");
    const filter = input.value.toLowerCase();
    const items = document.querySelectorAll(".checkbox-item");
    items.forEach(item => {
        const text = item.querySelector(".org-name").innerText.toLowerCase();
        item.style.display = text.includes(filter) ? "flex" : "none";
    });
}

window.onclick = function(event) {
    if (!event.target.closest(".multiselect-container")) {
        document.getElementById("checkboxes").style.display = "none";
    }
}
</script>
</body>
</html>