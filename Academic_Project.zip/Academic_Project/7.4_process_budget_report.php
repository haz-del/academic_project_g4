<?php
session_start();
include '0.1_dbconnect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $report_id = intval($_POST['report_id']);
    
    // Mulakan transaksi untuk memastikan kedua-dua table dikemaskini serentak
    $conn->begin_transaction();

    try {
        // --- BAHAGIAN 1: PENGURUSAN DATA LAMA ---
        // Padam butiran lama dalam budget_actual supaya tidak bertindih (Selesaikan isu Duplicate)
        $stmt_del = $conn->prepare("DELETE FROM programme_budget_actual WHERE report_id = ?");
        $stmt_del->bind_param("i", $report_id);
        $stmt_del->execute();

        // --- BAHAGIAN 2: PENGIRAAN & PENGISIAN DATA BARU ---
        $total_income = 0;
        $total_expense = 0;

        // SQL untuk masukkan butiran ke table budget_actual
        $sql_inc = "INSERT INTO programme_budget_actual (report_id, actualincome_name, actualincome_amt) VALUES (?, ?, ?)";
        $sql_exp = "INSERT INTO programme_budget_actual (report_id, actualexpense_name, actualexpense_amt) VALUES (?, ?, ?)";
        
        $stmt_inc = $conn->prepare($sql_inc);
        $stmt_exp = $conn->prepare($sql_exp);

        // Simpan setiap baris Pendapatan
        if (!empty($_POST['income_name'])) {
            foreach ($_POST['income_name'] as $key => $name) {
                if (trim($name) !== "") {
                    $amt = floatval($_POST['income_amt'][$key]);
                    $stmt_inc->bind_param("isd", $report_id, $name, $amt);
                    $stmt_inc->execute();
                    $total_income += $amt;
                }
            }
        }

        // Simpan setiap baris Perbelanjaan
        if (!empty($_POST['expense_name'])) {
            foreach ($_POST['expense_name'] as $key => $name) {
                if (trim($name) !== "") {
                    $amt = floatval($_POST['expense_amt'][$key]);
                    $stmt_exp->bind_param("isd", $report_id, $name, $amt);
                    $stmt_exp->execute();
                    $total_expense += $amt;
                }
            }
        }

        // --- BAHAGIAN 3: UPDATE TABLE REPORT ---
        // Kemaskini kolum prog_act_income dan prog_act_expenses
        $sql_update_report = "UPDATE programme_report 
                              SET prog_act_income = ?, prog_act_expenses = ? 
                              WHERE report_id = ?";
        $stmt_upd = $conn->prepare($sql_update_report);
        $stmt_upd->bind_param("ddi", $total_income, $total_expense, $report_id);
        $stmt_upd->execute();

        // Jika semua OK, simpan perubahan secara kekal
        $conn->commit();

        echo "<script>
                alert('Berjaya: Table Report dikemaskini & butiran bajet disimpan.');
                window.location.href = '5.0_programme_list.php';
              </script>";

    } catch (Exception $e) {
        // Jika ada error (seperti Duplicate Entry), batalkan semua perubahan
        $conn->rollback();
        die("Ralat Teknikal: " . $e->getMessage());
    }
} else {
    header("Location: 5.0_programme_list.php");
    exit();
}
?>