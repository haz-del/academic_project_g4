<?php 
session_start();
include '0.1_dbconnect.php';

// Ambil peranan user dari sesi
$user_role = $_SESSION['com_role'] ?? ''; 

// Mengambil semua tarikh program daripada pangkalan data
$events = [];
$query = mysqli_query($conn, "SELECT prog_name, prog_date FROM programme_proposal WHERE prog_status = 'Approved'");
while($row = mysqli_fetch_assoc($query)) {
    $events[] = [
        'title' => $row['prog_name'],
        'start' => $row['prog_date'],
        'color' => '#0061f2' 
    ];
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>Kalendar Aktiviti Kampung</title>
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/core@6.1.8/locales-all.global.min.js'></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root { --primary: #0061f2; --glass: rgba(255, 255, 255, 0.95); }
        body { font-family: 'Segoe UI', sans-serif; background: #f8fafc; margin: 0; transition: all 0.3s ease; }
        
        /* Logik Autocorrect Layout */
        .main-content { 
            margin-left: 260px; 
            padding: 100px 30px 30px 30px; 
            transition: all 0.3s ease-in-out; 
            min-height: 100vh;
        }

        /* Jika navbar disembunyikan (bergantung kepada class pada body) */
        body.sidebar-closed .main-content { margin-left: 0; }
        
        .glass-card { 
            background: var(--glass); 
            padding: 30px; 
            border-radius: 20px; 
            box-shadow: 0 8px 32px rgba(0,0,0,0.05); 
            border: 1px solid rgba(255,255,255,0.3);
            backdrop-filter: blur(10px);
        }

        .fc-toolbar-title { color: #1e293b; font-weight: 700; }
        .fc-button { background-color: var(--primary) !important; border: none !important; }
        
        @media (max-width: 768px) {
            .main-content { margin-left: 0; padding: 80px 15px 20px 15px; }
        }
    </style>
</head>
<body id="body-layout">

<?php 
// --- LOGIK PEMILIHAN NAVBAR MENGIKUT PERANAN ---
if ($user_role === 'Village Head') { 
    include '0.2_ketua_navbar.php'; 
} elseif ($user_role === 'Committee') { 
    include '0.3_committee_navbar.php'; // Navbar untuk AJK
} else { 
    include '0.4_guest_navbar.php';    // Navbar untuk Tetamu
} 
?>

<div class="main-content">
    <div class="glass-card">
        <h2 style="display: flex; align-items: center; gap: 10px; color: #1e293b; margin-bottom: 25px;">
            <i class='bx bx-calendar-event' style="color: var(--primary); font-size: 2rem;"></i>
            Jadual Aktiviti Tahunan
        </h2>
        
        <div id='calendar'></div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: 'ms', 
        buttonText: {
            today: 'Hari Ini',
            month: 'Bulan',
            week: 'Minggu',
            day: 'Hari',
            list: 'Senarai'
        },
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek'
        },
        events: <?php echo json_encode($events); ?>, 
        eventClick: function(info) {
            let tarikhStr = info.event.start.toLocaleDateString('ms-MY', { 
                day: 'numeric', month: 'long', year: 'numeric' 
            });
            alert('Aktiviti: ' + info.event.title + '\nTarikh: ' + tarikhStr);
        },
        handleWindowResize: true,
        height: 'auto'
    });
    calendar.render();

    // Logik toggle sidebar untuk autocorrect saiz kalendar
    const toggleBtn = document.querySelector('.header_toggle') || document.getElementById('header-toggle');
    const body = document.getElementById('body-layout');

    if(toggleBtn) {
        toggleBtn.addEventListener('click', () => {
            body.classList.toggle('sidebar-closed');
            setTimeout(() => { calendar.updateSize(); }, 350);
        });
    }
});
</script>

</body>
</html>