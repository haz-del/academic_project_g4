<?php 
session_start();
include '0.1_dbconnect.php';

$user_role = $_SESSION['com_role'] ?? ''; 
ini_set('display_errors', 1);
error_reporting(E_ALL);

/* ================= 1. FILTER LOGIK ================= */
$com_id = $_GET['com_id'] ?? 'all';
$year   = $_GET['year'] ?? date('Y');

// Bina klausa WHERE secara dinamik
$where = "WHERE YEAR(pr.prog_rep_submitted) = '$year'";
if ($com_id != 'all') {
    $where .= " AND pr.com_id = '" . mysqli_real_escape_string($conn, $com_id) . "'";
}

/* ================= 2. DATA KPI ================= */
$kpi_query = mysqli_query($conn, "SELECT COUNT(pr.report_id) AS total_programmes, IFNULL(SUM(pr.prog_act_participants), 0) AS total_participants FROM programme_report pr $where");
$kpi = mysqli_fetch_assoc($kpi_query);

/* ================= 3. DATA GRAF TREND (LINE) ================= */
$month_label = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
$month_data = array_fill(0, 12, 0);
$q1 = mysqli_query($conn, "SELECT MONTH(prog_rep_submitted) m, COUNT(*) total FROM programme_report pr $where GROUP BY m");
while($r = mysqli_fetch_assoc($q1)) { 
    $month_data[$r['m']-1] = $r['total']; 
}

/* ================= 4. DATA GRAF KATEGORI (PIE) ================= */
$cat_labels = []; $cat_counts = [];
$q2 = mysqli_query($conn, "SELECT pp.prog_category, COUNT(pr.report_id) as total FROM programme_report pr JOIN programme_proposal pp ON pr.proposal_id = pp.proposal_id $where GROUP BY pp.prog_category");
while($r = mysqli_fetch_assoc($q2)) { 
    $cat_labels[] = $r['prog_category'] ?? 'Tiada Kategori'; 
    $cat_counts[] = $r['total']; 
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analisis Aktiviti Program</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root { 
            --primary: #0061f2; 
            --secondary: #6900f2;
            --slate-500: #64748b;
            --slate-600: #475569;
        }

        body { 
            font-family: 'Inter', 'Segoe UI', sans-serif; 
            background: #f8fafc; 
            margin: 0; 
        }
        
        .main-content { 
            margin-left: 260px; 
            padding: 100px 30px 30px 30px; 
            transition: all 0.3s ease; 
        }

        .glass-card { 
            background: white; 
            padding: 30px; 
            border-radius: 20px; 
            box-shadow: 0 10px 25px rgba(0,0,0,0.05); 
            border: 1px solid #e2e8f0;
        }

        h2 { 
            color: #1e293b; 
            font-size: 1.5rem; 
            display: flex; 
            align-items: center; 
            gap: 10px;
            margin-bottom: 25px;
        }

        /* Filter Section Styling */
        .filter-section { 
            display: flex; 
            gap: 12px; 
            margin-bottom: 30px; 
            flex-wrap: wrap; 
            background: #f1f5f9;
            padding: 20px;
            border-radius: 12px;
            align-items: center;
        }

        .filter-section select, .filter-section input {
            padding: 10px 15px;
            border-radius: 8px;
            border: 1px solid #cbd5e1;
            background: white;
            outline: none;
        }

        .btn-tapis { 
            background: var(--primary); 
            color: white; 
            border: none; 
            cursor: pointer; 
            padding: 10px 25px; 
            border-radius: 8px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.3s;
        }

        .btn-tapis:hover { background: #004dc2; }

        .btn-reset {
            background: var(--slate-500);
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.3s;
        }

        .btn-reset:hover { background: var(--slate-600); }

        /* KPI Grid */
        .stats-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); 
            gap: 20px; 
            margin-bottom: 30px; 
        }

        .stat-card { 
            background: white; 
            padding: 25px; 
            border-radius: 15px; 
            border-left: 6px solid var(--primary); 
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
        }

        .stat-label { font-size: 0.85rem; color: var(--slate-500); font-weight: 600; text-transform: uppercase; }
        .stat-value { font-size: 2.2rem; font-weight: 800; color: #0f172a; margin-top: 5px; }

        /* Chart Layout */
        .chart-section { 
            display: grid; 
            grid-template-columns: 1fr 1.5fr; 
            gap: 20px; 
            margin-top: 20px; 
        }

        .chart-container {
            position: relative; 
            height: 400px; 
            width: 100%; 
            background: white;
            padding: 25px;
            border-radius: 15px;
            border: 1px solid #e2e8f0;
            box-sizing: border-box;
            overflow: hidden;
        }

        @media (max-width: 992px) { 
            .chart-section { grid-template-columns: 1fr; } 
            .main-content { margin-left: 0; padding-top: 80px; } 
        }
    </style>
</head>
<body>

<?php 
if ($user_role === 'Village Head') { include '0.2_ketua_navbar.php'; } 
else { include '0.3_committee_navbar.php'; } 
?>

<div class="main-content">
    <div class="glass-card">
        <h2><i class='bx bx-pie-chart-alt-2'></i> Analisis Aktiviti Program (<?= $year ?>)</h2>

        <form method="GET" action="" class="filter-section">
            <select name="com_id">
                <option value="all">Semua Jawatankuasa</option>
                <?php
                $c = mysqli_query($conn,"SELECT com_id, com_name FROM committee WHERE com_id != 1 ORDER BY com_name");
                while($r = mysqli_fetch_assoc($c)){
                    $sel = ($com_id == $r['com_id']) ? 'selected' : '';
                    echo "<option value='{$r['com_id']}' $sel>{$r['com_name']}</option>";
                }
                ?>
            </select>

            <input type="number" name="year" value="<?= $year ?>" style="width:120px;" placeholder="Tahun">

            <button type="submit" class="btn-tapis">
                <i class='bx bx-filter-alt'></i> Tapis
            </button>

            <a href="<?= strtok($_SERVER["REQUEST_URI"], '?'); ?>" class="btn-reset">
                <i class='bx bx-refresh'></i> Reset
            </a>
        </form>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label">JUMLAH PROGRAM</div>
                <div class="stat-value"><?= $kpi['total_programmes'] ?></div>
            </div>
            <div class="stat-card" style="border-left-color: var(--secondary);">
                <div class="stat-label">JUMLAH PENYERTAAN</div>
                <div class="stat-value"><?= number_format($kpi['total_participants']) ?></div>
            </div>
        </div>

        <div class="chart-section">
            <div class="chart-container">
                <canvas id="categoryChart"></canvas>
            </div>
            <div class="chart-container">
                <canvas id="trendChart"></canvas>
            </div>
        </div>
    </div>
</div>

<script>
// Tetapan Global Chart.js
Chart.defaults.font.family = "'Inter', sans-serif";
Chart.defaults.responsive = true;
Chart.defaults.maintainAspectRatio = false;

// --- GRAF PIE: KATEGORI ---
const categoryChart = new Chart(document.getElementById('categoryChart'), {
    type: 'pie',
    data: {
        labels: <?= json_encode($cat_labels) ?>,
        datasets: [{
            data: <?= json_encode($cat_counts) ?>,
            backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b', '#858796'],
            borderWidth: 2,
            borderColor: '#ffffff'
        }]
    },
    options: { 
        plugins: { 
            title: { 
                display: true, 
                text: 'Taburan Program Mengikut Kategori',
                font: { size: 16, weight: 'bold' },
                padding: { bottom: 20 }
            }, 
            legend: { position: 'bottom' } 
        } 
    }
});

// --- GRAF LINE: TREND BULANAN ---
const trendChart = new Chart(document.getElementById('trendChart'), {
    type: 'line',
    data: {
        labels: <?= json_encode($month_label) ?>,
        datasets: [{
            label: 'Bilangan Program',
            data: <?= json_encode($month_data) ?>,
            borderColor: '#0061f2',
            backgroundColor: 'rgba(0, 97, 242, 0.1)',
            fill: true,
            tension: 0.4,
            pointRadius: 5,
            pointHoverRadius: 7
        }]
    },
    options: { 
        plugins: { 
            title: { 
                display: true, 
                text: 'Trend Aktiviti Bulanan',
                font: { size: 16, weight: 'bold' },
                padding: { bottom: 20 }
            } 
        }, 
        scales: { 
            y: { 
                beginAtZero: true, 
                ticks: { stepSize: 1, color: '#94a3b8' },
                grid: { color: '#f1f5f9' }
            },
            x: {
                grid: { display: false },
                ticks: { color: '#64748b' }
            }
        } 
    }
});

// Penyelarasan saiz automatik (ResizeObserver)
const containers = document.querySelectorAll('.chart-container');
const resizeObserver = new ResizeObserver(() => {
    categoryChart.resize();
    trendChart.resize();
});
containers.forEach(container => resizeObserver.observe(container));
</script>

</body>
</html>