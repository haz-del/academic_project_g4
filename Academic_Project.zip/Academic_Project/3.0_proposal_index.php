<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include '0.1_dbconnect.php';

/* ======================
   Dashboard statistics
====================== */

// Total proposals
$totalProposal = $conn->query("SELECT COUNT(*) AS total FROM programme_proposal")->fetch_assoc()['total'];

// Draft
$draftProposal = $conn->query("SELECT COUNT(*) AS total FROM programme_proposal WHERE prog_status = 'Draft'")->fetch_assoc()['total'];

// Pending
$pendingProposal = $conn->query("SELECT COUNT(*) AS total FROM programme_proposal WHERE prog_status = 'Pending Approval'")->fetch_assoc()['total'];

// Approved
$approvedProposal = $conn->query("SELECT COUNT(*) AS total FROM programme_proposal WHERE prog_status = 'Approved'")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Proposal Dashboard</title>

<style>
body {
    font-family: Arial, sans-serif;
    background-color: #f4f6f8;
    margin: 0;
    padding: 0;
}

.header {
    background-color: #0d6efd;
    color: white;
    padding: 25px;
    text-align: center;
}

.container {
    width: 1000px;
    margin: 40px auto;
}

/* KPI CARDS */
.kpi-row {
    display: flex;
    gap: 20px;
    margin-bottom: 40px;
}

.kpi-card {
    flex: 1;
    background: white;
    padding: 25px;
    border-radius: 10px;
    text-align: center;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

.kpi-card h2 {
    margin: 0;
    font-size: 36px;
    color: #0d6efd;
}

.kpi-card p {
    margin-top: 10px;
    color: #6c757d;
    font-weight: bold;
}

/* MENU */
.menu {
    display: flex;
    gap: 20px;
}

.card {
    background: #ffffff;
    flex: 1;
    padding: 30px;
    border-radius: 10px;
    text-align: center;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

.card h3 {
    margin-bottom: 15px;
}

.card p {
    color: #6c757d;
    font-size: 14px;
    margin-bottom: 20px;
}

.card a {
    display: inline-block;
    padding: 10px 18px;
    background-color: #0d6efd;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-weight: bold;
}

.card a.secondary {
    background-color: #6c757d;
}

.card a:hover {
    opacity: 0.9;
}

.footer {
    text-align: center;
    margin-top: 60px;
    color: #6c757d;
}
</style>
</head>

<body>

<div class="header">
    <h1>Programme Proposal Dashboard</h1>
    <p>Village Programme Management System</p>
</div>

<div class="container">

    <!-- KPI SECTION -->
    <div class="kpi-row">
        <div class="kpi-card">
            <h2><?= $totalProposal ?></h2>
            <p>Total Proposals</p>
        </div>

        <div class="kpi-card">
            <h2><?= $draftProposal ?></h2>
            <p>Draft</p>
        </div>

        <div class="kpi-card">
            <h2><?= $pendingProposal ?></h2>
            <p>Pending Approval</p>
        </div>

        <div class="kpi-card">
            <h2><?= $approvedProposal ?></h2>
            <p>Approved</p>
        </div>
    </div>

    <!-- MAIN MENU -->
    <div class="menu">

        <div class="card">
            <h3>Create Programme Proposal</h3>
            <p>Create a new programme proposal manually or from guest request.</p>
            <a href="3.1_create_proposal.php">Create Proposal</a>
        </div>

        <div class="card">
            <h3>Programme Proposal List</h3>
            <p>View, edit and track proposal approval status.</p>
            <a href="3.3_proposal_list.php">View Proposal List</a>
        </div>

        <div class="card">
            <h3>Guest Activity Request</h3>
            <p>External guests submit activity requests for review.</p>
            <a href="3.6_guest_request.php" class="secondary">Guest Request</a>
        </div>

        <div class="card">
            <h3>Guest Request List</h3>
            <p>Review and convert guest requests into proposals.</p>
            <a href="3.9_guest_request_list.php" class="secondary">Request List</a>
        </div>

    </div>

</div>

<div class="footer">
    © Village Programme System
</div>

</body>
</html>






