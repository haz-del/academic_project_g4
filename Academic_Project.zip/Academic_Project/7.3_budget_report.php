<?php
session_start();
include './0.1_dbconnect.php';

/* Semakan Akses */
if (!isset($_SESSION['com_id'])) {
    header("Location: 2.0_login.php");
    exit();
}

/* Capture report_id from URL */
if (!isset($_GET['report_id'])) {
    die("Akses tidak sah.");
}
$report_id = intval($_GET['report_id']);
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Bajet Sebenar</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --text-dark: #1a2a3a;
        }

        body { 
            font-family: 'Segoe UI', sans-serif; 
            background: url('uploads/Bg/Background.jpg') no-repeat center fixed; 
            background-size: cover;
            margin: 0;
        }

        .main-content {
            margin-left: 260px; /* Melaras ikut sidebar */
            padding: 40px;
            padding-top: 100px;
            transition: 0.3s;
            display: flex;
            justify-content: center;
        }

        .container {
            width: 100%;
            max-width: 1100px;
            background: var(--glass-bg);
            padding: 35px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            border: 1px solid rgba(255, 255, 255, 0.5);
        }

        h2.main-title {
            color: var(--primary-blue);
            font-size: 1.8rem;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 10px;
            text-transform: uppercase;
        }

        .budget-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }

        .section-box {
            background: rgba(255, 255, 255, 0.6);
            padding: 20px;
            border-radius: 15px;
            border: 1px solid #ddd;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            border-bottom: 2px solid var(--primary-blue);
            padding-bottom: 10px;
        }

        .section-header h3 {
            margin: 0;
            font-size: 1.2rem;
            color: var(--text-dark);
        }

        .add-btn {
            background: var(--primary-blue);
            color: white;
            border: none;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            transition: 0.2s;
        }

        .add-btn:hover { transform: scale(1.1); background: #004dc2; }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
        }

        th {
            background: #f1f5f9;
            color: #333;
            padding: 10px;
            font-size: 0.85rem;
            text-align: left;
            border-bottom: 2px solid #ddd;
        }

        td {
            padding: 5px;
            border-bottom: 1px solid #eee;
        }

        input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 0.9rem;
            box-sizing: border-box;
        }

        .total-display {
            font-size: 1.1rem;
            font-weight: 800;
            color: var(--primary-blue);
            text-align: right;
            margin-top: 10px;
        }

        .controls {
            margin-top: 30px;
            display: flex;
            justify-content: flex-end;
            gap: 15px;
        }

        .btn {
            padding: 12px 30px;
            border-radius: 10px;
            border: none;
            font-weight: 700;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: 0.3s;
        }

        .btn-confirm { background: var(--primary-blue); color: white; }
        .btn-confirm:hover { background: #004dc2; transform: translateY(-2px); }
        .btn-clear { background: #64748b; color: white; }

        @media (max-width: 900px) {
            .main-content { margin-left: 0; }
            .budget-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<?php 
/* Logik Navibar Dinamik */
if (isset($_SESSION['com_role'])) {
    if ($_SESSION['com_role'] === 'Village Head') {
        include '0.2_ketua_navbar.php';
    } else {
        include '0.3_committee_navbar.php';
    }
}
?>

<div class="main-content">
    <div class="container">
        <h2 class="main-title"><i class='bx bx-calculator'></i> Laporan Bajet Sebenar (Actual)</h2>

        <form action="7.4_process_budget_report.php" method="POST">
            <input type="hidden" name="report_id" value="<?= $report_id; ?>">

            <div class="budget-grid">
                <div class="section-box">
                    <div class="section-header">
                        <h3><i class='bx bx-trending-up'></i> Pendapatan Sebenar</h3>
                        <button type="button" class="add-btn" onclick="addRow('income-tbody','income_name','income_amt','inc-total')">+</button>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th width="10%">No.</th>
                                <th>Sumber</th>
                                <th width="35%">Jumlah (RM)</th>
                            </tr>
                        </thead>
                        <tbody id="income-tbody">
                            <tr>
                                <td>1.</td>
                                <td><input type="text" name="income_name[]" placeholder="Contoh: Jualan Tiket" required></td>
                                <td><input type="number" step="0.01" name="income_amt[]" class="inc-total" oninput="updateTotals()" required></td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="total-display">Jumlah Pendapatan: RM <span id="display-inc">0.00</span></div>
                </div>

                <div class="section-box">
                    <div class="section-header">
                        <h3><i class='bx bx-trending-down'></i> Perbelanjaan Sebenar</h3>
                        <button type="button" class="add-btn" onclick="addRow('expense-tbody','expense_name','expense_amt','exp-total')">+</button>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th width="10%">No.</th>
                                <th>Item</th>
                                <th width="35%">Jumlah (RM)</th>
                            </tr>
                        </thead>
                        <tbody id="expense-tbody">
                            <tr>
                                <td>1.</td>
                                <td><input type="text" name="expense_name[]" placeholder="Contoh: Makanan" required></td>
                                <td><input type="number" step="0.01" name="expense_amt[]" class="exp-total" oninput="updateTotals()" required></td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="total-display">Jumlah Perbelanjaan: RM <span id="display-exp">0.00</span></div>
                </div>
            </div>

            <div class="controls">
                <button type="reset" class="btn btn-clear" onclick="setTimeout(updateTotals,10)"><i class='bx bx-refresh'></i> Kosongkan</button>
                <button type="submit" class="btn btn-confirm"><i class='bx bx-check-circle'></i> Sahkan Laporan</button>
            </div>
        </form>
    </div>
</div>

<script>
function addRow(tbodyId, nameAttr, amtAttr, amtClass) {
    const tbody = document.getElementById(tbodyId);
    const no = tbody.rows.length + 1;
    const row = tbody.insertRow();
    row.innerHTML = `
        <td>${no}.</td>
        <td><input type="text" name="${nameAttr}[]" required></td>
        <td><input type="number" step="0.01" name="${amtAttr}[]" class="${amtClass}" oninput="updateTotals()" required></td>
    `;
}

function updateTotals() {
    let inc = 0, exp = 0;
    document.querySelectorAll('.inc-total').forEach(i => inc += parseFloat(i.value) || 0);
    document.querySelectorAll('.exp-total').forEach(i => exp += parseFloat(i.value) || 0);
    document.getElementById('display-inc').innerText = inc.toLocaleString('en-US', {minimumFractionDigits: 2});
    document.getElementById('display-exp').innerText = exp.toLocaleString('en-US', {minimumFractionDigits: 2});
}
</script>

</body>
</html>