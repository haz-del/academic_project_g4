<?php 
session_start();
include "0.1_dbconnect.php";

// 1. Kawalan Akses
if (!isset($_SESSION['guest_id'])) {
    header("Location: 2.6_login_guest.php");
    exit();
}

$guest_id = $_SESSION['guest_id'];

/* ==========================================================
   PENGAMBILAN DATA TERBARU (Mencegah Undefined Key)
========================================================== */
$query = $conn->query("SELECT * FROM guest WHERE guest_id = '$guest_id'");
$db_data = $query->fetch_assoc();

// Kemaskini Session dengan data terbaru jika data DB dijumpai
if ($db_data) {
    $_SESSION['guest_name'] = $db_data['guest_name'];
    $_SESSION['guest_organisation'] = $db_data['guest_organisation'];
    $_SESSION['guest_org_type'] = $db_data['guest_org_type'];
    $_SESSION['guest_phone'] = $db_data['guest_phone'];
    $_SESSION['guest_email'] = $db_data['guest_email'];
    $_SESSION['guest_address'] = $db_data['guest_address'];
}

/* ==========================================================
   PROSES KEMASKINI PROFIL
========================================================== */
$error = "";
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['update'])) {

    $guestNewname = $conn->real_escape_string(trim($_POST['guest_new_name']));
    $guestNeworg  = $conn->real_escape_string(trim($_POST['guest_new_organisation']));
    $guestNewtype = $conn->real_escape_string(trim($_POST['guest_new_organisationtype']));
    $guestNewphone = $conn->real_escape_string(trim($_POST['guest_new_phone']));
    $guestNewemail = $conn->real_escape_string(trim($_POST['guest_new_email']));
    $guestNewadd   = $conn->real_escape_string(trim($_POST['guest_new_add']));

    if (empty($guestNewname) && empty($guestNewphone) && empty($guestNewemail)) {
        $error = "Nama, No. Telefon dan Emel wajib diisi.";
    } else {
        $sql = "UPDATE guest SET 
                guest_name = '$guestNewname',
                guest_organisation = '$guestNeworg',
                guest_org_type = '$guestNewtype',
                guest_phone = '$guestNewphone',
                guest_email = '$guestNewemail',
                guest_address = '$guestNewadd'
                WHERE guest_id = '$guest_id'";

        if ($conn->query($sql)) {
            $_SESSION['success_message'] = "Profil berjaya dikemaskini.";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        } else {
            $error = "Gagal mengemaskini: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kemas Kini Profil Tetamu | Sistem Kampung</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: var(--text-dark);
        }

        .main-content {
            margin-left: 260px;
            padding: 40px;
            padding-top: 110px;
            transition: all 0.3s ease;
        }

        #mySidebar.collapsed ~ .main-content { margin-left: 0; }

        .container { max-width: 850px; margin: auto; }

        .glass-card {
            background: var(--glass-bg);
            padding: 40px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid var(--border-color);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        h2 {
            font-size: 1.8rem;
            color: var(--primary-blue);
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 5px;
        }

        .subtitle { color: #718096; margin-bottom: 30px; font-size: 0.95rem; }

        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .form-group { display: flex; flex-direction: column; gap: 8px; margin-bottom: 15px; }
        .full-width { grid-column: span 2; }

        label { font-weight: 600; font-size: 0.85rem; color: #4a5568; text-transform: uppercase; letter-spacing: 0.5px; }

        input {
            padding: 12px 15px;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            font-size: 1rem;
            transition: 0.3s;
            background: white;
            width: 100%;
        }

        input:focus {
            outline: none;
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(0, 97, 242, 0.1);
        }

        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 25px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .success { background: #f0fff4; color: #2f855a; border: 1px solid #c6f6d5; }
        .error { background: #fff5f5; color: #c53030; border: 1px solid #fed7d7; }

        .btn-update {
            background: var(--primary-blue);
            color: white;
            padding: 14px;
            border: none;
            border-radius: 12px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
            margin-top: 20px;
            font-size: 1rem;
        }

        .btn-update:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0, 97, 242, 0.3); }

        @media (max-width: 768px) {
            .main-content { margin-left: 0; padding: 20px; padding-top: 100px; }
            .form-grid { grid-template-columns: 1fr; }
            .full-width { grid-column: span 1; }
        }
    </style>
</head>
<body>

<?php include '0.4_guest_navbar.php'; ?>

<div class="main-content">
    <div class="container">
        <div class="glass-card">
            <h2><i class='bx bxs-user-detail'></i> Kemas Kini Profil</h2>
            <p class="subtitle">Sila pastikan maklumat organisasi anda sentiasa dikemaskini.</p>

            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert success">
                    <i class='bx bxs-check-circle'></i> <?= $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert error">
                    <i class='bx bxs-error-circle'></i> <?= $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-grid">
                    <div class="form-group full-width">
                        <label>Nama Penuh Wakil</label>
                        <input type="text" name="guest_new_name" value="<?= htmlspecialchars($_SESSION['guest_name'] ?? ''); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Nama Organisasi</label>
                        <input type="text" name="guest_new_organisation" value="<?= htmlspecialchars($_SESSION['guest_organisation'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label>Jenis Organisasi</label>
                        <input type="text" name="guest_new_organisationtype" value="<?= htmlspecialchars($_SESSION['guest_org_type'] ?? ''); ?>" placeholder="Contoh: NGO / Swasta">
                    </div>

                    <div class="form-group">
                        <label>No. Telefon</label>
                        <input type="tel" name="guest_new_phone" value="<?= htmlspecialchars($_SESSION['guest_phone'] ?? ''); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Alamat Emel</label>
                        <input type="email" name="guest_new_email" value="<?= htmlspecialchars($_SESSION['guest_email'] ?? ''); ?>" required>
                    </div>

                    <div class="form-group full-width">
                        <label>Alamat Surat-menyurat</label>
                        <input type="text" name="guest_new_add" value="<?= htmlspecialchars($_SESSION['guest_address'] ?? ''); ?>">
                    </div>
                </div>

                <button type="submit" name="update" class="btn-update">
                    <i class='bx bx-save'></i> Simpan Perubahan Profil
                </button>
            </form>
        </div>
    </div>
</div>

</body>
</html>