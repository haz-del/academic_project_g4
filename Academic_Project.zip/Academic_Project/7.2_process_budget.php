<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '0.1_dbconnect.php';

/* -------------------------
   1. Get proposal_id
-------------------------- */
$proposal_id = $_GET['proposal_id'] ?? null;
if (!$proposal_id) {
    die("Error: No proposal ID provided.");
}

/* -------------------------
   2. Get form data (Arrays)
-------------------------- */
$income_names  = $_POST['income_name'] ?? [];
$income_amts   = $_POST['income_amt'] ?? [];
$expense_names = $_POST['expense_name'] ?? [];
$expense_amts  = $_POST['expense_amt'] ?? [];

// Variables to track totals
$total_income = 0;
$total_expense = 0;

/* -------------------------
   3. Process & Insert Items
-------------------------- */
$stmt_budget = $conn->prepare("INSERT INTO programme_budget (proposal_id, income_name, income_amt, expense_name, expense_amt) VALUES (?, ?, ?, ?, ?)");

// Insert Income Rows and Calculate Total
for ($i = 0; $i < count($income_names); $i++) {
    if (!empty($income_names[$i])) {
        $inc_name = $income_names[$i];
        $inc_amt  = (float)$income_amts[$i];
        $total_income += $inc_amt; // Add to total
        
        $exp_name_placeholder = ""; 
        $exp_amt_placeholder  = 0.00;
        
        $stmt_budget->bind_param("isdsd", $proposal_id, $inc_name, $inc_amt, $exp_name_placeholder, $exp_amt_placeholder);
        $stmt_budget->execute();
    }
}

// Insert Expense Rows and Calculate Total
for ($i = 0; $i < count($expense_names); $i++) {
    if (!empty($expense_names[$i])) {
        $exp_name = $expense_names[$i];
        $exp_amt  = (float)$expense_amts[$i];
        $total_expense += $exp_amt; // Add to total
        
        $inc_name_placeholder = "";
        $inc_amt_placeholder  = 0.00;
        
        $stmt_budget->bind_param("isdsd", $proposal_id, $inc_name_placeholder, $inc_amt_placeholder, $exp_name, $exp_amt);
        $stmt_budget->execute();
    }
}

/* -------------------------
   4. Update Proposal (Status + Totals)
-------------------------- */
// We update prog_status, prog_income_desc (total income), and prog_expense_desc (total expense)
$sql_update = "UPDATE programme_proposal 
               SET prog_status = 'Pending', 
                   prog_income_desc = ?, 
                   prog_expense_desc = ? 
               WHERE proposal_id = ?";

$stmt_update = $conn->prepare($sql_update);
// Note: Based on your schema, prog_income_desc is TEXT and prog_expense_desc is INT
// Adjusting bind types to match your schema image
$stmt_update->bind_param("sdi", $total_income, $total_expense, $proposal_id);

if ($stmt_update->execute()) {
    header("Location: 3.2_proposal_detail.php?id=$proposal_id");
    exit;
} else {
    echo "Error updating proposal: " . $conn->error;
}

$stmt_budget->close();
$stmt_update->close();
$conn->close();
?>