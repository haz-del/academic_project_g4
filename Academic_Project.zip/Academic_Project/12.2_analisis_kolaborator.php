<?php 
session_start();
include '0.1_dbconnect.php';

$user_role = $_SESSION['com_role'] ?? ''; 
ini_set('display_errors', 1);
error_reporting(E_ALL);

/* ================= 1. KAD KPI ================= */
// Jumlah Keseluruhan Kolaborator
$total_col_query = mysqli_query($conn, "SELECT COUNT(*) as total FROM collaborators");
$total_col = mysqli_fetch_assoc($total_col_query)['total'];

// Jumlah Dana Sumbangan Keseluruhan (RM)
$total_funds_query = mysqli_query($conn, "SELECT SUM(coll_amount) as total FROM collaboratorsproposal");
$total_funds = mysqli_fetch_assoc($total_funds_query)['total'] ?? 0;

/* ================= 2. DATA GRAF BAR: KOLABORATOR & JUMLAH PROGRAM ================= */
$col_names = [];
$prog_counts = [];
$q_col_prog = mysqli_query($conn, "
    SELECT c.coll_organisation_name, COUNT(cp.proposal_id) as total_prog
    FROM collaborators c
    LEFT JOIN collaboratorsproposal cp ON c.coll_id = cp.coll_id
    GROUP BY c.coll_id
    ORDER BY total_prog DESC
    LIMIT 10
");
while($r = mysqli_fetch_assoc($q_col_prog)) {
    $col_names[] = $r['coll_organisation_name'];
    $prog_counts[] = $r['total_prog'];
}

/* ================= 3. DATA GRAF PIE: JENIS ORGANISASI ================= */
$org_types = [];
$org_counts = [];
$q_org = mysqli_query($conn, "
    SELECT coll_organisation_type, COUNT(*) as qty 
    FROM collaborators 
    GROUP BY coll_organisation_type
");
while($r = mysqli_fetch_assoc($q_org)) {
    $org_types[] = $r['coll_organisation_type'] ?: 'Lain-lain';
    $org_counts[] = $r['qty'];
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>Analisis Kolaborator</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root { --primary: #0061f2; --info: #36b9cc; }
        body { font-family: 'Segoe UI', sans-serif; background: #f0f2f5; margin: 0; overflow-x: hidden; }
        
        .main-content { margin-left: 260px; padding: 100px 30px 30px 30px; transition: all 0.3s ease; }
        .sidebar.collapsed ~ .main-content { margin-left: 0; }
        
        .glass-card { background: white; padding: 25px; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
        
        /* KPI Cards */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 25px; border-radius: 12px; border-left: 5px solid var(--primary); box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        .stat-label { font-size: 0.85rem; color: #64748b; font-weight: 600; text-transform: uppercase; }
        .stat-value { font-size: 2rem; font-weight: 700; color: #1e293b; margin-top: 5px; }

        /* Chart Layout */
        .chart-section { display: grid; grid-template-columns: 1.5fr 1fr; gap: 20px; }
        .chart-container { 
            position: relative; height: 450px; width: 100%; background: white; 
            padding: 20px; border-radius: 12px; border: 1px solid #eee;
            box-sizing: border-box; overflow: hidden;
        }

        @media (max-width: 1100px) { .chart-section { grid-template-columns: 1fr; } }
    </style>
</head>
<body>

<?php 
if ($user_role === 'Village Head') { include '0.2_ketua_navbar.php'; } 
else { include '0.3_committee_navbar.php'; } 
?>

<div class="main-content">
    <div class="glass-card">
        <h2><i class='bx bxs-group'></i> Analisis Rakan Kolaborasi</h2>
        <br>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label">Jumlah Rakan Strategik</div>
                <div class="stat-value"><?= $total_col ?> Organisasi</div>
            </div>
            <div class="stat-card" style="border-left-color: var(--info);">
                <div class="stat-label">Jumlah Dana/Sumbangan Luar</div>
                <div class="stat-value">RM <?= number_format($total_funds, 2) ?></div>
            </div>
        </div>

        <div class="chart-section">
            <div class="chart-container">
                <canvas id="colBarChart"></canvas>
            </div>

            <div class="chart-container">
                <canvas id="colPieChart"></canvas>
            </div>
        </div>
    </div>
</div>

<script>
Chart.defaults.responsive = true;
Chart.defaults.maintainAspectRatio = false;

// --- GRAF BAR: KOLABORATOR VS PROGRAM ---
const ctxBar = document.getElementById('colBarChart').getContext('2d');
const colBarChart = new Chart(ctxBar, {
    type: 'bar',
    data: {
        labels: <?= json_encode($col_names) ?>,
        datasets: [{
            label: 'Bilangan Program Dilakukan Bersama',
            data: <?= json_encode($prog_counts) ?>,
            backgroundColor: 'rgba(0, 97, 242, 0.7)',
            borderColor: '#0061f2',
            borderWidth: 1
        }]
    },
    options: {
        indexAxis: 'y', // Menjadikan bar melintang untuk nama organisasi yang panjang
        plugins: { 
            title: { display: true, text: 'Top 10 Kolaborator Paling Aktif', font: {size: 16} },
            legend: { display: false }
        }
    }
});

// --- GRAF PIE: JENIS ORGANISASI ---
const ctxPie = document.getElementById('colPieChart').getContext('2d');
const colPieChart = new Chart(ctxPie, {
    type: 'pie',
    data: {
        labels: <?= json_encode($org_types) ?>,
        datasets: [{
            data: <?= json_encode($org_counts) ?>,
            backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b', '#858796']
        }]
    },
    options: {
        plugins: { 
            title: { display: true, text: 'Taburan Kolaborator Mengikut Jenis', font: {size: 16} },
            legend: { position: 'bottom' }
        }
    }
});

/* --- AUTO-RESIZE FIX --- */
const mainContent = document.querySelector('.main-content');
if (mainContent) {
    let resizeTimer;
    const observer = new ResizeObserver(() => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
            colBarChart.resize();
            colPieChart.resize();
        }, 350);
    });
    observer.observe(mainContent);
}
</script>

</body>
</html>