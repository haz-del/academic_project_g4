<?php 
require_once "0.1_dbconnect.php";
session_start(); 

$error_msg = "";
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $guest_username = trim($_POST['guest_username']);
    $guest_password = $_POST['guest_password'];
    
    if (empty($guest_username) || empty($guest_password)){
        $error_msg = "Both username and password are required.";
    } else {
        // Updated to Prepared Statements for security
        $stmt = $conn->prepare("SELECT * FROM guest WHERE guest_username = ?");
        $stmt->bind_param("s", $guest_username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1){
            $row = $result->fetch_assoc();
            if (password_verify($guest_password, $row['guest_password'])){
                $_SESSION['guest_id'] = $row['guest_id'];
                $_SESSION['guest_name'] = $row['guest_name'];
                $_SESSION['guest_username'] = $row['guest_username'];
                
                header("Location: 1.3_guest_dashboard.php");
                exit();
            } else {
                $error_msg = "Log in failed. Invalid password.";
            }
        } else {
            $error_msg = "Log in failed. Invalid username.";
        }
        $stmt->close();
    }
}
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guest Login - Interactive Theme</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        /* Blue overlay overlay */
        body::before {
            content: "";
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(240, 247, 255, 0.2); 
            z-index: -1;
        }

        .wrapper {
            background: var(--glass-bg);
            padding: 40px;
            width: 100%;
            max-width: 400px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid var(--border-color);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);
            text-align: center;
        }

        .wrapper h2 {
            color: var(--primary-blue);
            font-size: 1.8rem;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .wrapper p {
            color: #4a5568;
            margin-bottom: 30px;
            font-size: 0.9rem;
        }

        .input-group {
            position: relative;
            width: 100%;
            margin-bottom: 20px;
        }

        .input-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
            color: var(--primary-blue);
            z-index: 2;
        }

        .input-group input {
            width: 100%;
            padding: 14px 15px 14px 45px;
            border-radius: 10px;
            border: 1px solid #ddd;
            outline: none;
            background: #fff;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .input-group input:focus {
            border-color: var(--primary-blue);
            box-shadow: 0 0 8px rgba(0, 97, 242, 0.15);
        }

        .btn-login {
            width: 100%;
            padding: 14px;
            background: var(--primary-blue);
            border: none;
            border-radius: 10px;
            color: white;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }

        .btn-login:hover {
            background: #004ecb;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 97, 242, 0.3);
        }

        .error-message {
            background: #fee2e2;
            color: #dc2626;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 0.85rem;
            border: 1px solid #fecaca;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .bottom-nav {
            margin-top: 25px;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .bottom-nav a {
            color: var(--primary-blue);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
        }

        .bottom-nav a:hover {
            text-decoration: underline;
        }

        .register-text {
            font-size: 0.85rem;
            color: #666;
        }
    </style>
</head>
<body>

<div class="wrapper">
    <h2>Log Masuk Tetamu</h2>
    <p>Sila masukkan kredential anda</p>

    <?php if (!empty($error_msg)): ?>
        <div class="error-message">
            <i class='bx bx-error-circle'></i> <?= htmlspecialchars($error_msg) ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="#">
        <div class="input-group">
            <i class='bx bxs-user'></i>
            <input type="text" name="guest_username" placeholder="Nama Pengguna" required>
        </div>

        <div class="input-group">
            <i class='bx bxs-lock-alt'></i>
            <input type="password" name="guest_password" placeholder="Kata Laluan" required>
        </div>

        <button type="submit" class="btn-login">Masuk</button>
    </form>

    <div class="bottom-nav">
        <span class="register-text">Tiada Akaun ? 
            <a href="2.2_register_guest.php">Daftar Sini</a>
        </span>
        <a href="1.0_resident_homepage.php">← Kembali ke Halaman Utama</a>
    </div>
</div>

</body>
</html>