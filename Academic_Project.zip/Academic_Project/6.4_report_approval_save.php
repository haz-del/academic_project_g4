<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include '0.1_dbconnect.php';

$report_id = $_POST['report_id'] ?? null;
$status = $_POST['status'] ?? null;

if (!$report_id || !$status) {
    die("Invalid request");
}

// Update proposal status
$sql = "UPDATE programme_report
        SET prog_rep_status = ?
        WHERE report_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $status, $report_id);
$stmt->execute();

// Redirect back to approval page
header("Location: 6.3_report_approval.php");
exit;


