<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once "0.1_dbconnect.php";

/* BLOCK logged-in users from re-accessing login page */
if (isset($_SESSION['com_id'])) {
    if ($_SESSION['com_role'] === "Admin") {
        header("Location: 2.1_register_committee.php");
    } elseif ($_SESSION['com_role'] === "Village Head") {
        header("Location: 1.1_head_dashboard.php");
    } elseif ($_SESSION['com_role'] === "Exco") {
        header("Location: 1.2_committee_dashboard.php");
    }
    exit();
}

$error = "";
if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $username = trim($_POST['committee_username']);
    $password = trim($_POST['committee_password']);

    if ($username === "" || $password === "") {
        $error = "Both username and password are required.";
    } else {
        $stmt = $conn->prepare("SELECT * FROM committee WHERE com_username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['com_password'])) {
                if ($row['com_status'] !== 'Active') {
                    $error = "Employee inactive. Please contact administrator.";
                } else {
                    $_SESSION['com_id'] = $row['com_id'];
                    $_SESSION['com_role'] = $row['com_role'];
                    $_SESSION['com_passwordstatus'] = $row['com_passwordstatus'];
                    $_SESSION['com_name'] = $row['com_name'];
                    $_SESSION['com_username'] = $row['com_username'];

                    if ($row['com_role'] === "Admin") {
                        header("Location: 2.1_register_committee.php");
                    } elseif (($row['com_role'] === "Village Head" || $row['com_role'] === "Exco") && $row['com_passwordstatus'] === "Old") {
                        header("Location: 2.5_new_password.php");
                    } elseif ($row['com_role'] === "Village Head") {
                        header("Location: 1.1_head_dashboard.php");
                    } elseif ($row['com_role'] === "Exco") {
                        header("Location: 1.2_committee_dashboard.php");
                    } else {
                        $error = "Invalid role configuration.";
                    }
                    exit();
                }
            } else {
                $error = "Invalid password.";
            }
        } else {
            $error = "Invalid username.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log Masuk Jawatankuasa Kampung - Fixed Theme</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
        }

        * {
            box-sizing: border-box; /* Crucial: Keeps padding inside the box */
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        body::before {
            content: "";
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(240, 247, 255, 0.2); 
            z-index: -1;
        }

        .wrapper {
            background: var(--glass-bg);
            padding: 40px;
            width: 100%;
            max-width: 400px; /* Reduced slightly for a tighter look */
            border-radius: 20px;
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid var(--border-color);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);
            text-align: center;
        }

        .wrapper h2 {
            color: var(--primary-blue);
            font-size: 1.8rem;
            margin-bottom: 10px;
        }

        .wrapper p {
            color: #4a5568;
            margin-bottom: 30px;
            font-size: 0.9rem;
        }

        .input-group {
            position: relative;
            width: 100%;
            margin-bottom: 20px;
        }

        .input-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
            color: var(--primary-blue);
            z-index: 2;
        }

        .input-group input {
            width: 100%; /* Now stays inside because of box-sizing: border-box */
            padding: 14px 15px 14px 45px;
            border-radius: 10px;
            border: 1px solid #ddd;
            outline: none;
            background: #fff;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .input-group input:focus {
            border-color: var(--primary-blue);
            box-shadow: 0 0 8px rgba(0, 97, 242, 0.15);
        }

        .btn-login {
            width: 100%;
            padding: 14px;
            background: var(--primary-blue);
            border: none;
            border-radius: 10px;
            color: white;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }

        .btn-login:hover {
            background: #004ecb;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 97, 242, 0.3);
        }

        .error-message {
            background: #fee2e2;
            color: #dc2626;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 0.85rem;
            border: 1px solid #fecaca;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .back-link {
            display: inline-block;
            margin-top: 25px;
            color: var(--primary-blue);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
        }

        .back-link:hover { text-decoration: underline; }
    </style>
</head>
<body>

<div class="wrapper">
    <h2>Log Masuk Jawatan Kampung</h2>
    <p>Sila masukkan kredential anda</p>

    <?php if ($error): ?>
        <div class="error-message">
            <i class='bx bx-error-circle'></i> <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="input-group">
            <i class='bx bxs-user'></i>
            <input type="text" name="committee_username" placeholder="Nama Pengguna" required>
        </div>

        <div class="input-group">
            <i class='bx bxs-lock-alt'></i>
            <input type="password" name="committee_password" placeholder="Kata Laluan" required>
        </div>

        <button type="submit" class="btn-login">MASUK</button>
    </form>

    <a href="1.0_resident_homepage.php" class="back-link">← Kembali ke Halaman Utama</a>
</div>

</body>
</html>