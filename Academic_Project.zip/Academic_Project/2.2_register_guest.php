<?php 
session_start();
include "0.1_dbconnect.php";
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendaftaran Tetamu</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary: #0061f2;
            --secondary: #6900f2;
            --white: #ffffff;
        }

        /* Latar belakang bersih tanpa overlay gelap */
        html, body {
            height: 100%;
            margin: 0;
            overflow-x: hidden; 
            font-family: 'Segoe UI', sans-serif;
            background: url('uploads/Bg/Background.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
            box-sizing: border-box;
        }

        /* Glassmorphism dengan sedikit bayangan untuk keterbacaan tanpa menggelapkan BG */
        .wrapper {
            background: rgba(255, 255, 255, 0.9); /* Lebih legap sedikit supaya borang jelas */
            backdrop-filter: blur(10px);
            padding: 40px;
            border-radius: 25px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 500px;
            border: 1px solid rgba(255,255,255,0.5);
            position: relative;
        }

        h1 {
            color: #1e293b;
            font-size: 1.8rem;
            text-align: center;
            margin-bottom: 25px;
            font-weight: 700;
        }

        .section-title {
            font-size: 0.95rem;
            color: var(--secondary);
            margin-top: 20px;
            margin-bottom: 12px;
            border-bottom: 2px solid rgba(105, 0, 242, 0.1);
            padding-bottom: 5px;
            font-weight: 600;
            display: flex;
            align-items: center; gap: 8px;
        }

        .input-group { margin-bottom: 15px; }

        .input-group label {
            display: block;
            font-size: 0.85rem;
            color: #475569;
            margin-bottom: 5px;
            font-weight: 600;
        }

        .input-box {
            position: relative;
            display: flex;
            align-items: center;
        }

        .input-box i {
            position: absolute;
            left: 15px;
            color: var(--primary);
            font-size: 1.1rem;
        }

        .input-box input {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border-radius: 12px;
            border: 1px solid rgba(0,0,0,0.1);
            outline: none;
            transition: 0.3s;
            background: #ffffff;
        }

        .input-box input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(0, 97, 242, 0.1);
        }

        .btn-submit {
            width: 100%;
            padding: 14px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 20px;
            box-shadow: 0 4px 15px rgba(0, 97, 242, 0.2);
        }

        .btn-submit:hover {
            background: #004dc2;
            transform: translateY(-2px);
        }

        .btn-home {
            display: block;
            text-align: center;
            width: 100%;
            padding: 12px;
            background: rgba(100, 116, 139, 0.1);
            color: #475569;
            text-decoration: none;
            border-radius: 12px;
            font-size: 0.9rem;
            font-weight: 600;
            margin-top: 15px;
            transition: 0.3s;
            box-sizing: border-box;
        }

        .btn-home:hover {
            background: rgba(100, 116, 139, 0.2);
            color: #1e293b;
        }

        .alert {
            padding: 12px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 0.9rem;
            text-align: center;
            font-weight: 500;
        }
    </style>
</head>
<body>

<div class="wrapper">
    <form action="" method="POST">
        <h1><i class='bx bx-user-plus'></i> Daftar Tetamu</h1>

        <?php
        if ($_SERVER['REQUEST_METHOD'] == "POST"){
            $gname = mysqli_real_escape_string($conn, $_POST['gn']);
            $gphone = mysqli_real_escape_string($conn, $_POST['gp']);
            $gmail = mysqli_real_escape_string($conn, $_POST['ge']);
            $gorg = mysqli_real_escape_string($conn, $_POST['gorg']);
            $gorgt = mysqli_real_escape_string($conn, $_POST['gorgt']);
            $gadd = mysqli_real_escape_string($conn, $_POST['gadd']);
            $gun = mysqli_real_escape_string($conn, $_POST['gun']);
            $gpw = $_POST['gpw'];
            
            $hashedpassword = password_hash($gpw, PASSWORD_DEFAULT);
            
            $check_sql = "SELECT * FROM guest WHERE guest_phone='$gphone' OR guest_username='$gun'";
            $result = mysqli_query($conn, $check_sql);

            if (mysqli_num_rows($result) > 0) {
                echo "<div class='alert' style='background: #fee2e2; color: #b91c1c;'><i class='bx bx-error-circle'></i> No. Telefon atau Username sudah wujud.</div>";
            } else {
                $sql = "INSERT INTO `guest`(`guest_name`, `guest_organisation`, `guest_org_type`, `guest_phone`, `guest_email`, `guest_username`, `guest_address`, `guest_password`) 
                        VALUES ('$gname','$gorg','$gorgt','$gphone','$gmail','$gun','$gadd','$hashedpassword')";
                
                if(mysqli_query($conn, $sql)){
                    echo "<div class='alert' style='background: #dcfce7; color: #15803d;'><i class='bx bx-check-circle'></i> Berjaya! Sila log masuk sekarang.</div>";
                } else {
                    echo "<div class='alert' style='background: #fee2e2; color: #b91c1c;'>Ralat: " . mysqli_error($conn) . "</div>";
                }
            }
        }
        ?>

        <div class="section-title"><i class='bx bx-id-card'></i> Maklumat Peribadi</div>
        
        <div class="input-group">
            <label>Nama Penuh</label>
            <div class="input-box">
                <i class='bx bx-user'></i>
                <input type="text" name="gn" placeholder="Ahmad Ali" required>
            </div>
        </div>

        <div style="display: flex; gap: 10px;">
            <div class="input-group" style="flex: 1;">
                <label>No. Telefon</label>
                <div class="input-box">
                    <i class='bx bx-phone'></i>
                    <input type="number" name="gp" placeholder="6011..." required>
                </div>
            </div>
            <div class="input-group" style="flex: 1;">
                <label>E-mel</label>
                <div class="input-box">
                    <i class='bx bx-envelope'></i>
                    <input type="email" name="ge" placeholder="ali@mail.com" required>
                </div>
            </div>
        </div>

        <div class="input-group">
            <label>Organisasi & Jenis</label>
            <div style="display: flex; gap: 10px;">
                <div class="input-box" style="flex: 2;">
                    <i class='bx bx-buildings'></i>
                    <input type="text" name="gorg" placeholder="Nama Organisasi" required>
                </div>
                <div class="input-box" style="flex: 1;">
                    <input type="text" name="gorgt" placeholder="Jenis" style="padding-left: 15px;" required>
                </div>
            </div>
        </div>

        <div class="input-group">
            <label>Alamat Kediaman</label>
            <div class="input-box">
                <i class='bx bx-map'></i>
                <input type="text" name="gadd" placeholder="Alamat penuh" required>
            </div>
        </div>

        <div class="section-title"><i class='bx bx-lock-alt'></i> Akaun Log Masuk</div>

        <div style="display: flex; gap: 10px;">
            <div class="input-group" style="flex: 1;">
                <label>Username</label>
                <div class="input-box">
                    <i class='bx bx-at'></i>
                    <input type="text" name="gun" placeholder="ali123" required>
                </div>
            </div>
            <div class="input-group" style="flex: 1;">
                <label>Password</label>
                <div class="input-box">
                    <i class='bx bx-key'></i>
                    <input type="password" name="gpw" placeholder="********" required>
                </div>
            </div>
        </div>

        <button type="submit" name="submit" class="btn-submit">Sahkan Pendaftaran</button>
        
        <a href="1.0_resident_homepage.php" class="btn-home">
            <i class='bx bx-home-alt'></i> Kembali ke Laman Utama
        </a>
    </form>
</div>

</body>
</html>