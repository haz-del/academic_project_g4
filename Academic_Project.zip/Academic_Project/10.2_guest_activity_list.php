<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "0.1_dbconnect.php";

// Kawalan Akses
if (!isset($_SESSION['guest_id'])) {
    header("Location: 2.6_login_guest.php");
    exit();
}

$logged_in_guest_id = $_SESSION['guest_id'];

// Carian / Filter
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// Base SQL
$sql = "SELECT gr.*, g.guest_name, g.guest_organisation
        FROM guest_requests gr
        INNER JOIN guest g ON gr.guest_id = g.guest_id
        WHERE gr.guest_id = '$logged_in_guest_id'";

if (!empty($search)) {
    $sql .= " AND (gr.req_name LIKE '%$search%' 
              OR gr.req_category LIKE '%$search%'
              OR gr.req_venue LIKE '%$search%')";
}

$sql .= " ORDER BY gr.req_date DESC";

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Senarai Permohonan Saya | Sistem Kampung</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: var(--text-dark);
        }

        .main-content {
            margin-left: 260px;
            padding: 40px;
            padding-top: 110px;
            transition: all 0.3s ease;
        }

        #mySidebar.collapsed ~ .main-content { margin-left: 0; }

        .container { max-width: 1200px; margin: auto; }

        .glass-card {
            background: var(--glass-bg);
            padding: 30px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid var(--border-color);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        h2 {
            font-size: 1.8rem;
            color: var(--primary-blue);
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 25px;
        }

        /* Search Box */
        .search-container {
            margin-bottom: 25px;
            display: flex;
            gap: 10px;
        }

        .search-container input[type="text"] {
            flex: 1;
            padding: 12px 20px;
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            outline: none;
            font-size: 0.95rem;
        }

        .btn-search {
            background: var(--primary-blue);
            color: white;
            border: none;
            padding: 0 25px;
            border-radius: 12px;
            cursor: pointer;
            transition: 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
        }

        .btn-search:hover { background: #0052cc; }

        /* Table Styling */
        .table-wrapper {
            overflow-x: auto;
            border-radius: 12px;
            background: white;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
        }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #edf2f7;
            font-size: 0.9rem;
        }

        th {
            background: #f8fafc;
            color: #4a5568;
            font-weight: 700;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.05em;
        }

        tr:hover { background: #fdfdfd; }

        /* Status Badges */
        .badge {
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 700;
            display: inline-block;
        }
        .status-approve { background: #f0fff4; color: #2f855a; }
        .status-rejected { background: #fff5f5; color: #c53030; }
        .status-pending { background: #fffaf0; color: #c05621; }
        .status-returned { background: #ebf8ff; color: #2b6cb0; }

        .btn-view {
            color: var(--primary-blue);
            text-decoration: none;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .btn-view:hover { text-decoration: underline; }

        @media (max-width: 768px) {
            .main-content { margin-left: 0; padding: 20px; padding-top: 100px; }
        }
    </style>
</head>
<body>

<?php include '0.4_guest_navbar.php'; ?>

<div class="main-content">
    <div class="container">
        <div class="glass-card">
            <h2><i class='bx bx-list-check'></i> Senarai Permohonan Aktiviti Saya</h2>

            <form class="search-container" method="get">
                <input type="text" name="search" placeholder="Cari nama aktiviti, kategori atau lokasi..." value="<?= htmlspecialchars($search); ?>">
                <button type="submit" class="btn-search">
                    <i class='bx bx-search-alt'></i> Cari
                </button>
            </form>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama Aktiviti</th>
                            <th>Kategori</th>
                            <th>Lokasi</th>
                            <th>Tarikh & Masa</th>
                            <th>Peserta</th>
                            <th>Bajet (RM)</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && mysqli_num_rows($result) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($result)): 
                                $status = strtolower($row['request_status']);
                                $badgeClass = "status-" . $status;
                            ?>
                                <tr>
                                    <td><strong>#<?= $row['request_id']; ?></strong></td>
                                    <td><?= htmlspecialchars($row['req_name']); ?></td>
                                    <td><?= htmlspecialchars($row['req_category']); ?></td>
                                    <td><?= htmlspecialchars($row['req_venue']); ?></td>
                                    <td>
                                        <div style="font-size: 0.85rem;">
                                            <i class='bx bx-calendar'></i> <?= date('d/m/Y', strtotime($row['req_date'])); ?><br>
                                            <i class='bx bx-time'></i> <?= date('h:i A', strtotime($row['req_time'])); ?>
                                        </div>
                                    </td>
                                    <td><?= $row['req_est_participants']; ?></td>
                                    <td><strong><?= number_format((float)$row['req_est_budget'], 2); ?></strong></td>
                                    
                                    <td>
                                        <span class="badge <?= $badgeClass ?>">
                                            <?= ucfirst($row['request_status']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="9" style="text-align: center; padding: 40px; color: #a0aec0;">
                                    Tiada permohonan aktiviti dijumpai.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

</body>
</html>