<?php
session_start();
include "0.1_dbconnect.php";

// Kawalan Akses: Pastikan pengguna telah log masuk
if (!isset($_SESSION['com_id'])) {
    header("Location: 1.0_resident_homepage.php");
    exit();
}

/* ==========================================================
   PENGAMBILAN DATA TERBARU (Mencegah Ralat Undefined Key)
========================================================== */
$com_id = $_SESSION['com_id'];
$query = $conn->query("SELECT * FROM committee WHERE com_id = '$com_id'");
$db_data = $query->fetch_assoc();

// Kemaskini Session dengan data terbaru dari DB jika perlu
if ($db_data) {
    $_SESSION['com_name'] = $db_data['com_name'];
    $_SESSION['com_phone'] = $db_data['com_phone'];
    $_SESSION['com_email'] = $db_data['com_email'];
    $_SESSION['com_address'] = $db_data['com_address'];
}

/* ==========================================================
   PROSES KEMASKINI PROFIL
========================================================== */
if ($_SERVER['REQUEST_METHOD'] === "POST" && isset($_POST['update'])) {

    $comNewName  = $conn->real_escape_string(trim($_POST['com_new_name']));
    $comNewphone = $conn->real_escape_string(trim($_POST['com_new_phone']));
    $comNewemail = $conn->real_escape_string(trim($_POST['com_new_email']));
    $comNewadd   = $conn->real_escape_string(trim($_POST['com_new_add']));

    if (empty($comNewName) && empty($comNewphone) && empty($comNewemail) && empty($comNewadd)) {
        $_SESSION['error_message'] = "Sila isi sekurang-kurangnya satu medan untuk mengemas kini maklumat.";
    } else {
        // Jalankan kemaskini berdasarkan input yang tidak kosong
        if (!empty($comNewName)) {
            $conn->query("UPDATE committee SET com_name='$comNewName' WHERE com_id='$com_id'");
            $_SESSION['com_name'] = $comNewName;
        }
        if (!empty($comNewphone)) {
            $conn->query("UPDATE committee SET com_phone='$comNewphone' WHERE com_id='$com_id'");
            $_SESSION['com_phone'] = $comNewphone;
        }
        if (!empty($comNewemail)) {
            $conn->query("UPDATE committee SET com_email='$comNewemail' WHERE com_id='$com_id'");
            $_SESSION['com_email'] = $comNewemail;
        }
        if (!empty($comNewadd)) {
            $conn->query("UPDATE committee SET com_address='$comNewadd' WHERE com_id='$com_id'");
            $_SESSION['com_address'] = $comNewadd;
        }

        $_SESSION['success_message'] = "Profil berjaya dikemaskini.";
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kemas Kini Profil AJK</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: var(--text-dark);
        }

        .main-content {
            margin-left: 260px;
            padding: 40px;
            padding-top: 110px;
            transition: all 0.3s ease;
        }

        #mySidebar.collapsed ~ .main-content { margin-left: 0; }

        .container { max-width: 800px; margin: auto; }

        .glass-card {
            background: var(--glass-bg);
            padding: 40px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid var(--border-color);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        h2 {
            font-size: 1.8rem;
            color: var(--primary-blue);
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 5px;
        }

        .subtitle { color: #718096; margin-bottom: 30px; font-size: 0.95rem; }

        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .form-group { display: flex; flex-direction: column; gap: 8px; margin-bottom: 15px; }
        .full-width { grid-column: span 2; }

        label { font-weight: 600; font-size: 0.9rem; color: #4a5568; }

        input {
            padding: 12px 15px;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            font-size: 1rem;
            transition: 0.3s;
            background: white;
            width: 100%;
        }

        input:focus {
            outline: none;
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(0, 97, 242, 0.1);
        }

        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 25px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .success { background: #f0fff4; color: #2f855a; border: 1px solid #c6f6d5; }
        .error { background: #fff5f5; color: #c53030; border: 1px solid #fed7d7; }

        .btn-update {
            background: var(--primary-blue);
            color: white;
            padding: 14px;
            border: none;
            border-radius: 12px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
            margin-top: 20px;
        }

        .btn-update:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0, 97, 242, 0.3); }

        @media (max-width: 768px) {
            .main-content { margin-left: 0; padding: 20px; padding-top: 100px; }
            .form-grid { grid-template-columns: 1fr; }
            .full-width { grid-column: span 1; }
        }
    </style>
</head>
<body>

<?php
if ($_SESSION['com_role'] === 'Village Head') {
    include '0.2_ketua_navbar.php';
} else {
    include '0.3_committee_navbar.php';
}
?>

<div class="main-content">
    <div class="container">
        <div class="glass-card">
            <h2><i class='bx bxs-user-badge'></i> Profil Saya</h2>
            <p class="subtitle">Kemas kini maklumat peribadi anda di bawah.</p>

            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert success">
                    <i class='bx bxs-check-circle'></i> <?= $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert error">
                    <i class='bx bxs-error-circle'></i> <?= $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-grid">
                    <div class="form-group full-width">
                        <label>Nama Penuh</label>
                        <input type="text" name="com_new_name" value="<?= htmlspecialchars($_SESSION['com_name'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label>No. Telefon</label>
                        <input type="tel" name="com_new_phone" value="<?= htmlspecialchars($_SESSION['com_phone'] ?? ''); ?>" placeholder="Contoh: 0123456789">
                    </div>

                    <div class="form-group">
                        <label>Emel</label>
                        <input type="email" name="com_new_email" value="<?= htmlspecialchars($_SESSION['com_email'] ?? ''); ?>" placeholder="Contoh: user@email.com">
                    </div>

                    <div class="form-group full-width">
                        <label>Alamat Tetap</label>
                        <input type="text" name="com_new_add" value="<?= htmlspecialchars($_SESSION['com_address'] ?? ''); ?>" placeholder="Masukkan alamat lengkap">
                    </div>
                </div>

                <button type="submit" name="update" class="btn-update">
                    <i class='bx bx-save'></i> Simpan Perubahan
                </button>
            </form>
        </div>
    </div>
</div>

</body>
</html>