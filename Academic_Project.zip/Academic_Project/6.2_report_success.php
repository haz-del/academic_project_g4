<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Report Submitted Successfully</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f8;
            padding: 40px;
            text-align: center;
        }
        .box {
            background: #ffffff;
            padding: 40px;
            max-width: 600px;
            margin: auto;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            color: #28a745;
        }
        .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 18px;
            text-decoration: none;
            background-color: #007bff;
            color: #ffffff;
            border-radius: 4px;
            font-size: 14px;
        }
        .btn-back {
            background-color: #6c757d;
        }
    </style>
</head>
<body>

<div class="box">
    <h2>Programme Report Submitted Successfully ✅</h2>

    <p>Your programme report has been saved and submitted for approval.</p>

    <a href="6.0_approved_programme_list.php" class="btn">
        View Approved Programmes
    </a>

    <br><br>

    <a href="index.php" class="btn btn-back">
        ← Back to Home
    </a>
</div>

</body>
</html>
