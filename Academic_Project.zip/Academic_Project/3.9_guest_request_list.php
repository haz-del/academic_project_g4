<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '0.1_dbconnect.php';

/* ✅ Ambil data Filter dari URL */
$search = $_GET['search'] ?? "";
$status = $_GET['status'] ?? "";

/* ✅ Bina Query secara dinamik */
$sql = "SELECT * FROM guest_requests WHERE 1";

if ($search != "") {
    $sql .= " AND req_name LIKE '%" . $conn->real_escape_string($search) . "%'";
}

if ($status != "") {
    // Pastikan nama kolum ini sepadan dengan database anda (request_status)
    $sql .= " AND request_status = '" . $conn->real_escape_string($status) . "'";
}

$sql .= " ORDER BY request_id DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Senarai Permohonan Aktiviti Tetamu</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        /* ... Style asal anda ... */
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
            --sidebar-width: 260px;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body { 
            font-family: 'Segoe UI', Arial, sans-serif; 
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            min-height: 100vh;
        }

        .main-content {
            margin-left: var(--sidebar-width);
            padding: 40px;
            padding-top: 100px;
            transition: all 0.3s ease-in-out;
            min-height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: auto;
            background: var(--glass-bg);
            padding: 30px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            border: 1px solid var(--border-color);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        /* ✅ Style Tambahan untuk Filter Bar */
        .filter-bar {
            background: rgba(255,255,255,0.5);
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 25px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: flex-end;
            border: 1px solid #e2e8f0;
        }

        .filter-group { display: flex; flex-direction: column; gap: 5px; flex: 1; min-width: 200px; }
        
        .filter-group label { font-size: 12px; font-weight: 600; color: var(--text-dark); }

        .filter-control {
            padding: 10px 15px;
            border-radius: 8px;
            border: 1px solid #cbd5e1;
            font-size: 14px;
            outline: none;
        }

        .btn-filter { background: var(--primary-blue); color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-weight: 600; height: 41px; transition: 0.3s; }
        .btn-filter:hover { background: #004dc2; }
        
        .btn-reset { background: #64748b; color: white; text-decoration: none; padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 600; height: 41px; display: flex; align-items: center; }

        h2 { color: var(--primary-blue); margin-bottom: 25px; font-size: 1.8rem; display: flex; align-items: center; gap: 12px; }

        .table-responsive { overflow-x: auto; border-radius: 12px; }
        table { width: 100%; border-collapse: collapse; }
        th { background: rgba(0, 97, 242, 0.05); color: var(--primary-blue); padding: 15px; text-align: left; border-bottom: 2px solid #e2e8f0; }
        td { padding: 15px; border-bottom: 1px solid #f1f5f9; font-size: 14px; }

        .status-badge { padding: 4px 10px; border-radius: 6px; font-weight: bold; font-size: 12px; }
        .status-Pending { background: #fff3cd; color: #856404; }
        .status-Approved { background: #d4edda; color: #155724; }
        .status-Rejected { background: #f8d7da; color: #721c24; }

        .btn { padding: 8px 16px; border-radius: 8px; text-decoration: none; font-size: 13px; font-weight: 600; color: #fff; display: inline-flex; align-items: center; gap: 5px; transition: 0.3s; border: none; cursor: pointer; }
        .view { background: var(--primary-blue); }
        .accept { background: #10b981; }
        .reject { background: #ef4444; }

        .modal { display:none; position:fixed; z-index: 1000; top:0; left:0; width:100%; height:100%; background: rgba(0,0,0,0.4); backdrop-filter: blur(4px); }
        .modal-content { background: #fff; width: 400px; margin: 10% auto; padding: 30px; border-radius: 15px; }
        textarea { width:100%; padding: 12px; border-radius: 8px; border: 1px solid #cbd5e1; margin-bottom: 20px; }
    </style>
</head>

<body>

<?php
if (isset($_SESSION['com_role'])) {
    if ($_SESSION['com_role'] === 'Village Head') {
        include '0.2_ketua_navbar.php';
    } else {
        include '0.3_committee_navbar.php';
    }
} else {
    die('Unauthorized access');
}
?>

<div class="main-content">
    <div class="container">
        <h2><i class='bx bx-spreadsheet'></i> Senarai Permohonan Aktiviti Tetamu</h2>

        <form method="GET" action="" class="filter-bar">
            <div class="filter-group">
                <label>Cari Nama Program</label>
                <input type="text" name="search" class="filter-control" placeholder="Contoh: Gotong-royong" value="<?= htmlspecialchars($search) ?>">
            </div>

            <div class="filter-group">
                <label>Tapis Status</label>
                <select name="status" class="filter-control">
                    <option value="">Semua Status</option>
                    <option value="Pending" <?= $status == 'Pending' ? 'selected' : '' ?>>Pending</option>
                    <option value="Approved" <?= $status == 'Approved' ? 'selected' : '' ?>>Approved</option>
                    <option value="Rejected" <?= $status == 'Rejected' ? 'selected' : '' ?>>Rejected</option>
                </select>
            </div>

            <button type="submit" class="btn-filter">
                <i class='bx bx-filter-alt'></i> Tapis
            </button>
            
            <a href="3.9_guest_request_list.php" class="btn-reset">
                <i class='bx bx-refresh'></i> Reset
            </a>
        </form>

        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Nama Program</th>
                        <th>Tarikh Perlaksanaan</th>
                        <th>Status</th>
                        <th>Tindakan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td style="font-weight: 500;"><?= htmlspecialchars($row['req_name']); ?></td>
                                <td><?= htmlspecialchars($row['req_date']); ?></td>
                                <td>
                                    <span class="status-badge status-<?= $row['request_status']; ?>">
                                        <?= htmlspecialchars($row['request_status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <div style="display: flex; gap: 8px;">
                                        <a class="btn view" href="3.8_guest_request_detail.php?id=<?= $row['request_id']; ?>">
                                            <i class='bx bx-show'></i> Lihat
                                        </a>

                                        <?php if ($row['request_status'] === 'Pending'): ?>
                                            <button class="btn accept" onclick="openModal(<?= $row['request_id']; ?>, 'Approved')">
                                                <i class='bx bx-check'></i> Terima
                                            </button>
                                            <button class="btn reject" onclick="openModal(<?= $row['request_id']; ?>, 'Rejected')">
                                                <i class='bx bx-x'></i> Tolak
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="4" style="text-align:center; padding: 40px;">Tiada permohonan dijumpai.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal" id="commentModal">
    <div class="modal-content">
        <h3 id="modalTitle">Komen</h3>
        <form method="POST" action="3.11_request_status_comment.php">
            <input type="hidden" name="request_id" id="request_id">
            <input type="hidden" name="new_status" id="new_status">
            <textarea name="comment" rows="4" required placeholder="Nyatakan ulasan di sini..."></textarea>
            <div style="display: flex; gap: 10px; justify-content: flex-end;">
                <button type="button" class="btn" style="background: #94a3b8;" onclick="closeModal()">Batal</button>
                <button type="submit" class="btn accept">Hantar</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal(id, action) {
    document.getElementById("request_id").value = id;
    document.getElementById("new_status").value = action;
    document.getElementById("modalTitle").innerText = (action === 'Approved') ? 'Ulasan Kelulusan' : 'Ulasan Penolakan';
    document.getElementById("commentModal").style.display = "block";
}

function closeModal() {
    document.getElementById("commentModal").style.display = "none";
}
</script>

</body>
</html>