<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

<style>
    :root {
        --primary-blue: #0061f2;
        --sidebar-bg: #ffffff;
        --text-dark: #1a2a3a;
        --text-muted: #718096;
        --glass-white: rgba(255, 255, 255, 0.75);
        --hover-bg: rgba(0, 97, 242, 0.05);
        --transition-speed: 0.3s;
    }
    
    body {
        font-family: 'Segoe UI', Arial, sans-serif;
        background-image: url('uploads/Bg/Background.jpg'); 
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        min-height: 100vh;
    }

    /* --- TOPBAR DESIGN (KONSISTEN) --- */
    .topbar {
        position: fixed;
        top: 0; left: 0; width: 100%;
        height: 70px;
        background: var(--glass-white); 
        backdrop-filter: blur(15px) saturate(180%);
        -webkit-backdrop-filter: blur(15px) saturate(180%);
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 30px;
        z-index: 1001;
        box-shadow: 0 2px 15px rgba(0,0,0,0.02);
        border-bottom: 3px solid var(--primary-blue); /* Corak Aksen Biru */
        box-sizing: border-box;
    }

    .topbar-left { display: flex; align-items: center; gap: 20px; }

    .hamburger {
        font-size: 26px;
        cursor: pointer;
        color: var(--primary-blue);
        background: rgba(0, 97, 242, 0.1); 
        padding: 5px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        transition: var(--transition-speed);
    }

    .hamburger:hover { background: var(--primary-blue); color: white; }

    .topbar-title {
        font-size: 18px;
        font-weight: 800;
        color: var(--text-dark);
        letter-spacing: 1px;
        text-transform: uppercase;
        background: linear-gradient(45deg, var(--text-dark), var(--primary-blue));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    /* --- SIDEBAR STYLING --- */
    .sidebar {
        height: 100vh;
        width: 260px;
        position: fixed;
        top: 0; left: 0;
        background-color: var(--sidebar-bg);
        padding-top: 85px;
        transition: all var(--transition-speed) cubic-bezier(0.4, 0, 0.2, 1);
        z-index: 1000;
        border-right: 1px solid #edf2f7;
        overflow-x: hidden;
        white-space: nowrap;
    }

    .sidebar.collapsed { width: 0; border-right: none; }

    .sidebar a, .dropdown-btn {
        padding: 14px 25px;
        text-decoration: none;
        font-size: 14px;
        font-weight: 500;
        color: var(--text-muted);
        display: flex;
        align-items: center;
        width: 100%;
        border: none;
        background: none;
        cursor: pointer;
        transition: var(--transition-speed);
        border-radius: 10px;
        margin: 2px 0;
    }

    .sidebar i { font-size: 20px; min-width: 30px; }

    .sidebar a:hover, .dropdown-btn:hover {
        background-color: var(--hover-bg);
        color: var(--primary-blue);
    }

    /* Dropdown Styles */
    .dropdown-container {
        display: none;
        background-color: rgba(0, 97, 242, 0.02);
        margin: 0 15px;
        border-radius: 10px;
    }

    .dropdown-container a { padding-left: 55px; font-size: 13px; }

    .caret { margin-left: auto; transition: transform 0.3s; }
    .active .caret { transform: rotate(180deg); }

    /* Logout Style */
    .logout-btn { color: #e53e3e !important; margin-top: 20px !important; border-top: 1px solid #f7fafc !important; }
    .logout-btn:hover { background-color: #fff5f5 !important; }

    /* Overlay Mobile */
    .sidebar-overlay {
        display: none; position: fixed; top: 0; left: 0;
        width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 999;
    }

    @media (max-width: 768px) {
        .sidebar { left: -260px; width: 260px; }
        .sidebar.active { left: 0; }
        .sidebar-overlay.active { display: block; }
    }
</style>

<div class="topbar">
    <div class="topbar-left">
        <div class="hamburger" id="hamburger"><i class='bx bx-menu-alt-left'></i></div>
        <span class="topbar-title">Ketua Kampung</span>
    </div>
</div>

<div class="sidebar" id="mySidebar">
    <a href="1.1_head_dashboard.php">
        <i class='bx bxs-grid-alt'></i> <span>Laman Utama</span>
    </a>
    
    <button class="dropdown-btn">
        <i class='bx bxs-calendar-event'></i> <span>Aktiviti Kampung</span>
        <i class='bx bx-chevron-down caret'></i>
    </button>
    <div class="dropdown-container">
        <a href="5.0_programme_list.php">Senarai Program</a>
        <a href="3.1_create_proposal.php">Borang Kertas Kerja</a>
    </div>
    
    <a href="4.0_proposal_approval.php">
        <i class='bx bxs-badge-check'></i> <span>Kelulusan Kertas Kerja</span>
    </a>
    
   <button class="dropdown-btn">
        <i class='bx bxs-user'></i> <span>AJK</span>
        <i class='bx bx-chevron-down caret'></i>
    </button>
    <div class="dropdown-container">
        <a href="2.1_register_committee.php">Daftar AJK</a>
        <a href="8.0_committees_list.php">Senarai AJK</a>
    </div>
    
    
    <button class="dropdown-btn">
        <i class='bx bxs-user-detail'></i> <span>Tetamu</span>
        <i class='bx bx-chevron-down caret'></i>
    </button>
    <div class="dropdown-container">
        <a href="10.3_guest_list.php">Senarai Tetamu</a>
        <a href="3.9_guest_request_list.php">Permohonan Program</a>
    </div>
    
    <button class="dropdown-btn">
        <i class='bx bxs-file-blank'></i> <span>Laporan Program</span>
        <i class='bx bx-chevron-down caret'></i>
    </button>
    <div class="dropdown-container">
        <a href="6.3_report_approval.php">Kelulusan Laporan</a>
        <a href="6.6_report_list.php">Senarai Laporan</a>
    </div>

    <button class="dropdown-btn">
        <i class='bx bxs-group'></i> <span>Kolaborator</span>
        <i class='bx bx-chevron-down caret'></i>
    </button>
    <div class="dropdown-container">
        <a href="2.3_register_collaborators.php">Daftar Kolaborator</a>
        <a href="9.0_collaborators_list.php">Senarai Kolaborator</a>
        <a href="2.9_update_collaborators.php">Kemaskini Kolaborator</a>
    </div>

    <button class="dropdown-btn">
        <i class='bx bxs-bar-chart-alt-2'></i> <span>Analisis</span>
        <i class='bx bx-chevron-down caret'></i>
    </button>
    <div class="dropdown-container">
        <a href="12.0_analisis_program.php">Program</a>
        <a href="12.1_analisis_ajk.php">AJK</a>
        <a href="12.2_analisis_kolaborator.php">Kolaborator</a>
        <a href="12.3_analisis_kewangan.php">Kewangan</a>
    </div>
    
    <a href="11.0_logout.php" class="logout-btn">
        <i class='bx bx-log-out-circle'></i> <span>Log Keluar</span>
    </a>
</div>

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<script>
    const sidebar = document.getElementById("mySidebar");
    const hamburger = document.getElementById("hamburger");
    const overlay = document.getElementById("sidebarOverlay");

    // Sidebar Toggle Logic
    hamburger.addEventListener("click", function() {
        if (window.innerWidth > 768) {
            sidebar.classList.toggle("collapsed");
        } else {
            sidebar.classList.toggle("active");
            overlay.classList.toggle("active");
        }
    });

    overlay.addEventListener("click", function() {
        sidebar.classList.remove("active");
        overlay.classList.remove("active");
    });

    // Dropdown Logic
    var dropdowns = document.getElementsByClassName("dropdown-btn");
    for (var i = 0; i < dropdowns.length; i++) {
        dropdowns[i].addEventListener("click", function() {
            this.classList.toggle("active");
            var container = this.nextElementSibling;
            container.style.display = (container.style.display === "block") ? "none" : "block";
        });
    }
</script>