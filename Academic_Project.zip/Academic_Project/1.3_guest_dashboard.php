<?php 
session_start();
include '0.1_dbconnect.php';

// Pastikan tetamu telah log masuk
if (!isset($_SESSION['guest_id'])) {
    header("Location: 2.6_login_guest.php");
    exit();
}

$guest_id = $_SESSION['guest_id'];

/* ================= 1. PENGIRAAN KPI DARI DB ================= */

// Permintaan Menunggu Kelulusan
$q_pending = mysqli_query($conn, "SELECT COUNT(*) as total FROM guest_requests WHERE guest_id = '$guest_id' AND request_status = 'Pending'");
$total_pending = mysqli_fetch_assoc($q_pending)['total'];

// Permintaan Diluluskan
$q_approved = mysqli_query($conn, "SELECT COUNT(*) as total FROM guest_requests WHERE guest_id = '$guest_id' AND request_status = 'Approved'");
$total_approved = mysqli_fetch_assoc($q_approved)['total'];

// Program Turut Serta (Berdasarkan penglibatan guest dalam jadual guest)
// Nota: Mengikut ERD anda, guest_requests yang lulus biasanya akan menjadi program
$q_participated = mysqli_query($conn, "SELECT COUNT(*) as total FROM guest_requests WHERE guest_id = '$guest_id' AND request_status = 'Approved'");
$total_participated = mysqli_fetch_assoc($q_participated)['total'];

/* ================= 2. SISTEM NOTIFIKASI ================= */
// Mengambil 3 perkembangan terbaru permintaan tetamu
$notifications = mysqli_query($conn, "
    SELECT req_name, request_status, status_comment, approved_at 
    FROM guest_requests 
    WHERE guest_id = '$guest_id' 
    ORDER BY req_submitted DESC LIMIT 3
");
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Tetamu | Sistem Kampung</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.85);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
        }

        /* ... (Style sedia ada anda kekalkan) ... */

        .main-content { margin-left: 260px; padding: 40px; padding-top: 110px; transition: all 0.3s ease; }
        #mySidebar.collapsed ~ .main-content { margin-left: 0; }

        /* Notification Styling */
        .noti-card {
            background: var(--glass-bg);
            padding: 20px;
            border-radius: 15px;
            margin-top: 30px;
            border: 1px solid var(--border-color);
            backdrop-filter: blur(10px);
        }
        .noti-item {
            padding: 12px 0;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .noti-item:last-child { border: none; }
        .status-tag {
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
        }
        .tag-pending { background: #fff4e6; color: #f6ad55; }
        .tag-approved { background: #f0fff4; color: #68d391; }
        .tag-returned { background: #ebf8ff; color: #63b3ed; }

        /* KPI Style */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 25px; }
        .card { background: var(--glass-bg); padding: 30px; border-radius: 20px; border: 1px solid var(--border-color); box-shadow: 0 10px 30px rgba(0,0,0,0.08); display: flex; flex-direction: column; gap: 10px; }
        .card .value { font-size: 42px; font-weight: 800; color: var(--primary-blue); }
        /* Action Buttons Styling - Ikut Design Asal */
.action-section { 
    display: flex;
    gap: 20px;
    margin-bottom: 40px; 
    flex-wrap: wrap;
}

.action-btn { 
    padding: 12px 25px; 
    cursor: pointer; 
    border: 2px solid var(--primary-blue); /* Border biru tebal sedikit */
    border-radius: 15px; /* Lebih bulat ikut design asal */
    background: white;
    color: var(--primary-blue);
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 12px;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    box-shadow: 0 4px 15px rgba(0, 97, 242, 0.1);
    font-size: 16px;
    text-decoration: none;
}

.action-btn i {
    font-size: 1.4rem;
    padding: 0; /* Reset padding dari card style */
    background: none !important; /* Buang background kotak icon */
}

.action-btn:hover { 
    background: var(--primary-blue); 
    color: white;
    box-shadow: 0 8px 25px rgba(0, 97, 242, 0.3);
    transform: translateY(-3px);
}
    </style>
</head>
<body>

    <?php include '0.4_guest_navbar.php'; ?>

    <div class="main-content">
        
        <div class="header-section">
            <h2>Hi, <?php echo $_SESSION['guest_name'] ?? 'Tetamu'; ?> 👋</h2>
            <p class="subtitle">Berikut adalah ringkasan aktiviti anda.</p>
        </div>

        <div class="action-section">
    <button class="action-btn" onclick="location.href='3.6_guest_request.php'">
        <i class='bx bx-plus-circle'></i> 
        <span>Borang Permintaan Program</span>
    </button>
    
    <button class="action-btn" onclick="location.href='10.2_guest_activity_list.php'">
        <i class='bx bx-list-ul'></i> 
        <span>Senarai Permintaan Saya</span>
    </button>

    <button class="action-btn" onclick="location.href='12.4_kalendar_aktiviti.php'">
        <i class='bx bx-calendar'></i> 
        <span>Semak Kalendar</span>
    </button>
</div>

        <div class="stats-grid">
            <div class="card">
                <b>Permintaan Menunggu</b>
                <div style="display: flex; align-items: baseline; justify-content: space-between;">
                    <span class="value"><?php echo $total_pending; ?></span>
                    <i class='bx bx-loader-alt' style="background: #fff4e6; color: #f6ad55; padding: 10px; border-radius: 10px;"></i>
                </div>
            </div>

            <div class="card">
                <b>Permintaan Diluluskan</b>
                <div style="display: flex; align-items: baseline; justify-content: space-between;">
                    <span class="value"><?php echo $total_approved; ?></span>
                    <i class='bx bx-check-circle' style="background: #f0fff4; color: #68d391; padding: 10px; border-radius: 10px;"></i>
                </div>
            </div>

            <div class="card">
                <b>Program Turut Serta</b>
                <div style="display: flex; align-items: baseline; justify-content: space-between;">
                    <span class="value"><?php echo $total_participated; ?></span>
                    <i class='bx bx-run' style="background: #ebf8ff; color: #63b3ed; padding: 10px; border-radius: 10px;"></i>
                </div>
            </div>
        </div>

        <div class="noti-card">
            <h3 style="margin-bottom: 15px; font-size: 1.1rem;"><i class='bx bx-bell'></i> Notifikasi & Maklum Balas Terbaru</h3>
            <?php if(mysqli_num_rows($notifications) > 0): ?>
                <?php while($noti = mysqli_fetch_assoc($notifications)): ?>
                    <div class="noti-item">
                        <div style="flex: 1;">
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <strong style="font-size: 0.95rem;"><?php echo $noti['req_name']; ?></strong>
                                <span class="status-tag tag-<?php echo strtolower($noti['request_status']); ?>">
                                    <?php echo $noti['request_status']; ?>
                                </span>
                            </div>
                            <p style="font-size: 0.85rem; color: #718096; margin-top: 5px;">
                                <?php echo $noti['status_comment'] ?: 'Menunggu semakan daripada pihak pengurusan.'; ?>
                            </p>
                        </div>
                        <div style="font-size: 0.75rem; color: #a0aec0;">
                            <?php echo $noti['approved_at'] ? date('d M', strtotime($noti['approved_at'])) : 'Baru sahaja'; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p style="font-size: 0.9rem; color: #718096;">Tiada notifikasi setakat ini.</p>
            <?php endif; ?>
        </div>

    </div>

</body>
</html>