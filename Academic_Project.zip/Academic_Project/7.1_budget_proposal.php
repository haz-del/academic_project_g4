<!DOCTYPE html>
<?php 
session_start();
include './0.1_dbconnect.php'; 

// Menangkap proposal_id daripada URL
$proposal_id = $_GET['proposal_id'] ?? null;
?>

<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bajet Program</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
            --sidebar-width: 260px;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            min-height: 100vh;
            color: var(--text-dark);
        }

        /* --- LOGIK PELARASAN AUTOMATIK --- */
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 40px;
            padding-top: 100px;
            transition: all 0.3s ease-in-out;
        }

        /* Melaras jika sidebar ditutup (class 'close' atau 'collapsed') */
        #sidebar.close ~ .main-content,
        #mySidebar.collapsed ~ .main-content { 
            margin-left: 0; 
        }

        .main-header {
            max-width: 1200px;
            margin: 0 auto 25px auto;
            color: white;
            font-size: 1.8rem;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 12px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }

        /* --- GLASS CONTAINER --- */
        .container {
            width: 100%;
            max-width: 1200px;
            margin: auto;
            background: var(--glass-bg);
            padding: 35px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid var(--border-color);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .budget-grid {
            display: flex;
            gap: 30px;
            margin-bottom: 30px;
        }

        .section {
            flex: 1;
            min-width: 0;
        }

        .section-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e2e8f0;
        }

        .section-header h2 {
            font-size: 1.2rem;
            color: var(--primary-blue);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* --- TABLE STYLING --- */
        .table-wrapper {
            background: rgba(255,255,255,0.5);
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid #e2e8f0;
            margin-bottom: 15px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: rgba(0, 97, 242, 0.05);
            color: var(--primary-blue);
            padding: 12px 8px;
            font-size: 0.85rem;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }

        td {
            padding: 0;
            border-bottom: 1px solid #f1f5f9;
        }

        input {
            width: 100%;
            padding: 12px;
            border: none;
            background: transparent;
            font-size: 0.95rem;
            color: var(--text-dark);
        }

        input:focus {
            background: rgba(0, 97, 242, 0.05);
            outline: none;
        }

        .col-no { width: 45px; text-align: center; color: #64748b; font-size: 0.85rem; }
        .col-amt { width: 140px; }
        .col-action { width: 50px; text-align: center; }

        .total-row {
            background: #f8fafc;
            padding: 15px;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: bold;
            text-align: right;
            color: var(--primary-blue);
            border: 1px solid #e2e8f0;
        }

        /* --- BUTTONS --- */
        .add-btn {
            background: var(--primary-blue);
            color: white;
            border: none;
            border-radius: 6px;
            width: 28px;
            height: 28px;
            cursor: pointer;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: 0.2s;
        }

        .add-btn:hover { transform: scale(1.1); background: #004dc2; }

        .btn-remove {
            background: #fee2e2;
            color: #ef4444;
            border: none;
            border-radius: 6px;
            width: 30px;
            height: 30px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto;
            transition: 0.2s;
        }

        .btn-remove:hover { background: #fecaca; transform: scale(1.1); }

        .footer-controls {
            margin-top: 30px;
            display: flex;
            justify-content: flex-end;
            gap: 12px;
        }

        .btn {
            padding: 12px 30px;
            border-radius: 10px;
            border: none;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: 0.3s;
        }

        .btn-confirm { background: var(--primary-blue); color: white; }
        .btn-confirm:hover { box-shadow: 0 4px 12px rgba(0, 97, 242, 0.3); transform: translateY(-2px); }

        .btn-clear { background: #64748b; color: white; }
        .btn-clear:hover { background: #475569; }

        @media (max-width: 1024px) {
            .budget-grid { flex-direction: column; }
            .main-content { margin-left: 0; padding: 20px; padding-top: 80px; }
        }
    </style>
</head>
<body>

<?php
if (isset($_SESSION['com_role'])) {
    if ($_SESSION['com_role'] === 'Village Head') {
        include '0.2_ketua_navbar.php';
    } else {
        include '0.3_committee_navbar.php';
    }
} else {
    die('Unauthorized access');
}
?>

<div class="main-content">
    <div class="main-header">
        <i class='bx bx-calculator'></i> BAJET PROGRAM
    </div>

    <form action="7.2_process_budget.php?proposal_id=<?php echo htmlspecialchars($proposal_id); ?>" method="POST">
        <div class="container">
            <div class="budget-grid">
                
                <div class="section">
                    <div class="section-header">
                        <h2><i class='bx bx-trending-up'></i> Income Sources</h2>
                        <button type="button" class="add-btn" onclick="addRow('income-tbody', 'income_name', 'income_amt', 'inc-total')">+</button>
                    </div>
                    <div class="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th class="col-no">No.</th>
                                    <th>Income Source</th>
                                    <th class="col-amt">Amount (RM)</th>
                                    <th class="col-action"></th>
                                </tr>
                            </thead>
                            <tbody id="income-tbody">
                                <tr>
                                    <td class="col-no">1.</td>
                                    <td><input type="text" name="income_name[]" placeholder="Contoh: Peruntukan Khas"></td>
                                    <td><input type="number" step="0.01" name="income_amt[]" class="inc-total" oninput="updateTotals()" placeholder="0.00"></td>
                                    <td class="col-action"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="total-row">Total Income: RM <span id="display-inc">0.00</span></div>
                </div>

                <div class="section">
                    <div class="section-header">
                        <h2><i class='bx bx-trending-down'></i> Programme Expenses</h2>
                        <button type="button" class="add-btn" onclick="addRow('expense-tbody', 'expense_name', 'expense_amt', 'exp-total')">+</button>
                    </div>
                    <div class="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th class="col-no">No.</th>
                                    <th>Expense Item</th>
                                    <th class="col-amt">Amount (RM)</th>
                                    <th class="col-action"></th>
                                </tr>
                            </thead>
                            <tbody id="expense-tbody">
                                <tr>
                                    <td class="col-no">1.</td>
                                    <td><input type="text" name="expense_name[]" placeholder="Contoh: Jamuan Makan"></td>
                                    <td><input type="number" step="0.01" name="expense_amt[]" class="exp-total" oninput="updateTotals()" placeholder="0.00"></td>
                                    <td class="col-action"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="total-row">Total Expenses: RM <span id="display-exp">0.00</span></div>
                </div>

            </div>

            <div class="footer-controls">
                <button type="reset" class="btn btn-clear" onclick="setTimeout(updateTotals, 10)">
                    <i class='bx bx-refresh'></i> Clear All
                </button>
                <button type="submit" class="btn btn-confirm">
                    <i class='bx bx-check-circle'></i> Confirm Budget
                </button>
            </div>
        </div>
    </form>
</div>

<script>
    /**
     * Menambah baris baharu ke dalam jadual
     */
    function addRow(tbodyId, nameAttr, amtAttr, amtClass) {
        const tbody = document.getElementById(tbodyId);
        const nextNo = tbody.rows.length + 1;
        const newRow = tbody.insertRow();

        newRow.innerHTML = `
            <td class="col-no">${nextNo}.</td>
            <td><input type="text" name="${nameAttr}[]"></td>
            <td><input type="number" step="0.01" name="${amtAttr}[]" class="${amtClass}" oninput="updateTotals()" placeholder="0.00"></td>
            <td class="col-action">
                <button type="button" class="btn-remove" onclick="removeRow(this, '${tbodyId}')">
                    <i class='bx bx-trash'></i>
                </button>
            </td>
        `;
    }

    /**
     * Membuang baris dan menyusun semula nombor turutan
     */
    function removeRow(btn, tbodyId) {
        const row = btn.parentNode.parentNode;
        row.parentNode.removeChild(row);
        
        // Susun semula nombor giliran (1, 2, 3...)
        const tbody = document.getElementById(tbodyId);
        Array.from(tbody.rows).forEach((tr, index) => {
            tr.querySelector('.col-no').innerText = (index + 1) + ".";
        });

        // Kira semula jumlah
        updateTotals();
    }

    /**
     * Mengira jumlah keseluruhan Income dan Expenses secara dinamik
     */
    function updateTotals() {
        let totalInc = 0;
        let totalExp = 0;

        document.querySelectorAll('.inc-total').forEach(input => {
            totalInc += parseFloat(input.value) || 0;
        });

        document.querySelectorAll('.exp-total').forEach(input => {
            totalExp += parseFloat(input.value) || 0;
        });

        document.getElementById('display-inc').innerText = totalInc.toFixed(2);
        document.getElementById('display-exp').innerText = totalExp.toFixed(2);
    }
</script>
</body>
</html>