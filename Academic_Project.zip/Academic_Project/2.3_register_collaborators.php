<?php 
session_start();
include "0.1_dbconnect.php";

if (!isset($_SESSION['com_id'])) {
    header("Location: 1.0_resident_homepage.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Kolaborator</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
            --sidebar-width: 260px; /* Laraskan mengikut lebar sebenar sidebar anda */
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body { 
            font-family: 'Segoe UI', Arial, sans-serif; 
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            min-height: 100vh;
        }

        /* LOGIK PELARASAN AUTOMATIK */
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 40px;
            padding-top: 100px;
            transition: all 0.3s ease-in-out;
            min-height: 100vh;
        }

        /* Kesan apabila sidebar disembunyikan (class 'close' atau 'collapsed') */
        #sidebar.close ~ .main-content,
        #mySidebar.collapsed ~ .main-content { 
            margin-left: 0; 
        }

        /* GLASS CONTAINER */
        .container {
            width: 100%;
            max-width: 800px;
            margin: auto;
            background: var(--glass-bg);
            padding: 40px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid var(--border-color);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        h1 { 
            color: var(--primary-blue); 
            margin-bottom: 30px; 
            font-size: 1.8rem; 
            display: flex; 
            align-items: center; 
            gap: 12px;
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 15px;
        }

        .input-box {
            margin-bottom: 20px;
        }

        .input-box label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--text-dark);
        }

        .input-box input {
            width: 100%;
            padding: 12px 15px;
            border-radius: 10px;
            border: 1px solid #cbd5e1;
            background: rgba(255, 255, 255, 0.8);
            font-size: 14px;
            transition: 0.3s;
        }

        .input-box input:focus {
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(0, 97, 242, 0.1);
            outline: none;
        }

        .registration-date {
            font-size: 13px;
            color: #64748b;
            margin-top: 10px;
            font-style: italic;
        }

        .btn-submit {
            background: var(--primary-blue);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            font-size: 16px;
            width: 100%;
            transition: 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .btn-submit:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 97, 242, 0.2);
        }

        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .alert-error { background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca; }
        .alert-success { background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; }

        @media (max-width: 768px) {
            .main-content { margin-left: 0; padding: 20px; padding-top: 80px; }
        }
    </style>
</head>
<body>

<?php
if (isset($_SESSION['com_role'])) {
    if ($_SESSION['com_role'] === 'Village Head') {
        include '0.2_ketua_navbar.php';
    } else {
        include '0.3_committee_navbar.php';
    }
} else {
    die('Unauthorized access');
}
?>

<div class="main-content">
    <div class="container">
        <h1><i class='bx bx-user-plus'></i> Daftar Kolaborator</h1>

        <?php
        if ($_SERVER['REQUEST_METHOD'] == "POST") {
            $oname = mysqli_real_escape_string($conn, $_POST['on']);
            $otype = mysqli_real_escape_string($conn, $_POST['ot']);
            $opic = mysqli_real_escape_string($conn, $_POST['pic']);
            $opicphone = mysqli_real_escape_string($conn, $_POST['picp']);
            $oemail = mysqli_real_escape_string($conn, $_POST['oe']);
            $oaddress = mysqli_real_escape_string($conn, $_POST['oadd']);
            $creator_id = $_SESSION['com_id']; 

            $check_sql = "SELECT * FROM collaborators WHERE coll_phone='$opicphone'";
            $result = mysqli_query($conn, $check_sql);

            if (mysqli_num_rows($result) > 0) {
                echo "<div class='alert alert-error'><i class='bx bx-error-circle'></i> Nombor telefon ini telah didaftarkan.</div>";
            } else {
                $sql = "INSERT INTO `collaborators`(`coll_id`, `com_id`, `coll_organisation_name`, `coll_organisation_type`, `coll_contact_person`, `coll_phone`, `coll_email`, `coll_address`, `coll_date_created`) 
                        VALUES (NULL,'$creator_id','$oname','$otype','$opic','$opicphone','$oemail','$oaddress','" . date('Y-m-d H:i:s') . "')";
                
                if (mysqli_query($conn, $sql)) {
                    $id = mysqli_insert_id($conn);
                    echo "<div class='alert alert-success'><i class='bx bx-check-circle'></i> Rekod berjaya didaftarkan. (ID: $id)</div>";
                } else {
                    echo "<div class='alert alert-error'>Ralat: " . mysqli_error($conn) . "</div>";
                }
            }
        }
        ?>

        <form action="" method="POST">
            <div class="input-box">
                <label for="on">Nama Organisasi</label>
                <input type="text" id="on" name="on" placeholder="Contoh: Koperasi Kampung Jaya" required>
            </div>

            <div class="input-box">
                <label for="ot">Jenis Organisasi</label>
                <input type="text" id="ot" name="ot" placeholder="Contoh: NGO / Kerajaan / Swasta" required>
            </div>

            <div class="input-box">
                <label for="pic">Pegawai Penyelaras (PIC)</label>
                <input type="text" id="pic" name="pic" placeholder="Nama penuh pegawai" required>
            </div>

            <div class="input-box">
                <label for="picp">No. Telefon</label>
                <input type="text" id="picp" name="picp" placeholder="Contoh: 0123456789" required>
            </div>

            <div class="input-box">
                <label for="oe">Emel Pegawai/Organisasi</label>
                <input type="email" id="oe" name="oe" placeholder="emel@organisasi.com" required>
            </div>

            <div class="input-box">
                <label for="oadd">Alamat Organisasi</label>
                <input type="text" id="oadd" name="oadd" placeholder="Alamat lengkap organisasi" required>
            </div>

            <div class="registration-date">
                <i class='bx bx-calendar-event'></i> Tarikh Daftar: <?php echo date("d/m/Y H:i:s"); ?>
            </div>
            
            <br>
            <button type="submit" name="submit" class="btn-submit">
                <i class='bx bx-save'></i> Daftar Kolaborator
            </button>
        </form>
    </div>
</div>

</body>
</html>