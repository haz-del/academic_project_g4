<?php 
session_start();
include "0.1_dbconnect.php";

// Pastikan hanya pengguna yang sudah log masuk boleh akses
if (!isset($_SESSION['com_id'])) {
    header("Location: 2.0_login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Pengurusan | Kemaskini Kata Laluan</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.95);
            --text-dark: #1a2a3a;
        }

        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f2f5;
            background-image: url('uploads/Bg/Background.jpg'); /* Pastikan path imej betul */
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .container { 
            background: var(--glass-bg); 
            padding: 40px; 
            border-radius: 20px; 
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 420px;
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.5);
        }

        h1 { 
            color: var(--primary-blue); 
            text-align: center; 
            font-size: 1.6rem;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }

        .input-group { margin-bottom: 18px; }
        
        .input-group label { 
            display: block; 
            font-weight: 600; 
            margin-bottom: 8px; 
            color: var(--text-dark);
            font-size: 0.85rem;
        }

        .input-wrapper { 
            position: relative; 
            display: flex; 
            align-items: center; 
        }

        .input-wrapper input {
            width: 100%;
            padding: 12px 45px 12px 15px;
            border: 1px solid #d1d5db;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .input-wrapper input:focus {
            border-color: var(--primary-blue);
            outline: none;
            box-shadow: 0 0 0 3px rgba(0, 97, 242, 0.15);
        }

        .toggle-pwd {
            position: absolute;
            right: 15px;
            cursor: pointer;
            color: #6b7280;
            font-size: 1.3rem;
            z-index: 10;
        }

        .btn-update {
            background: var(--primary-blue);
            color: white;
            width: 100%;
            padding: 13px;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-update:hover { 
            background: #004dc2; 
            transform: translateY(-2px); 
            box-shadow: 0 5px 15px rgba(0, 97, 242, 0.3);
        }

        .alert {
            padding: 12px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 0.9rem;
            text-align: center;
            font-weight: 500;
        }
        .error { 
            background: #fee2e2; 
            color: #991b1b; 
            border: 1px solid #fecaca; 
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            text-decoration: none;
            color: #6b7280;
            font-size: 0.85rem;
            transition: 0.3s;
        }
        
        .back-link:hover { color: var(--primary-blue); }
    </style>
</head>
<body>

<div class="container">
    <h1><i class='bx bx-shield-quarter'></i> Kemaskini Password</h1>

    <?php
    if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['submit'])) {
        $oldpassword = $_POST['old_password'];
        $newpassword = $_POST['new_password'];
        $confirmpassword = $_POST['confirm_password'];

        if (empty($oldpassword) || empty($newpassword) || empty($confirmpassword)) {
            echo "<div class='alert error'>Sila isi semua ruangan.</div>";
        } elseif ($newpassword !== $confirmpassword) {
            echo "<div class='alert error'>Kata laluan baharu tidak sepadan.</div>";
        } else {
            // Ambil hash password lama dari DB
            $com_id = $_SESSION['com_id'];
            $sql_fetch = "SELECT com_password FROM committee WHERE com_id = '$com_id'";
            $result_fetch = mysqli_query($conn, $sql_fetch);

            if ($result_fetch && mysqli_num_rows($result_fetch) > 0) {
                $row = mysqli_fetch_assoc($result_fetch);
                
                // Sahkan password lama
                if (password_verify($oldpassword, $row['com_password'])) {
                    $hashedPassword = password_hash($newpassword, PASSWORD_DEFAULT);
                    
                    // Update ke password baharu dan tukar status kepada 'New'
                    $sql_update = "UPDATE committee SET com_password = '$hashedPassword', com_passwordstatus = 'New' WHERE com_id = '$com_id'";
                    
                    if (mysqli_query($conn, $sql_update)) {
                        // JAVASCRIPT REDIRECT KE DASHBOARD
                        echo "<script>
                                alert('Tahniah! Kata laluan berjaya ditukar. Menuju ke Dashboard...');
                                window.location.href='1.1_head_dashboard.php';
                              </script>";
                        exit();
                    } else {
                        echo "<div class='alert error'>Ralat pangkalan data: " . mysqli_error($conn) . "</div>";
                    }
                } else {
                    echo "<div class='alert error'>Kata laluan lama anda tidak sah.</div>";
                }
            } else {
                echo "<div class='alert error'>Akaun tidak ditemui.</div>";
            }
        }
    }
    ?>

    <form action="" method="POST">
        <div class="input-group">
            <label>Kata Laluan Asal</label>
            <div class="input-wrapper">
                <input type="password" name="old_password" id="old_pw" required placeholder="Masukkan kata laluan lama">
                <i class='bx bx-hide toggle-pwd' onclick="toggle('old_pw', this)"></i>
            </div>
        </div>

        <div class="input-group">
            <label>Kata Laluan Baharu</label>
            <div class="input-wrapper">
                <input type="password" name="new_password" id="new_pw" required placeholder="Minima 6 aksara">
                <i class='bx bx-hide toggle-pwd' onclick="toggle('new_pw', this)"></i>
            </div>
        </div>

        <div class="input-group">
            <label>Sahkan Kata Laluan Baharu</label>
            <div class="input-wrapper">
                <input type="password" name="confirm_password" id="conf_pw" required placeholder="Ulang kata laluan baharu">
                <i class='bx bx-hide toggle-pwd' onclick="toggle('conf_pw', this)"></i>
            </div>
        </div>

        <button type="submit" name="submit" class="btn-update">
            <i class='bx bx-check-shield'></i> Simpan & Ke Dashboard
        </button>
    </form>

    <a href="1.1_head_dashboard.php" class="back-link"><i class='bx bx-chevron-left'></i> Kembali ke Laman Utama</a>
</div>

<script>
    // Fungsi untuk tukar nampak/tutup kata laluan
    function toggle(inputId, icon) {
        const inputField = document.getElementById(inputId);
        if (inputField.type === "password") {
            inputField.type = "text";
            icon.classList.replace('bx-hide', 'bx-show');
        } else {
            inputField.type = "password";
            icon.classList.replace('bx-show', 'bx-hide');
        }
    }
</script>

</body>
</html>