<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once "0.1_dbconnect.php";

// Secured Search Filter
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// Base SQL
$sql = "SELECT guest_id, guest_name, guest_organisation, guest_org_type, guest_phone, guest_email, guest_address 
        FROM guest";

if(!empty($search)) {
    $sql .= " WHERE guest_name LIKE '%$search%' OR guest_organisation LIKE '%$search%'";
}

$sql .= " ORDER BY guest_name ASC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Senarai Tetamu</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
            --sidebar-width: 260px;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body { 
            font-family: 'Segoe UI', Arial, sans-serif; 
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* DYNAMIC LAYOUT LOGIC */
        .main-content {
            /* This margin matches the sidebar width */
            margin-left: var(--sidebar-width); 
            padding: 40px;
            padding-top: 100px;
            transition: all 0.3s ease-in-out;
            min-height: 100vh;
        }

        /* This is the magic part: 
           If the sidebar (which is inside the navbar file) has the class 'close' or 'collapsed',
           we tell the main-content sibling to take up the full width.
        */
        #sidebar.close ~ .main-content,
        #mySidebar.collapsed ~ .main-content,
        .sidebar-hidden .main-content { 
            margin-left: 0; 
        }

        /* GLASS CONTAINER */
        .container {
            width: 100%;
            max-width: 1200px;
            margin: auto;
            background: var(--glass-bg);
            padding: 30px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid var(--border-color);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        h2 { color: var(--primary-blue); margin-bottom: 25px; font-size: 1.8rem; display: flex; align-items: center; gap: 12px; }

        /* SEARCH SECTION */
        .search-container {
            margin-bottom: 25px;
            display: flex;
            gap: 10px;
        }

        .search-input {
            flex: 1;
            padding: 12px 15px;
            border: 1px solid #cbd5e1;
            border-radius: 10px;
            font-size: 14px;
            background: rgba(255, 255, 255, 0.8);
            outline: none;
        }

        .search-input:focus { border-color: var(--primary-blue); box-shadow: 0 0 0 3px rgba(0, 97, 242, 0.1); }

        .btn-search {
            background: var(--primary-blue);
            color: white;
            border: none;
            padding: 0 25px;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: 0.3s;
        }

        .btn-search:hover { transform: translateY(-1px); opacity: 0.9; }

        /* TABLE STYLING */
        .table-responsive { overflow-x: auto; border-radius: 12px; }

        table {
            width: 100%;
            border-collapse: collapse;
            background: transparent;
        }

        th {
            background: rgba(0, 97, 242, 0.05);
            color: var(--primary-blue);
            text-align: left;
            padding: 18px 15px;
            font-size: 14px;
            border-bottom: 2px solid #e2e8f0;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #f1f5f9;
            font-size: 14px;
            color: var(--text-dark);
        }

        tr:hover { background: rgba(0, 97, 242, 0.02); }

        .org-link { color: var(--primary-blue); font-weight: 600; text-decoration: none; }
        .org-link:hover { text-decoration: underline; }

        .badge {
            padding: 5px 12px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            background: #f1f5f9;
            color: #475569;
        }

        /* Mobile Adjustments */
        @media (max-width: 768px) {
            .main-content { margin-left: 0 !important; padding: 20px; padding-top: 80px; }
            .search-container { flex-direction: column; }
            .btn-search { padding: 12px; justify-content: center; }
        }
    </style>
</head>
<body>

<?php
if (isset($_SESSION['com_role'])) {
    if ($_SESSION['com_role'] === 'Village Head') {
        include '0.2_ketua_navbar.php';
    } else {
        include '0.3_committee_navbar.php';
    }
} else {
    die('<div style="padding:50px; text-align:center;">Unauthorized access. Please login.</div>');
}
?>

<div class="main-content" id="contentArea">
    <div class="container">
        <h2><i class='bx bx-list-ul'></i> Senarai Tetamu</h2>

        <form method="get" action="" class="search-container">
            <input type="text" name="search" class="search-input" placeholder="Cari nama pegawai atau nama organisasi..." value="<?= htmlspecialchars($search); ?>">
            <button type="submit" class="btn-search">
                <i class='bx bx-search'></i> Cari
            </button>
        </form>

        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Pegawai Penyelaras</th>
                        <th>Nama Organisasi</th>
                        <th>Kategori</th>
                        <th>Maklumat Hubungi</th>
                        <th>Alamat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && mysqli_num_rows($result) > 0): ?>
                        <?php while($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td style="color: #94a3b8; font-family: monospace;">#<?= $row['guest_id']; ?></td>
                                <td style="font-weight: 600;"><?= htmlspecialchars($row['guest_name']); ?></td>
                                <td>
                                    <a class="org-link" href="10.4_guest_profile_detail.php?guest_id=<?= $row['guest_id']; ?>">
                                        <?= htmlspecialchars($row['guest_organisation']); ?>
                                    </a>
                                </td>
                                <td><span class="badge"><?= htmlspecialchars($row['guest_org_type']); ?></span></td>
                                <td>
                                    <div style="font-size: 13px; line-height: 1.6;">
                                        <i class='bx bx-phone' style="color: #10b981;"></i> <?= htmlspecialchars($row['guest_phone']); ?><br>
                                        <i class='bx bx-envelope' style="color: #64748b;"></i> <?= htmlspecialchars($row['guest_email']); ?>
                                    </div>
                                </td>
                                <td style="max-width: 250px; font-size: 13px; color: #64748b;">
                                    <?= htmlspecialchars($row['guest_address']); ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 60px; color: #94a3b8;">
                                <i class='bx bx-search-alt' style="font-size: 3rem; display: block; margin-bottom: 10px;"></i>
                                Tiada rekod tetamu ditemui.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    /**
     * This script monitors the sidebar toggle button.
     * Most sidebar templates use a 'close' class. 
     * If yours is different, change 'sidebar' to your actual sidebar ID.
     */
    const sidebar = document.querySelector(".sidebar") || document.getElementById("sidebar") || document.getElementById("mySidebar");
    const toggleBtn = document.querySelector(".toggle") || document.querySelector(".bx-menu");

    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener("click", () => {
            // Give CSS a moment to catch the class change
            setTimeout(() => {
                const isClosed = sidebar.classList.contains("close") || sidebar.classList.contains("collapsed");
                console.log("Sidebar state changed. Closed:", isClosed);
            }, 50);
        });
    }
</script>

</body>
</html>