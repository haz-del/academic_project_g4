<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include '0.1_dbconnect.php';

$sql = "
SELECT report_id, prog_name, prog_rep_submitted
FROM programme_report
WHERE prog_rep_status = 'Pending'
ORDER BY report_id DESC
";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelulusan Laporan Program</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
            --sidebar-width: 260px;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body { 
            font-family: 'Segoe UI', Arial, sans-serif; 
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            min-height: 100vh;
        }

        /* --- LOGIK PELARASAN AUTOMATIK --- */
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 40px;
            padding-top: 100px;
            transition: all 0.3s ease-in-out;
            min-height: 100vh;
        }

        /* Jika navbar mempunyai class 'close' atau 'collapsed' */
        #sidebar.close ~ .main-content,
        #mySidebar.collapsed ~ .main-content { 
            margin-left: 0; 
        }

        /* Glass Container */
        .container {
            width: 100%;
            max-width: 1200px;
            margin: auto;
            background: var(--glass-bg);
            padding: 30px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid var(--border-color);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        h2 { color: var(--primary-blue); margin-bottom: 25px; font-size: 1.8rem; display: flex; align-items: center; gap: 12px; }

        /* Table Styling */
        .table-responsive { overflow-x: auto; border-radius: 12px; }
        table { width: 100%; border-collapse: collapse; background: transparent; }
        th { 
            background: rgba(0, 97, 242, 0.05); 
            color: var(--primary-blue); 
            padding: 15px; 
            text-align: center; 
            font-size: 14px;
            border-bottom: 2px solid #e2e8f0;
        }
        td { padding: 15px; border-bottom: 1px solid #f1f5f9; font-size: 14px; vertical-align: top; text-align: center; }
        tr:hover { background: rgba(0, 97, 242, 0.02); }

        /* Form Elements inside Table */
        select, textarea { 
            width: 100%; 
            padding: 10px; 
            border-radius: 8px; 
            border: 1px solid #cbd5e1; 
            background: #fff;
            font-family: inherit;
        }
        textarea { resize: vertical; margin-top: 10px; }

        .pending { font-weight: bold; color: #f59e0b; }

        /* Buttons */
        .btn { 
            padding: 10px 20px; 
            border-radius: 8px; 
            border: none; 
            cursor: pointer; 
            font-weight: 600; 
            transition: 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .submit { background: var(--primary-blue); color: #fff; margin-top: 10px; }
        .submit:hover { opacity: 0.9; transform: translateY(-1px); }
        
        .view { 
            color: var(--primary-blue); 
            font-weight: bold; 
            text-decoration: none; 
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .view:hover { text-decoration: underline; }

        @media (max-width: 768px) {
            .main-content { margin-left: 0; padding: 20px; padding-top: 80px; }
        }
    </style>
</head>

<body>

<?php 
// Memasukkan navbar (Pastikan file ini mempunyai id="sidebar" atau "mySidebar")
include '0.2_ketua_navbar.php'; 
?>

<div class="main-content">
    <div class="container">
        <h2><i class='bx bx-check-shield'></i> Kelulusan Laporan Program</h2>

        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Nama Program</th>
                        <th>Tarikh Permohonan</th>
                        <th>Status</th>
                        <th style="width: 300px;">Tindakan & Komen</th>
                        <th>Lihat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0) { ?>
                        <?php while ($row = $result->fetch_assoc()) { ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($row['prog_name']); ?></strong></td>
                                <td><?= htmlspecialchars($row['prog_rep_submitted']); ?></td>
                                <td class="pending">
                                    <span style="display: flex; align-items: center; justify-content: center; gap: 5px;">
                                        <i class='bx bx-time-five'></i> Pending
                                    </span>
                                </td>
                                <td>
                                    <form action="6.4_report_approval_save.php" method="POST">
                                        <input type="hidden" name="report_id" value="<?= $row['report_id']; ?>">
                                        
                                        <select name="status" required>
                                            <option value="">-- Pilih Status --</option>
                                            <option value="Approved">Terima</option>
                                            <option value="Returned">Dikembalikan</option>
                                            <option value="Rejected">Ditolak</option>
                                        </select>

                                        <textarea name="comments" rows="3" required placeholder="Komen atau ulasan perlukan..."></textarea>

                                        <button type="submit" class="btn submit">
                                            <i class='bx bx-send'></i> Hantar
                                        </button>
                                    </form>
                                </td>
                                <td>
                                    <a class="view" href="6.5_report_detail.php?id=<?= $row['report_id']; ?>">
                                        <i class='bx bx-file-find'></i> Lihat Laporan
                                    </a>
                                </td>
                            </tr>
                        <?php } ?>
                    <?php } else { ?>
                        <tr>
                            <td colspan="5" style="padding: 50px; color: #64748b;">
                                <i class='bx bx-info-circle' style="font-size: 2rem; display: block; margin-bottom: 10px;"></i>
                                Tiada laporan untuk kelulusan pada masa ini.
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>