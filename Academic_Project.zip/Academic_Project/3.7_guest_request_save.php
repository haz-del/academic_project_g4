<?php
session_start(); // 1. MUST start session to access logged-in ID
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '0.1_dbconnect.php';

// 2. CHECK if the guest is actually logged in
if (!isset($_SESSION['guest_id'])) {
    die("Error: You must be logged in to submit a request.");
}
$guest_id = $_SESSION['guest_id'];

/* -----------------------------
   1. Get form data
------------------------------ */
$req_name  = trim($_POST['req_name'] ?? '');
$req_objectives = trim($_POST['req_objectives'] ?? '');
$req_category = trim($_POST['req_category'] ?? '');
$req_venue = trim($_POST['req_venue'] ?? '');
$req_date = $_POST['req_date'] ?? null;
$req_time = $_POST['req_time'] ?? null;
$req_est_participants = $_POST['req_est_participants'] ?? null;
$req_est_budget = $_POST['req_est_budget'] ?? null;

/* -----------------------------
   2. Escape text fields
------------------------------ */
$req_name = $conn->real_escape_string($req_name);
$req_objectives = $conn->real_escape_string($req_objectives);
$req_category = $conn->real_escape_string($req_category);
$req_venue = $conn->real_escape_string($req_venue);

/* -----------------------------
   3. Handle file upload
------------------------------ */
$req_docs = null;
if (!empty($_FILES['req_docs']['name'])) {
    $upload_dir = "upload/";
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    $file_name = time() . "_" . basename($_FILES['req_docs']['name']);
    $tmp_name = $_FILES['req_docs']['tmp_name'];
    $target_path = $upload_dir . $file_name;
    if (move_uploaded_file($tmp_name, $target_path)) {
        $req_docs = $file_name; // Store just the name for easier database retrieval
    }
}

$req_status = 'Pending'; // Usually starts as Pending rather than Draft for submissions
$req_submitted = date('Y-m-d H:i:s');

/* -----------------------------
   4. Insert into DB (Updated with guest_id)
------------------------------ */
$sql = "
INSERT INTO guest_requests (
    guest_id,         -- ADDED THIS
    req_name,
    req_objectives,
    req_category,
    req_venue,
    req_date,
    req_time,
    req_est_participants,
    req_est_budget,
    req_docs,
    request_status,
    req_submitted
) VALUES (
    '$guest_id',      -- ADDED THIS
    '$req_name',
    '$req_objectives',
    '$req_category',
    '$req_venue',
    " . ($req_date ? "'$req_date'" : "NULL") . ",
    " . ($req_time ? "'$req_time'" : "NULL") . ",
    " . ($req_est_participants ? "'$req_est_participants'" : "NULL") . ",
    " . ($req_est_budget ? "'$req_est_budget'" : "NULL") . ",
    " . ($req_docs ? "'$req_docs'" : "NULL") . ",
    '$req_status',
    '$req_submitted'
)";

/* -----------------------------
   5. Execute + redirect
------------------------------ */
if ($conn->query($sql)) {
    $new_id = $conn->insert_id;
    echo "<script>
        alert('Guest Activity Request submitted successfully!');
        window.location.href = '10.2_guest_activity_list.php?id=$new_id';
    </script>";
    exit;
} else {
    echo "<pre>";
    echo "SQL ERROR:\n" . $conn->error;
    echo "\n\nQUERY:\n$sql";
    echo "</pre>";
}
?>