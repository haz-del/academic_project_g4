<?php
session_start();
include '0.1_dbconnect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $proposal_id = mysqli_real_escape_string($conn, $_POST['proposal_id']);
    $status      = mysqli_real_escape_string($conn, $_POST['status']);
    $comments    = mysqli_real_escape_string($conn, $_POST['comments']);
    $source      = mysqli_real_escape_string($conn, $_POST['source']);
    $admin_name  = $_SESSION['com_name']; // Nama Ketua Kampung dari session

    // 1. Validasi Status (Pastikan ejaan sama seperti dalam tag <select>)
    $allowed_status = ['Approved', 'Returned', 'Rejected'];
    
    if (!in_array($status, $allowed_status)) {
        die("<script>alert('Ralat: Status tidak sah! ($status)'); window.history.back();</script>");
    }

    // 2. Logik Simpan mengikut Sumber (AJK atau Guest)
    if ($source == 'AJK') {
        // Update jadual programme_proposal
        $sql = "UPDATE programme_proposal SET 
                prog_status = '$status', 
                prog_status_comment = '$comments', 
                prog_status_by = '$admin_name' 
                WHERE proposal_id = '$proposal_id'";
    } else {
        // Update jadual guest_requests
        $sql = "UPDATE guest_requests SET 
                request_status = '$status', 
                status_comment = '$comments' 
                WHERE request_id = '$proposal_id'";
    }

    if (mysqli_query($conn, $sql)) {
        echo "<script>
                alert('Keputusan berjaya dihantar!');
                window.location.href='4.0_proposal_approval.php';
              </script>";
    } else {
        echo "Ralat Pangkalan Data: " . mysqli_error($conn);
    }
}
?>