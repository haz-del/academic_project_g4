<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

<style>
    :root {
        --primary-blue: #0061f2;
        --sidebar-bg: #ffffff;
        --text-dark: #1a2a3a;
        --text-muted: #718096;
        --glass-white: rgba(255, 255, 255, 0.75);
        --transition-speed: 0.3s;
    }
    body {
        font-family: 'Segoe UI', Arial, sans-serif;
        background-image: url('uploads/Bg/Background.jpg'); 
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        min-height: 100vh;
    }

    /* --- TOPBAR DESIGN (WARNA & CORAK) --- */
    .topbar {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 70px;
        background: var(--glass-white); 
        backdrop-filter: blur(15px) saturate(180%);
        -webkit-backdrop-filter: blur(15px) saturate(180%);
        display: flex;
        align-items: center;
        padding: 0 30px;
        z-index: 1001; /* Berada di atas sidebar */
        box-shadow: 0 2px 15px rgba(0,0,0,0.02);
        /* Corak: Garisan aksen biru di bawah untuk identiti sistem */
        border-bottom: 3px solid var(--primary-blue); 
        box-sizing: border-box;
    }

    .topbar-left {
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .hamburger {
        font-size: 26px;
        cursor: pointer;
        color: var(--primary-blue);
        background: rgba(0, 97, 242, 0.1); 
        padding: 5px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        transition: var(--transition-speed);
    }

    .hamburger:hover {
        background: var(--primary-blue);
        color: white;
    }

    .topbar-title {
        font-size: 18px;
        font-weight: 800;
        color: var(--text-dark);
        letter-spacing: 1px;
        text-transform: uppercase;
        background: linear-gradient(45deg, var(--text-dark), var(--primary-blue));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    /* --- SIDEBAR STYLING --- */
    .sidebar {
        height: 100vh;
        width: 260px;
        position: fixed;
        top: 0;
        left: 0;
        background-color: var(--sidebar-bg);
        padding-top: 85px; /* Ruang supaya tidak kena Topbar */
        transition: all var(--transition-speed) cubic-bezier(0.4, 0, 0.2, 1);
        z-index: 1000;
        border-right: 1px solid #edf2f7;
        overflow-x: hidden;
        white-space: nowrap;
    }

    /* Keadaan Collapsed (Desktop) */
    .sidebar.collapsed {
        width: 0;
        border-right: none;
    }

    /* Sidebar Links */
    .sidebar a {
        padding: 14px 25px;
        text-decoration: none;
        font-size: 15px;
        font-weight: 500;
        color: var(--text-muted);
        display: flex;
        align-items: center;
        gap: 12px;
        transition: var(--transition-speed);
        margin: 4px 15px;
        border-radius: 10px;
        opacity: 1;
    }

    /* Sembunyikan kandungan apabila ditutup */
    .sidebar.collapsed a {
        opacity: 0;
        pointer-events: none;
    }

    .sidebar a i {
        font-size: 20px;
        min-width: 20px;
    }

    .sidebar a:hover {
        background-color: rgba(0, 97, 242, 0.05);
        color: var(--primary-blue);
    }

    .sidebar a.logout-btn {
        margin-top: 30px;
        color: #e53e3e;
    }

    .sidebar a.logout-btn:hover {
        background-color: #fff5f5;
        color: #c53030;
    }

    /* --- RESPONSIVE MOBILE --- */
    .sidebar-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 999;
    }

    @media (max-width: 768px) {
        .sidebar { left: -260px; width: 260px; }
        .sidebar.active { left: 0; }
        .sidebar-overlay.active { display: block; }
    }
</style>

<div class="topbar">
    <div class="topbar-left">
        <div class="hamburger" id="hamburger">
            <i class='bx bx-menu-alt-left'></i>
        </div>
        <span class="topbar-title">Sistem Dashboard Tetamu</span>
    </div>
</div>

<div class="sidebar" id="mySidebar">
    <a href="1.3_guest_dashboard.php">
        <i class='bx bxs-grid-alt'></i> 
        <span>Laman Utama</span>
    </a>
    <a href="3.6_guest_request.php">
        <i class='bx bx-send'></i>
        <span>Permohonan Aktiviti</span>
    </a>
    <a href="10.2_guest_activity_list.php">
        <i class='bx bx-list-ul'></i>
        <span>Senarai Aktiviti</span>
    </a>
    <a href="2.8_update_guest.php">
        <i class='bx bx-user-circle'></i>
        <span>Kemaskini Profil</span>
    </a>
    
    <hr style="border: 0; border-top: 1px solid #edf2f7; margin: 20px 25px;">
    
    <a href="11.0_logout.php" class="logout-btn">
        <i class='bx bx-log-out'></i>
        <span>Log Keluar</span>
    </a>
</div>

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<script>
    const sidebar = document.getElementById("mySidebar");
    const hamburger = document.getElementById("hamburger");
    const overlay = document.getElementById("sidebarOverlay");

    hamburger.addEventListener("click", function() {
        if (window.innerWidth > 768) {
            // Desktop: Toggle collapsed
            sidebar.classList.toggle("collapsed");
            
            // Simpan status sidebar dalam localStorage (Pilihan)
            const isCollapsed = sidebar.classList.contains("collapsed");
            localStorage.setItem("sidebarStatus", isCollapsed ? "collapsed" : "open");
        } else {
            // Mobile: Toggle active
            sidebar.classList.toggle("active");
            overlay.classList.toggle("active");
        }
    });

    // Tutup sidebar mobile apabila overlay diklik
    overlay.addEventListener("click", function() {
        sidebar.classList.remove("active");
        overlay.classList.remove("active");
    });

    // Kekalkan status sidebar desktop semasa refresh
    window.addEventListener("load", () => {
        if (window.innerWidth > 768) {
            const status = localStorage.getItem("sidebarStatus");
            if (status === "collapsed") {
                sidebar.classList.add("collapsed");
            }
        }
    });
</script>