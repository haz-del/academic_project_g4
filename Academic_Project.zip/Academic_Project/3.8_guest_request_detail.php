<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '0.1_dbconnect.php';

// Semakan akses: Pastikan pengguna sudah log masuk
if (!isset($_SESSION['com_id'])) {
    header("Location: 2.0_login.php");
    exit();
}

// 1. Ambil ID permohonan dari URL
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id === 0) {
    die("ID Permohonan tidak sah.");
}

// 2. Query maklumat dari jadual guest_requests
$result = $conn->query("SELECT * FROM guest_requests WHERE request_id = $id");
if (!$result || $result->num_rows === 0) {
    die("Permohonan tidak dijumpai.");
}

$r = $result->fetch_assoc();

// 3. Logik Kebenaran Edit (Hanya status Draft atau Returned)
$editable = ($r['request_status'] === 'Draft' || $r['request_status'] === 'Returned');
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Butiran Permohonan Tetamu</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.95);
            --text-dark: #1a2a3a;
        }

        body { 
            font-family: 'Segoe UI', sans-serif;
            background: url('uploads/Bg/Background.jpg') no-repeat center fixed;
            background-size: cover;
            margin: 0;
        }

        .main-content {
            margin-left: 260px; /* Melaras mengikut lebar navbar anda */
            padding: 40px;
            padding-top: 100px;
            transition: all 0.3s ease;
            display: flex;
            justify-content: center;
        }

        .container {
            background: var(--glass-bg);
            padding: 40px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 850px;
        }

        h2 {
            color: var(--primary-blue);
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.6rem;
        }

        .status-badge {
            padding: 5px 12px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
            background: #e2e8f0;
            color: #475569;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-group { margin-bottom: 20px; }
        .full-width { grid-column: span 2; }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #444;
            font-size: 0.9rem;
        }

        input, textarea, select {
            width: 100%;
            padding: 12px;
            border: 1px solid #d1d5db;
            border-radius: 10px;
            font-size: 1rem;
            background: rgba(255, 255, 255, 0.8);
            box-sizing: border-box;
        }

        input[disabled], textarea[disabled] {
            background-color: #f3f4f6;
            cursor: not-allowed;
            color: #666;
        }

        .file-box {
            background: #f8fafc;
            padding: 15px;
            border-radius: 10px;
            border: 1px dashed #cbd5e1;
            margin-top: 10px;
        }

        .btn-update {
            background: var(--primary-blue);
            color: white;
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 12px;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }

        .btn-update:hover {
            background: #004dc2;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 97, 242, 0.3);
        }

        .btn-back {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            text-decoration: none;
            color: #64748b;
            font-weight: 600;
            margin-bottom: 20px;
        }

        @media (max-width: 768px) {
            .main-content { margin-left: 0; padding: 20px; padding-top: 80px; }
            .form-grid { grid-template-columns: 1fr; }
            .full-width { grid-column: span 1; }
        }
    </style>
</head>
<body>

<?php 
/* Logik Navibar Dinamik */
if (isset($_SESSION['com_role'])) {
    if ($_SESSION['com_role'] === 'Village Head') {
        include '0.2_ketua_navbar.php';
    } else {
        include '0.3_committee_navbar.php';
    }
}
?>

<div class="main-content">
    <div class="container">
        <a href="3.9_guest_request_list.php" class="btn-back"><i class='bx bx-arrow-back'></i> Kembali ke Senarai</a>

        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2><i class='bx bx-envelope'></i> Permohonan Program (Tetamu)</h2>
            <span class="status-badge"><?= htmlspecialchars($r['request_status']); ?></span>
        </div>

        <form action="3.7_guest_request_update.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= htmlspecialchars($r['request_id']); ?>">

            <div class="form-grid">
                <div class="form-group full-width">
                    <label>Nama Program</label>
                    <input type="text" name="req_name" value="<?= htmlspecialchars($r['req_name']); ?>" <?= $editable ? '' : 'disabled'; ?> required>
                </div>

                <div class="form-group full-width">
                    <label>Objektif Permohonan</label>
                    <textarea name="req_objectives" rows="3" <?= $editable ? '' : 'disabled'; ?> required><?= htmlspecialchars($r['req_objectives']); ?></textarea>
                </div>

                <div class="form-group">
                    <label>Kategori</label>
                    <input type="text" name="req_category" value="<?= htmlspecialchars($r['req_category']); ?>" <?= $editable ? '' : 'disabled'; ?>>
                </div>

                <div class="form-group">
                    <label>Lokasi Cadangan</label>
                    <input type="text" name="req_venue" value="<?= htmlspecialchars($r['req_venue']); ?>" <?= $editable ? '' : 'disabled'; ?>>
                </div>

                <div class="form-group">
                    <label>Tarikh Program</label>
                    <input type="date" name="req_date" value="<?= htmlspecialchars($r['req_date']); ?>" <?= $editable ? '' : 'disabled'; ?>>
                </div>

                <div class="form-group">
                    <label>Masa</label>
                    <input type="time" name="req_time" value="<?= htmlspecialchars($r['req_time']); ?>" <?= $editable ? '' : 'disabled'; ?>>
                </div>

                <div class="form-group">
                    <label>Anggaran Peserta</label>
                    <input type="number" name="req_est_participants" value="<?= htmlspecialchars($r['req_est_participants']); ?>" <?= $editable ? '' : 'disabled'; ?>>
                </div>

                <div class="form-group">
                    <label>Anggaran Bajet (RM)</label>
                    <input type="number" step="0.01" name="req_est_budget" value="<?= htmlspecialchars($r['req_est_budget']); ?>" <?= $editable ? '' : 'disabled'; ?>>
                </div>

                <div class="form-group full-width">
                    <label>Dokumen Sokongan</label>
                    <div class="file-box">
                        <?php if (!empty($r['req_docs'])): ?>
                            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                                <i class='bx bxs-file-pdf' style="font-size: 24px; color: #ef4444;"></i>
                                <a href="<?= htmlspecialchars($r['req_docs']); ?>" target="_blank" style="color: var(--primary-blue); font-weight: 600; text-decoration: none;">Lihat Dokumen Sedia Ada</a>
                            </div>
                        <?php else: ?>
                            <p style="margin: 0; color: #888; font-size: 0.85rem;"><i class='bx bx-info-circle'></i> Tiada dokumen sokongan dimuat naik.</p>
                        <?php endif; ?>

                        <?php if ($editable): ?>
                            <div style="margin-top: 15px; border-top: 1px solid #e2e8f0; padding-top: 10px;">
                                <label style="font-size: 0.8rem; color: #666;">Muat Naik Dokumen Baru (Jika perlu)</label>
                                <input type="file" name="req_docs" style="border: none; padding-left: 0;">
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if ($editable): ?>
                <button type="submit" class="btn-update">
                    <i class='bx bx-save'></i> Kemaskini & Hantar Permohonan
                </button>
            <?php endif; ?>
        </form>
    </div>
</div>

</body>
</html>