<?php 
session_start();
include '0.1_dbconnect.php';

// Semakan sesi log masuk Ketua Kampung (com_role: 'Village Head' atau 'Admin')
if (!isset($_SESSION['com_id'])) {
    header("Location: 2.0_login.php"); 
    exit();
}

$com_id = $_SESSION['com_id'];

/* ================= 1. PENGIRAAN KPI KETUA KAMPUNG (Dinamik) ================= */

// 1. Program Belum Diluluskan (Status: Pending) - Dari AJK & Tetamu
$q_pending_ajk = mysqli_query($conn, "SELECT COUNT(*) as total FROM programme_proposal WHERE prog_status = 'Pending'");
$q_pending_guest = mysqli_query($conn, "SELECT COUNT(*) as total FROM guest_requests WHERE request_status = 'Pending'");
$total_pending = mysqli_fetch_assoc($q_pending_ajk)['total'] + mysqli_fetch_assoc($q_pending_guest)['total'];

// 2. Program Diluluskan (Status: Approved)
$q_approved_ajk = mysqli_query($conn, "SELECT COUNT(*) as total FROM programme_proposal WHERE prog_status = 'Approved'");
$q_approved_guest = mysqli_query($conn, "SELECT COUNT(*) as total FROM guest_requests WHERE request_status = 'Approved'");
$total_approved = mysqli_fetch_assoc($q_approved_ajk)['total'] + mysqli_fetch_assoc($q_approved_guest)['total'];

// 3. Program Akan Datang (Berdasarkan prog_date yang telah diluluskan)
$q_future = mysqli_query($conn, "SELECT COUNT(*) as total FROM programme_proposal WHERE prog_status = 'Approved' AND prog_date >= CURDATE()");
$total_future = mysqli_fetch_assoc($q_future)['total'];

/* ================= 2. SISTEM NOTIFIKASI (ID Bersatu melalui UNION) ================= */
// Menggunakan 'link_id' supaya pautan ID konsisten untuk kedua-dua jadual
$latest_requests = mysqli_query($conn, "
    SELECT proposal_id AS link_id, prog_name AS title, prog_status AS status, prog_prop_submitted AS date, 'AJK' AS source 
    FROM programme_proposal 
    WHERE prog_status = 'Pending'
    UNION
    SELECT request_id AS link_id, req_name AS title, request_status AS status, req_submitted AS date, 'Tetamu' AS source
    FROM guest_requests
    WHERE request_status = 'Pending'
    ORDER BY date DESC LIMIT 5
");
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Ketua Kampung | Sistem Pengurusan</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.85);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            margin: 0;
        }

        /* Automatik melaras jika sidebar wujud/tidak wujud */
        .main-content { 
            margin-left: 260px; 
            padding: 40px; 
            padding-top: 110px; 
            transition: all 0.3s ease; 
        }

        /* Gunakan selector ini jika anda menggunakan class 'collapsed' pada sidebar */
        #mySidebar.collapsed ~ .main-content { margin-left: 80px; }

        .header-section { margin-bottom: 30px; }
        h2 { font-size: 2.2rem; color: var(--text-dark); font-weight: 800; }
        .subtitle { font-size: 1.1rem; color: #4a5568; margin-top: 5px; }

        /* Action Buttons */
        .action-section { display: flex; gap: 20px; margin-bottom: 40px; flex-wrap: wrap; }
        .action-btn { 
            padding: 12px 25px; cursor: pointer; border: 2px solid var(--primary-blue);
            border-radius: 15px; background: white; color: var(--primary-blue);
            font-weight: 700; display: flex; align-items: center; gap: 12px;
            transition: 0.3s; box-shadow: 0 4px 15px rgba(0, 97, 242, 0.1);
            text-decoration: none;
        }
        .action-btn:hover { background: var(--primary-blue); color: white; transform: translateY(-3px); }

        /* Stats Grid */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 25px; }
        .card { 
            background: var(--glass-bg); padding: 30px; border-radius: 20px; 
            border: 1px solid var(--border-color); backdrop-filter: blur(15px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.08); display: flex; flex-direction: column; gap: 10px;
        }
        .card b { font-size: 0.9rem; color: #718096; text-transform: uppercase; }
        .card .value { font-size: 42px; font-weight: 800; color: var(--text-dark); }
        .icon-box { padding: 12px; border-radius: 12px; font-size: 1.8rem; }

        /* Notifikasi Section */
        .noti-card {
            background: var(--glass-bg); padding: 25px; border-radius: 20px;
            margin-top: 30px; border: 1px solid var(--border-color); backdrop-filter: blur(15px);
        }
        .noti-item { padding: 15px 0; border-bottom: 1px solid rgba(0,0,0,0.05); display: flex; align-items: center; gap: 15px; }
        .noti-item:last-child { border: none; }
        
        .source-badge { 
            padding: 3px 10px; border-radius: 20px; font-size: 10px; font-weight: 800; 
            background: #ebf8ff; color: #3182ce; border: 1px solid #bee3f8;
        }

        .check-link {
            background: var(--primary-blue); color: white !important; 
            padding: 8px 16px; border-radius: 10px; 
            transition: 0.3s; display: inline-block;
        }
        .check-link:hover { background: #004dc0; transform: scale(1.05); }

        @media (max-width: 768px) { .main-content { margin-left: 0; padding: 20px; padding-top: 100px; } }
    </style>
</head>
<body>

    <?php include '0.2_ketua_navbar.php'; ?>

    <div class="main-content">
        <div class="header-section">
            <h2>Hi, <?php echo $_SESSION['com_name'] ?? 'Ketua Kampung'; ?> 👋</h2>
            <p class="subtitle">Sistem Pengurusan Aktiviti - Anda mempunyai <b><?php echo $total_pending; ?></b> permohonan menunggu kelulusan.</p>
        </div>

        <div class="action-section">
            <a href="4.0_proposal_approval.php" class="action-btn">
                <i class='bx bx-task'></i> <span>Semak Kertas Kerja</span>
            </a>
            <a href="3.9_guest_request_list.php" class="action-btn">
                <i class='bx bx-user-voice'></i> <span>Semak Permintaan Tetamu</span>
            </a>
            <a href="12.3_analisis_kewangan.php" class="action-btn">
                <i class='bx bx-pie-chart-alt-2'></i> <span>Analisis Kewangan</span>
            </a>
        </div>

        <div class="stats-grid">
            <div class="card">
                <b>Permohonan Baru</b>
                <div style="display: flex; align-items: baseline; justify-content: space-between;">
                    <span class="value"><?php echo $total_pending; ?></span>
                    <i class='bx bx-error-circle icon-box' style="background: #fff5f5; color: #fc8181;"></i>
                </div>
            </div>

            <div class="card">
                <b>Program Diluluskan</b>
                <div style="display: flex; align-items: baseline; justify-content: space-between;">
                    <span class="value"><?php echo $total_approved; ?></span>
                    <i class='bx bx-check-shield icon-box' style="background: #f0fff4; color: #68d391;"></i>
                </div>
            </div>

            <div class="card">
                <b>Program Akan Datang</b>
                <div style="display: flex; align-items: baseline; justify-content: space-between;">
                    <span class="value"><?php echo $total_future; ?></span>
                    <i class='bx bx-calendar-event icon-box' style="background: #ebf8ff; color: #63b3ed;"></i>
                </div>
            </div>
        </div>

        <div class="noti-card">
            <h3 style="margin-bottom: 20px; font-size: 1.1rem; display: flex; align-items: center; gap: 10px;">
                <i class='bx bxs-bell-ring' style="color: #f6ad55;"></i> Tindakan Diperlukan (Pending)
            </h3>
            
            <?php if(mysqli_num_rows($latest_requests) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($latest_requests)): ?>
                    <div class="noti-item">
                        <div style="flex: 1;">
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <span class="source-badge"><?php echo $row['source']; ?></span>
                                <strong style="font-size: 0.95rem; color: var(--text-dark);">
                                    <?php echo $row['title']; ?>
                                </strong>
                            </div>
                            <p style="font-size: 0.85rem; color: #718096; margin-top: 5px;">
                                Permohonan baru daripada <b><?php echo $row['source']; ?></b> memerlukan semakan dan kelulusan anda.
                            </p>
                        </div>
                        <div style="text-align: right;">
                        <div style="font-size: 0.75rem; color: #a0aec0; margin-bottom: 8px;">
                            <?php echo date('d M Y', strtotime($row['date'])); ?>
                            </div>
                                <a href="4.0_proposal_approval.php?id=<?php echo $row['link_id']; ?>&source=<?php echo $row['source']; ?>" 
                               class="check-link" 
                               style="background: var(--primary-blue); color: white; padding: 6px 12px; border-radius: 8px; font-size: 11px; text-decoration: none; font-weight: 700;">
                               SEMAK SEKARANG >
                             </a>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div style="text-align: center; padding: 20px;">
                    <i class='bx bx-check-circle' style="font-size: 3rem; color: #68d391;"></i>
                    <p style="font-size: 0.9rem; color: #718096; margin-top: 10px;">Tiada tugasan tertunggak. Semua permohonan telah disemak!</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>