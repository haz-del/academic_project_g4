<?php
$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "programme_management";

// Use mysqli_report to help catch errors during development
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = new mysqli($dbServername, $dbUsername, $dbPassword, $dbName);
    
    // Set charset to utf8mb4 for better compatibility with special characters
    $conn->set_charset("utf8mb4");
    
} catch (Exception $e) {
    // If connection fails, this will show you exactly why
    die("Database Connection failed: " . $e->getMessage());
}
?>