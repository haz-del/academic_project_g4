<?php
session_start();
include '0.1_dbconnect.php';

// Ambil ID kolaborator dari URL
if (!isset($_GET['id'])) {
    header("Location: 2.3_collaborators_list.php");
    exit;
}

$id = mysqli_real_escape_string($conn, $_GET['id']);

// 1. QUERY DATA KOLABORATOR (Ikut nama jadual 'collaborators' dalam ERD)
$query_partner = "SELECT * FROM collaborators WHERE coll_id = '$id'";
$result_partner = mysqli_query($conn, $query_partner);
$partner = mysqli_fetch_assoc($result_partner);

if (!$partner) {
    die("<script>alert('Kolaborator tidak dijumpai!'); window.location='2.3_collaborators_list.php';</script>");
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Kolaborator | <?= htmlspecialchars($partner['coll_organisation_name']) ?></title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root { --primary-blue: #0061f2; --glass: rgba(255, 255, 255, 0.95); }
        body { 
            font-family: 'Segoe UI', sans-serif; 
            background: url('uploads/Bg/Background.jpg') no-repeat center fixed; 
            background-size: cover; 
            margin: 0; 
        }
        .main-content { margin-left: 260px; padding: 40px; padding-top: 100px; display: flex; justify-content: center; }
        .container { width: 100%; max-width: 900px; }
        
        /* Glassmorphism Card */
        .profile-card { 
            background: var(--glass); 
            padding: 35px; 
            border-radius: 20px; 
            box-shadow: 0 15px 35px rgba(0,0,0,0.1); 
            backdrop-filter: blur(15px);
            margin-bottom: 25px;
            border: 1px solid rgba(255,255,255,0.5);
        }

        .header-profile { display: flex; align-items: center; gap: 20px; border-bottom: 2px solid #eee; padding-bottom: 20px; margin-bottom: 25px; }
        .header-profile i { font-size: 60px; color: var(--primary-blue); }
        .header-profile h2 { margin: 0; color: #333; font-size: 1.8rem; }

        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 25px; }
        .info-box b { color: var(--primary-blue); font-size: 0.8rem; text-transform: uppercase; letter-spacing: 1px; }
        .info-box p { margin: 5px 0 0; font-size: 1.05rem; color: #2c3e50; font-weight: 500; }

        .history-table-container { 
            background: white; 
            padding: 25px; 
            border-radius: 20px; 
            box-shadow: 0 5px 15px rgba(0,0,0,0.05); 
        }
        .history-table-container h3 { margin-top: 0; color: #444; border-left: 5px solid var(--primary-blue); padding-left: 15px; }

        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th { text-align: left; padding: 12px; border-bottom: 2px solid #f1f1f1; color: #666; }
        td { padding: 12px; border-bottom: 1px solid #fafafa; color: #333; }

        .btn-back { display: inline-flex; align-items: center; gap: 5px; color: #666; text-decoration: none; margin-bottom: 20px; font-weight: 600; }
        .btn-back:hover { color: var(--primary-blue); }
    </style>
</head>
<body>

<?php 
// Panggil navbar berdasarkan role sesi
if ($_SESSION['com_role'] === 'Village Head') { include '0.2_ketua_navbar.php'; } 
else { include '0.3_committee_navbar.php'; } 
?>

<div class="main-content">
    <div class="container">
        <a href="9.0_collaborators_list.php" class="btn-back"><i class='bx bx-left-arrow-alt'></i> Kembali ke Senarai</a>

        <div class="profile-card">
            <div class="header-profile">
                <i class='bx bxs-business'></i>
                <div>
                    <h2><?= htmlspecialchars($partner['coll_organisation_name']) ?></h2>
                    <p style="margin:0; color:#666;"><i class='bx bx-tag-alt'></i> <?= htmlspecialchars($partner['coll_organisation_type']) ?></p>
                </div>
            </div>

            <div class="info-grid">
                <div class="info-box">
                    <b>Pegawai Penyelaras</b>
                    <p><?= htmlspecialchars($partner['coll_contact_person']) ?></p>
                </div>
                <div class="info-box">
                    <b>No. Telefon</b>
                    <p><?= htmlspecialchars($partner['coll_phone']) ?></p>
                </div>
                <div class="info-box">
                    <b>Alamat Emel</b>
                    <p><?= htmlspecialchars($partner['coll_email']) ?></p>
                </div>
                <div class="info-box">
                    <b>Tarikh Sertai</b>
                    <p><?= date('d/m/Y', strtotime($partner['coll_date_created'])) ?></p>
                </div>
                <div class="info-box" style="grid-column: span 2;">
                    <b>Alamat Organisasi</b>
                    <p><?= nl2br(htmlspecialchars($partner['coll_address'])) ?></p>
                </div>
            </div>
        </div>

        <div class="history-table-container">
            <h3>Sejarah Program</h3>
            <table>
                <thead>
                    <tr>
                        <th>Nama Program</th>
                        <th>Tarikh</th>
                        <th>Peranan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // 2. QUERY SEJARAH PROGRAM (Ikut ERD: collaboratorsproposal -> programme_proposal)
                    // Berdasarkan ERD anda, sejarah kolaborasi boleh dilihat melalui jadual collaboratorsproposal
                    $sql_history = "SELECT cp.coll_role, pp.prog_name, pp.prog_date 
                                    FROM collaboratorsproposal cp
                                    JOIN programme_proposal pp ON cp.proposal_id = pp.proposal_id
                                    WHERE cp.coll_id = '$id'";
                    
                    $history_result = mysqli_query($conn, $sql_history);

                    if (mysqli_num_rows($history_result) > 0) {
                        while ($row = mysqli_fetch_assoc($history_result)) {
                            echo "<tr>";
                            echo "<td><b>" . htmlspecialchars($row['prog_name']) . "</b></td>";
                            echo "<td>" . date('d/m/Y', strtotime($row['prog_date'])) . "</td>";
                            echo "<td>" . htmlspecialchars($row['coll_role']) . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='3' style='text-align:center; padding:20px; color:#999;'>Tiada sejarah program ditemui.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>