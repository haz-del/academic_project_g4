<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '0.1_dbconnect.php';

if (
    !isset($_POST['request_id']) ||
    !isset($_POST['new_status']) ||
    !isset($_POST['comment']) ||
    !isset($_SESSION['com_id'])
) {
    die("Invalid submission");
}

$request_id = intval($_POST['request_id']);
$status     = $_POST['new_status']; // Approved | Rejected
$comment    = trim($_POST['comment']);
$by         = intval($_SESSION['com_id']);

/* Ensure committee exists */
$check = $conn->query("SELECT com_id FROM committee WHERE com_id = $by");
if ($check->num_rows === 0) {
    die("Invalid committee ID.");
}

$sql = "
UPDATE guest_requests SET
    request_status = '$status',
    status_comment = '$comment',
    com_id = $by
WHERE request_id = $request_id
";

if (!$conn->query($sql)) {
    die("Update failed: " . $conn->error);
}

/* Redirect */
if ($status === 'Approved') {
    header("Location: 3.1_create_proposal.php?request_id=$request_id");
} else {
    header("Location: 3.9_guest_request_list.php");
}
exit();
