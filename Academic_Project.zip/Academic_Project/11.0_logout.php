<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Logout Page</title>
    </head>
    <body>
        <?php
            // Start the session
            session_start();

            // Unset all of the session variables
            $_SESSION = array();

            // Destroy the session
            session_destroy();

            // Redirect to home page
            header("Location: 1.0_resident_homepage.php");
            exit();
        ?>
    </body>
</html>

