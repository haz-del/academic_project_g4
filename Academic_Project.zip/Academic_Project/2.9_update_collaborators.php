<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

include "0.1_dbconnect.php";

/* =========================
   Access Control
   ========================= */
if (!isset($_SESSION['com_id'])) {
    header("Location: 1.0_resident_homepage.php");
    exit();
}

/* =========================
   Handle Update Submission
   ========================= */
$success = $error = "";

if ($_SERVER['REQUEST_METHOD'] === "POST" && isset($_POST['update'])) {
    $coll_id = intval($_POST['coll_id']);
    $name  = $conn->real_escape_string(trim($_POST['coll_organisation_name']));
    $type  = $conn->real_escape_string(trim($_POST['coll_organisation_type']));
    $contp = $conn->real_escape_string(trim($_POST['coll_contact_person']));
    $phone = $conn->real_escape_string(trim($_POST['coll_phone']));
    $email = $conn->real_escape_string(trim($_POST['coll_email']));
    $addr  = $conn->real_escape_string(trim($_POST['coll_address']));

    $sql = "UPDATE collaborators SET 
            coll_organisation_name = '$name',
            coll_organisation_type = '$type',
            coll_contact_person = '$contp',
            coll_phone = '$phone',
            coll_email = '$email',
            coll_address = '$addr'
            WHERE coll_id = $coll_id";

    if ($conn->query($sql)) {
        $success = "Maklumat kolaborator berjaya dikemaskini.";
    } else {
        $error = "Gagal dikemaskini: " . $conn->error;
    }
}

/* =========================
   Fetch Collaborators List
   ========================= */
$collaborators = $conn->query("SELECT * FROM collaborators ORDER BY coll_organisation_name");

/* =========================
   Fetch Selected Collaborator
   ========================= */
$selected = null;
if (isset($_GET['coll_id'])) {
    $id = intval($_GET['coll_id']);
    $res = $conn->query("SELECT * FROM collaborators WHERE coll_id = $id");
    $selected = $res->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kemas Kini Kolaborator | Sistem Kampung</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: var(--text-dark);
        }

        .main-content {
            margin-left: 260px;
            padding: 40px;
            padding-top: 110px;
            transition: all 0.3s ease;
        }

        #mySidebar.collapsed ~ .main-content {
            margin-left: 0;
        }

        .container {
            max-width: 1100px;
            margin: auto;
        }

        h2 {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 25px;
            color: var(--text-dark);
            font-size: 1.8rem;
        }

        /* Glass Cards */
        .glass-card {
            background: var(--glass-bg);
            padding: 30px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid var(--border-color);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        /* Table Styling */
        .table-wrapper {
            overflow-x: auto;
            background: white;
            border-radius: 12px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: transparent;
        }

        th {
            background: rgba(0, 97, 242, 0.05);
            color: var(--primary-blue);
            text-align: left;
            padding: 15px;
            font-weight: 700;
            border-bottom: 2px solid #edf2f7;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #edf2f7;
            font-size: 0.95rem;
        }

        tr:hover { background: rgba(0, 97, 242, 0.02); }

        /* Form Styling */
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-bottom: 15px;
        }

        .full-width { grid-column: span 2; }

        label {
            font-weight: 600;
            font-size: 0.9rem;
            color: #4a5568;
        }

        input {
            padding: 12px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 1rem;
            transition: 0.3s;
        }

        input:focus {
            outline: none;
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(0, 97, 242, 0.1);
        }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
            text-decoration: none;
            border: none;
        }

        .btn-update {
            background: var(--primary-blue);
            color: white;
        }

        .btn-update:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 97, 242, 0.3);
        }

        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .success { background: #f0fff4; color: #2f855a; border: 1px solid #c6f6d5; }
        .error { background: #fff5f5; color: #c53030; border: 1px solid #fed7d7; }

        @media (max-width: 768px) {
            .form-grid { grid-template-columns: 1fr; }
            .full-width { grid-column: span 1; }
            .main-content { margin-left: 0; padding: 20px; padding-top: 100px; }
        }
    </style>
</head>
<body>

<?php
if (isset($_SESSION['com_role'])) {
    if ($_SESSION['com_role'] === 'Village Head') {
        include '0.2_ketua_navbar.php';
    } else {
        include '0.3_committee_navbar.php';
    }
} else {
    die('Unauthorized access');
}
?>

<div class="main-content">
    <div class="container">
        
        <h2><i class='bx bxs-edit-location'></i> Kemas Kini Kolaborator</h2>

        <div class="glass-card">
            <h3 style="margin-bottom: 20px;">Pilih Organisasi</h3>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Nama Organisasi</th>
                            <th>Kategori</th>
                            <th>Tindakan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $collaborators->fetch_assoc()): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($row['coll_organisation_name']); ?></strong></td>
                            <td><?= htmlspecialchars($row['coll_organisation_type']); ?></td>
                            <td>
                                <a class="btn btn-update" href="?coll_id=<?= $row['coll_id']; ?>">
                                    <i class='bx bx-edit-alt'></i> Kemas Kini
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php if ($selected): ?>
        <div class="glass-card" id="edit-form">
            <h3 style="margin-bottom: 25px; color: var(--primary-blue);">
                <i class='bx bx-cog'></i> Edit Maklumat: <?= htmlspecialchars($selected['coll_organisation_name']); ?>
            </h3>

            <?php if ($success): ?>
                <div class="alert success"><i class='bx bxs-check-circle'></i> <?= $success; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert error"><i class='bx bxs-error-circle'></i> <?= $error; ?></div>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="coll_id" value="<?= $selected['coll_id']; ?>">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Nama Organisasi</label>
                        <input type="text" name="coll_organisation_name" value="<?= htmlspecialchars($selected['coll_organisation_name']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Kategori Organisasi</label>
                        <input type="text" name="coll_organisation_type" value="<?= htmlspecialchars($selected['coll_organisation_type']); ?>">
                    </div>

                    <div class="form-group">
                        <label>Pegawai Penyelaras</label>
                        <input type="text" name="coll_contact_person" value="<?= htmlspecialchars($selected['coll_contact_person']); ?>">
                    </div>

                    <div class="form-group">
                        <label>No. Telefon</label>
                        <input type="text" name="coll_phone" value="<?= htmlspecialchars($selected['coll_phone']); ?>">
                    </div>

                    <div class="form-group">
                        <label>Emel Organisasi</label>
                        <input type="email" name="coll_email" value="<?= htmlspecialchars($selected['coll_email']); ?>">
                    </div>

                    <div class="form-group">
                        <label>Tarikh Pendaftaran (Sistem)</label>
                        <input type="text" value="<?= $selected['coll_date_created']; ?>" disabled style="background: #f8fafc; color: #94a3b8;">
                    </div>

                    <div class="form-group full-width">
                        <label>Alamat Organisasi</label>
                        <input type="text" name="coll_address" value="<?= htmlspecialchars($selected['coll_address']); ?>">
                    </div>
                </div>

                <div style="margin-top: 20px; display: flex; gap: 10px;">
                    <button type="submit" name="update" class="btn btn-update">
                        <i class='bx bx-save'></i> Simpan Perubahan
                    </button>
                    <a href="2.9_update_collaborators.php" class="btn" style="background: #e2e8f0; color: #4a5568;">Batal</a>
                </div>
            </form>
        </div>
        <?php endif; ?>

    </div>
</div>

<script>
    // Penyelarasan untuk Sidebar (jika fungsi toggle wujud dalam navbar)
    const sidebar = document.getElementById("mySidebar");
    const hamburger = document.getElementById("hamburger");

    if (hamburger && sidebar) {
        hamburger.addEventListener("click", function() {
            sidebar.classList.toggle("collapsed");
        });
    }
</script>

</body>
</html>