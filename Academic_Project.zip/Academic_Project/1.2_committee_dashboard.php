<?php 
session_start();
include '0.1_dbconnect.php';

// Semakan sesi log masuk AJK
if (!isset($_SESSION['com_id'])) {
    header("Location: 2.0_login.php"); 
    exit();
}

$com_id = $_SESSION['com_id'];

/* ================= 1. PENGIRAAN KPI DARI DB (Ikut ERD) ================= */

// 1. Perlu Kelulusan (Status: Pending)
$q_pending = mysqli_query($conn, "SELECT COUNT(*) as total FROM programme_proposal WHERE com_id = '$com_id' AND prog_status = 'Pending'");
$total_pending = mysqli_fetch_assoc($q_pending)['total'];

// 2. Perlu Pembetulan (Status: Returned)
$q_fix = mysqli_query($conn, "SELECT COUNT(*) as total FROM programme_proposal WHERE com_id = '$com_id' AND prog_status = 'Returned'");
$total_fix = mysqli_fetch_assoc($q_fix)['total'];

// 3. Telah Diluluskan (Status: Approved)
$q_approved = mysqli_query($conn, "SELECT COUNT(*) as total FROM programme_proposal WHERE com_id = '$com_id' AND prog_status = 'Approved'");
$total_approved = mysqli_fetch_assoc($q_approved)['total'];

// 4. Program Akan Datang (Berdasarkan prog_date)
$q_future = mysqli_query($conn, "SELECT COUNT(*) as total FROM programme_proposal WHERE prog_status = 'Approved' AND prog_date >= CURDATE()");
$total_future = mysqli_fetch_assoc($q_future)['total'];

/* ================= 2. SISTEM NOTIFIKASI (Ikut ERD) ================= */
// Mengambil 3 perkembangan terbaru berdasarkan tarikh serahan prog_prop_submitted
$notifications = mysqli_query($conn, "
    SELECT prog_name, prog_status, prog_status_comment, prog_prop_submitted 
    FROM programme_proposal 
    WHERE com_id = '$com_id' 
    ORDER BY prog_prop_submitted DESC LIMIT 3
");
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard AJK | Programme Management</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.85);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            min-height: 100vh;
            margin: 0;
        }

        .main-content { margin-left: 260px; padding: 40px; padding-top: 110px; transition: all 0.3s ease; }
        #mySidebar.collapsed ~ .main-content { margin-left: 0; }

        .header-section { margin-bottom: 30px; }
        h2 { font-size: 2.2rem; color: var(--text-dark); font-weight: 800; }
        .subtitle { font-size: 1.1rem; color: #4a5568; margin-top: 5px; }

        /* Action Buttons - Premium Design */
        .action-section { display: flex; gap: 20px; margin-bottom: 40px; flex-wrap: wrap; }
        .action-btn { 
            padding: 12px 25px; cursor: pointer; border: 2px solid var(--primary-blue);
            border-radius: 15px; background: white; color: var(--primary-blue);
            font-weight: 700; display: flex; align-items: center; gap: 12px;
            transition: 0.3s ease; box-shadow: 0 4px 15px rgba(0, 97, 242, 0.1);
            text-decoration: none; font-size: 16px;
        }
        .action-btn:hover { background: var(--primary-blue); color: white; transform: translateY(-3px); }

        /* Stats Grid */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 25px; }
        .card { 
            background: var(--glass-bg); padding: 30px; border-radius: 20px; 
            border: 1px solid var(--border-color); backdrop-filter: blur(15px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.08); display: flex; flex-direction: column; gap: 10px;
        }
        .card b { font-size: 0.9rem; color: #718096; text-transform: uppercase; }
        .card .value { font-size: 42px; font-weight: 800; color: var(--text-dark); }
        .icon-box { padding: 10px; border-radius: 12px; font-size: 1.5rem; }

        /* Notifikasi */
        .noti-card {
            background: var(--glass-bg); padding: 25px; border-radius: 20px;
            margin-top: 30px; border: 1px solid var(--border-color); backdrop-filter: blur(15px);
        }
        .noti-item { padding: 15px 0; border-bottom: 1px solid rgba(0,0,0,0.05); display: flex; align-items: center; gap: 15px; }
        .noti-item:last-child { border: none; }
        .status-tag { padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
        
        /* Status Colors */
        .tag-pending { background: #fff4e6; color: #f6ad55; }
        .tag-approved { background: #f0fff4; color: #68d391; }
        .tag-returned { background: #ebf8ff; color: #63b3ed; }
        .tag-rejected { background: #fff5f5; color: #fc8181; }

        @media (max-width: 768px) { .main-content { margin-left: 0; padding: 20px; padding-top: 100px; } }
    </style>
</head>
<body>

    <?php include '0.3_committee_navbar.php'; ?>

    <div class="main-content">
        <div class="header-section">
            <h2>Hi, <?php echo $_SESSION['com_name'] ?? 'Ahli Jawatankuasa'; ?> 👋</h2>
            <p class="subtitle">Sistem Pengurusan Aktiviti Kampung - Ringkasan Kertas Kerja</p>
        </div>

        <div class="action-section">
            <a href="3.1_create_proposal.php" class="action-btn">
                <i class='bx bx-file-blank'></i> <span>Borang Kertas Kerja</span>
            </a>
            <a href="12.4_kalendar_aktiviti.php" class="action-btn">
                <i class='bx bx-calendar'></i> <span>Semak Kalendar</span>
            </a>
        </div>

        <div class="stats-grid">
            <div class="card">
                <b>Perlu Kelulusan</b>
                <div style="display: flex; align-items: baseline; justify-content: space-between;">
                    <span class="value"><?php echo $total_pending; ?></span>
                    <i class='bx bx-loader-circle icon-box' style="background: #fff4e6; color: #f6ad55;"></i>
                </div>
            </div>

            <div class="card">
                <b>Perlu Pembetulan</b>
                <div style="display: flex; align-items: baseline; justify-content: space-between;">
                    <span class="value"><?php echo $total_fix; ?></span>
                    <i class='bx bx-revision icon-box' style="background: #ebf8ff; color: #63b3ed;"></i>
                </div>
            </div>

            <div class="card">
                <b>Telah Diluluskan</b>
                <div style="display: flex; align-items: baseline; justify-content: space-between;">
                    <span class="value"><?php echo $total_approved; ?></span>
                    <i class='bx bx-check-double icon-box' style="background: #f0fff4; color: #68d391;"></i>
                </div>
            </div>

            <div class="card">
                <b>Program Akan Datang</b>
                <div style="display: flex; align-items: baseline; justify-content: space-between;">
                    <span class="value"><?php echo $total_future; ?></span>
                    <i class='bx bx-party icon-box' style="background: #e1e7ff; color: #5a67d8;"></i>
                </div>
            </div>
        </div>

        <div class="noti-card">
            <h3 style="margin-bottom: 15px; font-size: 1.1rem;"><i class='bx bx-bell'></i> Status Kertas Kerja Terbaru</h3>
            <?php if(mysqli_num_rows($notifications) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($notifications)): ?>
                    <div class="noti-item">
                        <div style="flex: 1;">
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <strong style="font-size: 0.95rem;"><?php echo $row['prog_name']; ?></strong>
                                <span class="status-tag tag-<?php echo strtolower($row['prog_status']); ?>">
                                    <?php echo $row['prog_status']; ?>
                                </span>
                            </div>
                            <p style="font-size: 0.85rem; color: #718096; margin-top: 5px;">
                                <?php echo $row['prog_status_comment'] ?: 'Sedang diproses oleh Ketua Kampung.'; ?>
                            </p>
                        </div>
                        <div style="font-size: 0.75rem; color: #a0aec0;">
                            <?php echo date('d M', strtotime($row['prog_prop_submitted'])); ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p style="font-size: 0.9rem; color: #718096;">Tiada permohonan kertas kerja baru.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>