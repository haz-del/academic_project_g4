<?php
include '0.1_dbconnect.php';

// Ambil program Approved yang akan datang
$query = "SELECT prog_name, prog_date, prog_time, prog_venue, prog_category 
          FROM programme_proposal 
          WHERE prog_status = 'Approved' AND prog_date >= CURDATE() 
          ORDER BY prog_date ASC";
$result = $conn->query($query);
$events = [];
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) { $events[] = $row; }
}
$eventsJson = json_encode($events);
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Utama</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --event-glow: #ff9800;
            --glass: rgba(255, 255, 255, 0.95);
        }

        /* Menghapuskan skrol pada seluruh halaman */
        html, body {
            height: 100%;
            margin: 0;
            overflow: hidden; 
            font-family: 'Segoe UI', sans-serif;
            background: url('uploads/Bg/Background.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        /* Layout Utama Flexbox */
        .wrapper {
            display: flex;
            flex-direction: column;
            height: 100vh;
            padding: 20px 40px; /* Padding tepi dikurangkan */
            box-sizing: border-box;
        }

        /* Header: Kedudukan Hujung ke Hujung */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex: 0 1 auto;
            margin-bottom: 20px;
        }

        .title-area h1 {
            font-size: 3.5rem;
            margin: 0;
            color: #1a2a3a;
            letter-spacing: -1px;
        }

        .auth-group {
            display: flex;
            gap: 15px;
        }

        .btn-auth {
            background: white;
            color: var(--primary-blue);
            text-decoration: none;
            padding: 12px 28px;
            border-radius: 12px;
            font-weight: bold;
            border: 2px solid var(--primary-blue);
            transition: 0.3s;
        }

        .btn-auth:hover { background: var(--primary-blue); color: white; }

        /* Main Section: Dua Lajur Seimbang */
        main {
            display: flex;
            gap: 30px;
            flex: 1; /* Mengambil baki ruang skrin */
            min-height: 0; /* Penting untuk overflow anak elemen */
        }

        .card {
            background: var(--glass);
            border-radius: 30px;
            padding: 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            backdrop-filter: blur(15px);
            display: flex;
            flex-direction: column;
        }

        #cal-card { flex: 1.4; }
        #event-card { flex: 1; }

        /* Kalendar: Saiz Dinamik */
        .cal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .cal-header h2 { color: var(--primary-blue); margin: 0; font-size: 2rem; }

        table { width: 100%; height: 80%; border-collapse: collapse; }
        th { color: var(--primary-blue); padding: 10px; font-size: 1.1rem; }
        td { 
            text-align: center; 
            font-size: 1.2rem; 
            cursor: pointer; 
            position: relative; 
            height: 50px; /* Saiz kotak tarikh tetap */
        }

        /* Indikator Menonjol (Glow Effect) */
        .has-event { font-weight: 800; color: var(--primary-blue); }
        .has-event::after {
            content: "";
            position: absolute;
            bottom: 8px;
            left: 50%;
            transform: translateX(-50%);
            width: 10px; height: 10px;
            background: var(--event-glow);
            border-radius: 50%;
            box-shadow: 0 0 12px var(--event-glow), 0 0 5px #fff;
        }

        .today { background: var(--primary-blue); color: white !important; border-radius: 15px; }

        /* Senarai Aktiviti dengan Skrol Dalaman Sahaja */
        .event-list {
            overflow-y: auto; /* Hanya kawasan ini boleh skrol jika terlalu banyak */
            padding-right: 10px;
        }

        .item-card {
            background: white;
            padding: 20px;
            border-radius: 18px;
            margin-bottom: 15px;
            border-left: 8px solid var(--primary-blue);
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
        }

        /* Modal Pop-out */
        .modal {
            display: none; position: fixed; z-index: 1000; left: 0; top: 0;
            width: 100%; height: 100%; background: rgba(0,0,0,0.6);
            backdrop-filter: blur(8px); align-items: center; justify-content: center;
        }
        .modal-content {
            background: white; padding: 40px; border-radius: 25px;
            width: 400px; position: relative;
            animation: pop 0.3s cubic-bezier(0.68, -0.55, 0.27, 1.55);
        }
        @keyframes pop { from { transform: scale(0.8); opacity: 0; } to { transform: scale(1); opacity: 1; } }
    </style>
</head>
<body>

<div id="eventModal" class="modal">
    <div class="modal-content">
        <span onclick="closeModal()" style="position:absolute; right:20px; top:15px; cursor:pointer; font-size:2rem;">&times;</span>
        <h2 id="m-title" style="color:var(--primary-blue); border-bottom:2px solid #eee; padding-bottom:10px;"></h2>
        <div id="m-body" style="font-size:1.1rem; line-height:1.8;"></div>
    </div>
</div>

<div class="wrapper">
    <header>
        <div class="title-area">
            <h1>Hello Penduduk 👋</h1>
            <p style="margin:0; font-weight:500; color:#555;">Apa aktiviti kita hari ini?</p>
        </div>
        <div class="auth-group">
            <a href="2.0_login.php" class="btn-auth"><i class='bx bx-log-in-circle'></i> Jawatan Kampung</a>
            <a href="2.6_login_guest.php" class="btn-auth"><i class='bx bx-user'></i> Tetamu</a>
        </div>
    </header>

    <main>
        <section id="cal-card" class="card">
            <div class="cal-header">
                <button class="btn-auth" style="padding:5px 15px;" onclick="changeMonth(-1)"><i class='bx bx-chevron-left'></i></button>
                <h2 id="monthDisplay"></h2>
                <button class="btn-auth" style="padding:5px 15px;" onclick="changeMonth(1)"><i class='bx bx-chevron-right'></i></button>
            </div>
            <div id="residentCalendar" style="flex:1;"></div>
        </section>

        <section id="event-card" class="card">
            <h2 style="color:var(--primary-blue); margin-top:0;"><i class='bx bx-calendar-star'></i> Akan Datang</h2>
            <div class="event-list">
                <?php foreach($events as $e): ?>
                    <div class="item-card">
                        <div style="color:var(--primary-blue); font-weight:bold;"><?= date('d M Y', strtotime($e['prog_date'])) ?></div>
                        <div style="font-size:1.2rem; font-weight:bold;"><?= htmlspecialchars($e['prog_name']) ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </main>
</div>

<script>
    let curDate = new Date();
    const eventData = <?= $eventsJson ?>;

    function renderCal(y, m) {
        const calDiv = document.getElementById('residentCalendar');
        const mDisplay = document.getElementById('monthDisplay');
        const names = ["Januari", "Februari", "Mac", "April", "Mei", "Jun", "Julai", "Ogos", "September", "Oktober", "November", "Disember"];
        
        mDisplay.innerText = `${names[m]} ${y}`;
        const first = new Date(y, m, 1).getDay();
        const days = new Date(y, m + 1, 0).getDate();
        
        let h = '<table><tr><th>Ahd</th><th>Isn</th><th>Sel</th><th>Rab</th><th>Kha</th><th>Jum</th><th>Sab</th></tr><tr>';
        for(let i=0; i<first; i++) h += '<td></td>';
        for(let d=1; d<=days; d++){
            const dStr = `${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
            const hasEv = eventData.some(e => e.prog_date === dStr);
            const isToday = (d === new Date().getDate() && m === new Date().getMonth() && y === new Date().getFullYear());
            
            h += `<td class="${hasEv?'has-event':''} ${isToday?'today':''}" onclick="showEv('${dStr}')">${d}</td>`;
            if((first+d)%7 === 0) h += '</tr><tr>';
        }
        calDiv.innerHTML = h + '</tr></table>';
    }

    function showEv(dStr) {
        const evs = eventData.filter(e => e.prog_date === dStr);
        if(!evs.length) return;
        
        document.getElementById('m-title').innerText = "Butiran Aktiviti";
        let b = "";
        evs.forEach(e => {
            b += `<strong>${e.prog_name}</strong><br>
                  <i class='bx bx-time'></i> ${e.prog_time}<br>
                  <i class='bx bx-map'></i> ${e.prog_venue}<br>
                  <i class='bx bx-tag'></i> ${e.prog_category}<hr>`;
        });
        document.getElementById('m-body').innerHTML = b;
        document.getElementById('eventModal').style.display = 'flex';
    }

    function closeModal() { document.getElementById('eventModal').style.display = 'none'; }
    function changeMonth(dir) { curDate.setMonth(curDate.getMonth() + dir); renderCal(curDate.getFullYear(), curDate.getMonth()); }
    
    renderCal(curDate.getFullYear(), curDate.getMonth());
</script>
</body>
</html>