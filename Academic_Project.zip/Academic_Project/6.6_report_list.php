<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include '0.1_dbconnect.php';

// SQL untuk senarai laporan
$sql = "
SELECT r.report_id, p.prog_name, r.prog_rep_submitted, r.prog_rep_status
FROM programme_report r
JOIN programme_proposal p ON r.proposal_id = p.proposal_id
ORDER BY r.report_id DESC
";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Senarai Laporan Program</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
            --sidebar-width: 260px;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body { 
            font-family: 'Segoe UI', Arial, sans-serif; 
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            min-height: 100vh;
        }

        /* --- LOGIK PELARASAN AUTOMATIK (AUTOCORRECT) --- */
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 40px;
            padding-top: 100px;
            transition: all 0.3s ease-in-out;
            min-height: 100vh;
        }
        
        /* Jika navbar mempunyai class 'close' atau 'collapsed' */
        #sidebar.close ~ .main-content,
        #mySidebar.collapsed ~ .main-content { 
            margin-left: 0; 
        }

        /* Menghilangkan margin jika navbar disembunyikan */
        body.sidebar-closed .main-content {
            margin-left: 0;
        }

        /* Glass Container - Design yang sama dengan fail kelulusan */
        .container {
            width: 100%;
            max-width: 1200px;
            margin: auto;
            background: var(--glass-bg);
            padding: 30px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid var(--border-color);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        h2 { color: var(--primary-blue); margin-bottom: 25px; font-size: 1.8rem; display: flex; align-items: center; gap: 12px; }

        /* Table Styling - Sama seperti yang anda mahukan */
        .table-responsive { overflow-x: auto; border-radius: 12px; }
        table { width: 100%; border-collapse: collapse; background: transparent; }
        th { 
            background: rgba(0, 97, 242, 0.05); 
            color: var(--primary-blue); 
            padding: 15px; 
            text-align: center; 
            font-size: 14px;
            border-bottom: 2px solid #e2e8f0;
        }
        td { padding: 15px; border-bottom: 1px solid #f1f5f9; font-size: 14px; vertical-align: top; text-align: center; }
        tr:hover { background: rgba(0, 97, 242, 0.02); }

        .pending { font-weight: bold; color: #f59e0b; }
        .approved { font-weight: bold; color: #10b981; }

        .view { 
            color: var(--primary-blue); 
            font-weight: bold; 
            text-decoration: none; 
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .view:hover { text-decoration: underline; }

        @media (max-width: 768px) {
            .main-content { margin-left: 0; padding: 20px; padding-top: 80px; }
        }
    </style>
</head>

<body id="body-layout">

<?php include '0.2_ketua_navbar.php'; ?>

<div class="main-content">
    <div class="container">
        <h2><i class='bx bx-list-ul'></i> Senarai Laporan Program</h2>

        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Nama Program</th>
                        <th>Tarikh Hantar</th>
                        <th>Status</th>
                        <th>Tindakan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0) { ?>
                        <?php while ($row = $result->fetch_assoc()) { ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($row['prog_name']); ?></strong></td>
                                <td><?= htmlspecialchars($row['prog_rep_submitted']); ?></td>
                                <td class="<?= strtolower($row['prog_rep_status']); ?>">
                                    <span style="display: flex; align-items: center; justify-content: center; gap: 5px;">
                                        <i class='bx bx-info-circle'></i> <?= htmlspecialchars($row['prog_rep_status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <a class="view" href="6.5_report_detail.php?id=<?= $row['report_id']; ?>">
                                        <i class='bx bx-file-find'></i> Lihat Butiran
                                    </a>
                                </td>
                            </tr>
                        <?php } ?>
                    <?php } else { ?>
                        <tr>
                            <td colspan="4" style="padding: 50px; color: #64748b;">
                                Tiada rekod laporan ditemui.
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const toggleBtn = document.querySelector('.header_toggle') || document.getElementById('header-toggle');
        const body = document.getElementById('body-layout');

        if(toggleBtn) {
            toggleBtn.addEventListener('click', () => {
                body.classList.toggle('sidebar-closed');
            });
        }
    });
</script>

</body>
</html>