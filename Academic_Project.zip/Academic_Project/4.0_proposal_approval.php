<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
include '0.1_dbconnect.php';

// 1. Tangkap ID dan Source dari URL (Jika datang dari butang Dashboard)
$filter_id = isset($_GET['id']) ? mysqli_real_escape_string($conn, $_GET['id']) : '';
$source = isset($_GET['source']) ? mysqli_real_escape_string($conn, $_GET['source']) : 'AJK';

/* ================= 2. LOGIK QUERY DINAMIK ================= */
if (!empty($filter_id)) {
    // Jika klik "Semak Sekarang" untuk AJK
    if ($source == 'AJK') {
        $sql = "SELECT proposal_id, prog_name, prog_date FROM programme_proposal 
                WHERE proposal_id = '$filter_id'";
    } 
    // Jika klik "Semak Sekarang" untuk Tetamu
    else {
        $sql = "SELECT request_id AS proposal_id, req_name AS prog_name, req_date AS prog_date 
                FROM guest_requests WHERE request_id = '$filter_id'";
    }
} else {
    // Paparan asal: Semua yang Pending dari AJK
    $sql = "SELECT proposal_id, prog_name, prog_date FROM programme_proposal 
            WHERE prog_status = 'Pending' ORDER BY proposal_id DESC";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelulusan Permohonan Program</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --border-color: rgba(255, 255, 255, 0.5);
            --text-dark: #1a2a3a;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { 
            font-family: 'Segoe UI', Arial, sans-serif; 
            background-image: url('uploads/Bg/Background.jpg'); 
            background-size: cover; background-position: center; background-attachment: fixed;
            min-height: 100vh;
        }

        .main-content { margin-left: 260px; padding: 40px; padding-top: 100px; transition: all 0.3s ease; }
        #mySidebar.collapsed ~ .main-content { margin-left: 80px; }

        .container { 
            width: 100%; max-width: 1200px; margin: auto; background: var(--glass-bg); 
            padding: 30px; border-radius: 15px; backdrop-filter: blur(15px);
            border: 1px solid var(--border-color); box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .header-flex { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
        h2 { color: var(--primary-blue); font-size: 1.8rem; }

        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: separate; border-spacing: 0; background: #fff; border-radius: 10px; overflow: hidden; border: 1px solid #eee; }
        th { background: #f8f9fa; color: #333; padding: 15px; border-bottom: 2px solid #eee; font-weight: 600; text-align: center; }
        td { padding: 20px 15px; border-bottom: 1px solid #eee; vertical-align: top; text-align: center; }

        select, textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 8px; font-size: 14px; margin-bottom: 10px; }
        textarea { resize: vertical; min-height: 80px; }
        .pending { font-weight: bold; color: #f59e0b; text-transform: uppercase; font-size: 0.85rem; }

        .btn {
            padding: 10px 20px; border-radius: 8px; text-decoration: none; color: #fff;
            font-size: 14px; font-weight: 600; border: none; cursor: pointer; transition: 0.3s;
            display: inline-flex; align-items: center; gap: 8px;
        }
        .submit { background: var(--primary-blue); width: 100%; justify-content: center; }
        .view { color: var(--primary-blue); font-weight: bold; text-decoration: none; display: flex; align-items: center; gap: 5px; justify-content: center; margin-bottom: 10px;}
        .reset-btn { background: #64748b; margin-bottom: 20px; }

        .file-input-wrapper { text-align: left; margin-bottom: 15px; }
        .file-input-wrapper label { display: block; font-size: 12px; font-weight: 600; color: #666; margin-bottom: 5px; }
    </style>
</head>

<body>
    <?php include '0.2_ketua_navbar.php'; ?>

    <div class="main-content">
        <div class="container">
            <div class="header-flex">
                <h2>Kelulusan Permohonan <?php echo (!empty($filter_id)) ? "(Rekod #$filter_id)" : ""; ?></h2>
                <?php if (!empty($filter_id)): ?>
                    <a href="4.0_proposal_approval.php" class="btn reset-btn"><i class='bx bx-undo'></i> Lihat Semua</a>
                <?php endif; ?>
            </div>

            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th width="20%">Nama Program</th>
                            <th width="15%">Tarikh</th>
                            <th width="10%">Status</th>
                            <th width="40%">Tindakan & Komen</th>
                            <th width="15%">Lihat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && $result->num_rows > 0) { ?>
                            <?php while ($row = $result->fetch_assoc()) { ?>
                                <tr>
                                    <td>
                                        <strong><?= htmlspecialchars($row['prog_name']); ?></strong><br>
                                        <small style="color:#888;">Sumber: <?= $source; ?></small>
                                    </td>
                                    <td><?= date("d/m/Y", strtotime($row['prog_date'])); ?></td>
                                    <td class="pending">Pending</td>
                                    <td>
                                        <form action="4.1_proposal_approval_save.php" method="POST" enctype="multipart/form-data">
                                            <input type="hidden" name="proposal_id" value="<?= $row['proposal_id']; ?>">
                                            <input type="hidden" name="source" value="<?= $source; ?>">

                                            <select name="status" required>
                                                <option value="">-- Pilih Keputusan --</option>
                                                <option value="Approved">Terima (Approve)</option>
                                                <option value="Returned">Dikembalikan (Update Required)</option>
                                                <option value="Rejected">Ditolak (Reject)</option>
                                            </select>

                                            <textarea name="comments" required placeholder="Sila berikan ulasan atau teguran di sini..."></textarea>

                                            <div class="file-input-wrapper">
                                                <label><i class='bx bx-upload'></i> Dokumen Tambahan (Opsional)</label>
                                                <input type="file" name="approval_document" accept=".pdf,.doc,.docx,.jpg,.png">
                                            </div>

                                            <button type="submit" class="btn submit">
                                                <i class='bx bx-send'></i> Hantar Keputusan
                                            </button>
                                        </form>
                                    </td>
                                    <td>
                                        <a class="view" href="3.2_proposal_detail.php?id=<?= $row['proposal_id']; ?>&source=<?= $source; ?>">
                                            <i class='bx bx-file-find'></i> Lihat Kertas Kerja
                                        </a>
                                    </td>
                                </tr>
                            <?php } ?>
                        <?php } else { ?>
                            <tr>
                                <td colspan="5" style="padding: 40px; color: #666;">Tiada kertas kerja yang menunggu kelulusan buat masa ini.</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>