<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '0.1_dbconnect.php';

// Semakan akses: Pastikan pengguna sudah log masuk
if (!isset($_SESSION['com_id'])) {
    header("Location: 2.0_login.php");
    exit();
}

if (!isset($_GET['proposal_id'])) {
    die("Akses tidak sah.");
}

$proposal_id = intval($_GET['proposal_id']);

/* Ambil butiran program dari jadual programme_proposal */
$sql = "SELECT prog_name FROM programme_proposal WHERE proposal_id = '$proposal_id'";
$result = $conn->query($sql);

if (!$result || $result->num_rows == 0) {
    die("Program tidak dijumpai.");
}

$programme = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Program | <?= htmlspecialchars($programme['prog_name']); ?></title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.95);
            --text-dark: #1a2a3a;
        }

        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: url('uploads/Bg/Background.jpg') no-repeat center fixed;
            background-size: cover;
            margin: 0;
        }

        .main-content {
            margin-left: 260px; /* Lebar sidebar anda */
            padding: 40px;
            padding-top: 100px;
            transition: all 0.3s ease;
            display: flex;
            justify-content: center;
        }

        .container {
            background: var(--glass-bg);
            padding: 40px;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 800px;
        }

        h2 {
            color: var(--primary-blue);
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.8rem;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--text-dark);
            font-size: 0.9rem;
        }

        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #d1d5db;
            border-radius: 10px;
            font-size: 1rem;
            background: rgba(255, 255, 255, 0.8);
            transition: all 0.3s ease;
            box-sizing: border-box;
        }

        .form-group textarea {
            height: 120px;
            resize: vertical;
        }

        .form-group input:focus, .form-group textarea:focus {
            border-color: var(--primary-blue);
            outline: none;
            box-shadow: 0 0 0 3px rgba(0, 97, 242, 0.1);
        }

        .form-group input[readonly] {
            background-color: #f3f4f6;
            cursor: not-allowed;
        }

        .btn-submit {
            background: var(--primary-blue);
            color: white;
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }

        .btn-submit:hover {
            background: #004dc2;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 97, 242, 0.3);
        }

        @media (max-width: 768px) {
            .main-content { margin-left: 0; padding: 20px; padding-top: 80px; }
        }
    </style>
</head>
<body>

<?php 
/* LOGIK NAVIBAR DINAMIK */
if (isset($_SESSION['com_role'])) {
    if ($_SESSION['com_role'] === 'Village Head') {
        include '0.2_ketua_navbar.php';
    } else {
        include '0.3_committee_navbar.php';
    }
}
?>

<div class="main-content">
    <div class="container">
        <h2><i class='bx bx-file-blank'></i> Penyediaan Laporan Program</h2>
        
        <form action="6.1_programme_report_save.php" method="POST" enctype="multipart/form-data">
            
            <input type="hidden" name="proposal_id" value="<?= $proposal_id; ?>">

            <div class="form-group">
                <label>Nama Program</label>
                <input type="text" name="prog_name" value="<?= htmlspecialchars($programme['prog_name']); ?>" readonly>
            </div>

            <div class="form-group">
                <label>Ringkasan Program (Summary)</label>
                <textarea name="prog_summary" required placeholder="Ceritakan perjalanan program secara ringkas..."></textarea>
            </div>

            <div class="form-group">
                <label>Cadangan Penambahbaikan</label>
                <textarea name="prog_improvement" placeholder="Apa yang boleh diperbaiki untuk masa depan?"></textarea>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label>Bilangan Peserta Sebenar</label>
                    <input type="number" name="prog_act_participants" required placeholder="Contoh: 50">
                </div>
                
                <div class="form-group">
                    <label>Dokumen/Gambar Laporan</label>
                    <input type="file" name="prog_rep_docs" style="padding-top: 8px;">
                </div>
            </div>

            <button type="submit" class="btn-submit">
                <i class='bx bx-save'></i> Seterusnya
            </button>

            <a href="5.0_programme_list.php" style="display: block; text-align: center; margin-top: 20px; color: #666; text-decoration: none; font-size: 0.9rem;">
                <i class='bx bx-chevron-left'></i> Batal dan Kembali
            </a>

        </form>
    </div>
</div>

</body>
</html>