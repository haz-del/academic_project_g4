<?php 
session_start();
include '0.1_dbconnect.php';

$user_role = $_SESSION['com_role'] ?? ''; 
ini_set('display_errors', 1);
error_reporting(E_ALL);

/* ================= 1. FILTER LOGIC ================= */
$com_filter = $_GET['com_id'] ?? 'all';
$pos_filter = $_GET['com_position'] ?? 'all';

// Build dynamic WHERE clause to handle filtering correctly
$conditions = ["c.com_id != 1"]; // Always ignore Admin/Superuser

if ($com_filter !== 'all') {
    $conditions[] = "c.com_id = '" . mysqli_real_escape_string($conn, $com_filter) . "'";
}
if ($pos_filter !== 'all') {
    $conditions[] = "c.com_position = '" . mysqli_real_escape_string($conn, $pos_filter) . "'";
}

$where_clause = "WHERE " . implode(" AND ", $conditions);

/* ================= 2. KPI CARDS ================= */
// Total registered AJK (Overall)
$total_ajk_res = mysqli_query($conn, "SELECT COUNT(*) as total FROM committee WHERE com_id != 1");
$total_ajk = mysqli_fetch_assoc($total_ajk_res)['total'];

// Count based on active search filter
$pos_count_query = mysqli_query($conn, "SELECT COUNT(*) as total FROM committee c $where_clause");
$total_filtered = mysqli_fetch_assoc($pos_count_query)['total'];

/* ================= 3 & 4. CHART DATA (COMBINED) ================= */
$ajk_names = [];
$prog_counts = [];
$fin_income = [];
$fin_expense = [];

// Unified query to ensure all chart arrays match indices perfectly
$q_data = mysqli_query($conn, "
    SELECT 
        c.com_name, 
        COUNT(pr.report_id) as total_act,
        SUM(pr.prog_act_income) as total_in,
        SUM(pr.prog_act_expenses) as total_out
    FROM committee c
    LEFT JOIN programme_report pr ON c.com_id = pr.com_id
    $where_clause
    GROUP BY c.com_id, c.com_name
    ORDER BY total_act DESC
");

while($r = mysqli_fetch_assoc($q_data)) {
    $ajk_names[] = $r['com_name'];
    $prog_counts[] = (int)$r['total_act'];
    $fin_income[] = (float)($r['total_in'] ?? 0);
    $fin_expense[] = (float)($r['total_out'] ?? 0);
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analisis Prestasi AJK</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root { 
            --primary: #0061f2; 
            --secondary: #6900f2;
            --slate-600: #475569;
            --slate-500: #64748b;
        }

        body { 
            font-family: 'Inter', 'Segoe UI', sans-serif; 
            background: #f8fafc; 
            margin: 0; 
        }
        
        .main-content { 
            margin-left: 260px; 
            padding: 100px 30px 30px 30px; 
            transition: all 0.3s ease; 
        }

        .glass-card { 
            background: white; 
            padding: 30px; 
            border-radius: 20px; 
            box-shadow: 0 10px 25px rgba(0,0,0,0.05); 
            border: 1px solid #e2e8f0;
        }

        h2 { 
            color: #1e293b; 
            font-size: 1.5rem; 
            display: flex; 
            align-items: center; 
            gap: 10px;
            margin-bottom: 25px;
        }

        .filter-section { 
            display: flex; 
            gap: 12px; 
            margin-bottom: 30px; 
            flex-wrap: wrap; 
            background: #f1f5f9;
            padding: 20px;
            border-radius: 12px;
        }

        .filter-section select {
            padding: 10px 15px;
            border-radius: 8px;
            border: 1px solid #cbd5e1;
            background: white;
            min-width: 200px;
            outline: none;
        }

        .btn-tapis { 
            background: var(--primary); 
            color: white; 
            border: none; 
            cursor: pointer; 
            padding: 10px 25px; 
            border-radius: 8px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.3s;
        }

        .btn-tapis:hover { background: #004dc2; }

        .btn-reset {
            background: var(--slate-500);
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.3s;
        }

        .btn-reset:hover { background: var(--slate-600); }

        .stats-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); 
            gap: 20px; 
            margin-bottom: 35px; 
        }

        .stat-card { 
            background: white; 
            padding: 25px; 
            border-radius: 15px; 
            border-left: 6px solid var(--primary); 
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
        }

        .stat-label { font-size: 0.85rem; color: var(--slate-500); font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
        .stat-value { font-size: 2.2rem; font-weight: 800; color: #0f172a; margin-top: 5px; }

        .chart-wrapper {
            display: grid;
            grid-template-columns: 1fr;
            gap: 30px;
        }

        .chart-container { 
            background: white; 
            padding: 25px; 
            border-radius: 15px; 
            border: 1px solid #e2e8f0;
            height: 450px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.02);
        }

        @media (max-width: 768px) {
            .main-content { margin-left: 0; padding-top: 80px; }
            .filter-section { flex-direction: column; align-items: stretch; }
            .filter-section select { width: 100%; }
        }
    </style>
</head>
<body>

<?php 
if ($user_role === 'Village Head') { include '0.2_ketua_navbar.php'; } 
else { include '0.3_committee_navbar.php'; } 
?>

<div class="main-content">
    <div class="glass-card">
        <h2><i class='bx bx-bar-chart-alt-2'></i> Analisis Prestasi & Aktiviti AJK</h2>

        <form method="GET" action="12.1_analisis_ajk.php" class="filter-section">
            <select name="com_id">
                <option value="all">Semua Nama AJK</option>
                <?php 
                $ajks = mysqli_query($conn, "SELECT com_id, com_name FROM committee WHERE com_id != 1");
                while($a = mysqli_fetch_assoc($ajks)) {
                    $sel = ($com_filter == $a['com_id']) ? 'selected' : '';
                    echo "<option value='{$a['com_id']}' $sel>{$a['com_name']}</option>";
                }
                ?>
            </select>

            <select name="com_position">
                <option value="all">Semua Posisi</option>
                <?php 
                $pos = mysqli_query($conn, "SELECT DISTINCT com_position FROM committee WHERE com_id != 1");
                while($p = mysqli_fetch_assoc($pos)) {
                    $sel = ($pos_filter == $p['com_position']) ? 'selected' : '';
                    echo "<option value='{$p['com_position']}' $sel>{$p['com_position']}</option>";
                }
                ?>
            </select>

            <button type="submit" class="btn-tapis">
                <i class='bx bx-filter-alt'></i> Tapis
            </button>

            <a href="12.1_analisis_ajk.php" class="btn-reset">
                <i class='bx bx-refresh'></i> Reset
            </a>
        </form>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label">Jumlah Keseluruhan AJK</div>
                <div class="stat-value"><?= $total_ajk ?></div>
            </div>
            <div class="stat-card" style="border-left-color: var(--secondary);">
                <div class="stat-label">Hasil Carian (AJK Terlibat)</div>
                <div class="stat-value"><?= $total_filtered ?></div>
            </div>
        </div>

        <?php if (empty($ajk_names)): ?>
            <div style="text-align: center; padding: 50px; color: var(--slate-500);">
                <i class='bx bx-info-circle' style="font-size: 3rem;"></i>
                <p>Tiada data dijumpai untuk filter ini.</p>
            </div>
        <?php else: ?>
            <div class="chart-wrapper">
                <div class="chart-container">
                    <canvas id="activityChart"></canvas>
                </div>

                <div class="chart-container">
                    <canvas id="financeChart"></canvas>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
Chart.defaults.font.family = "'Inter', sans-serif";
Chart.defaults.color = '#64748b';

// --- CHART 1: ACTIVITY BAR CHART ---
const ctx1 = document.getElementById('activityChart')?.getContext('2d');
if(ctx1) {
    new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: <?= json_encode($ajk_names) ?>,
            datasets: [{
                label: 'Bilangan Program',
                data: <?= json_encode($prog_counts) ?>,
                backgroundColor: 'rgba(0, 97, 242, 0.8)',
                borderRadius: 6,
                barThickness: 30
            }]
        },
        options: {
            maintainAspectRatio: false,
            plugins: { 
                title: { 
                    display: true, 
                    text: 'Bilangan Program Mengikut AJK', 
                    color: '#1e293b',
                    font: { size: 16, weight: 'bold' }
                },
                legend: { display: false }
            },
            scales: { 
                y: { beginAtZero: true, ticks: { stepSize: 1 } }
            }
        }
    });
}

// --- CHART 2: FINANCE BAR CHART ---
const ctx2 = document.getElementById('financeChart')?.getContext('2d');
if(ctx2) {
    new Chart(ctx2, {
        type: 'bar',
        data: {
            labels: <?= json_encode($ajk_names) ?>,
            datasets: [
                {
                    label: 'Pendapatan (RM)',
                    data: <?= json_encode($fin_income) ?>,
                    backgroundColor: '#10b981',
                    borderRadius: 4
                },
                {
                    label: 'Perbelanjaan (RM)',
                    data: <?= json_encode($fin_expense) ?>,
                    backgroundColor: '#ef4444',
                    borderRadius: 4
                }
            ]
        },
        options: {
            maintainAspectRatio: false,
            plugins: { 
                title: { 
                    display: true, 
                    text: 'Analisis Kewangan Program Per AJK', 
                    color: '#1e293b',
                    font: { size: 16, weight: 'bold' }
                },
                legend: { position: 'bottom' }
            },
            scales: { y: { beginAtZero: true } }
        }
    });
}
</script>

</body>
</html>