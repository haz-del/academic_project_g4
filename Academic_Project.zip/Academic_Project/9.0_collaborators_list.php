<?php
session_start();
include '0.1_dbconnect.php';

// Semakan akses (Hanya untuk yang sudah login)
if (!isset($_SESSION['com_id'])) {
    header("Location: 2.0_login.php");
    exit();
}

$sql = "SELECT * FROM collaborators ORDER BY coll_date_created DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Senarai Kolaborator</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-blue: #0061f2;
            --glass-bg: rgba(255, 255, 255, 0.9);
            --text-dark: #1a2a3a;
        }

        body { 
            font-family: 'Segoe UI', sans-serif; 
            background: url('uploads/Bg/Background.jpg') no-repeat center fixed; 
            background-size: cover;
            margin: 0;
        }

        .main-content { margin-left: 260px; padding: 40px; padding-top: 100px; transition: 0.3s; }
        
        .container { 
            background: var(--glass-bg); 
            padding: 30px; 
            border-radius: 20px; 
            backdrop-filter: blur(15px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        h2 { color: var(--primary-blue); margin-bottom: 25px; display: flex; align-items: center; gap: 10px; }

        .table-responsive { overflow-x: auto; border-radius: 12px; }
        table { width: 100%; border-collapse: collapse; }
        th { background: rgba(0, 97, 242, 0.1); padding: 15px; text-align: left; font-size: 14px; border-bottom: 2px solid #ddd; }
        td { padding: 15px; border-bottom: 1px solid #eee; font-size: 13.5px; vertical-align: middle; }
        tr:hover { background: rgba(0, 97, 242, 0.03); }

        .btn-profile { 
            color: var(--primary-blue); 
            text-decoration: none; 
            font-weight: 600; 
            display: flex; 
            align-items: center; 
            gap: 5px; 
        }
        .btn-profile:hover { text-decoration: underline; }

        .badge { padding: 5px 10px; background: #e2e8f0; border-radius: 6px; font-size: 12px; font-weight: 600; }

        @media (max-width: 768px) { .main-content { margin-left: 0; } }
    </style>
</head>
<body>

<?php 
// Panggil navbar mengikut role
if ($_SESSION['com_role'] === 'Village Head') { include '0.2_ketua_navbar.php'; } 
else { include '0.3_committee_navbar.php'; } 
?>

<div class="main-content">
    <div class="container">
        <h2><i class='bx bx-group'></i> Senarai Kolaborator</h2>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Organisasi</th>
                        <th>Jenis</th>
                        <th>Pegawai Penyelaras</th>
                        <th>Telefon</th>
                        <th>Emel</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>$no</td>";
                        echo "<td><a href='2.4_collaborators_profil.php?id=" . $row['coll_id'] . "' class='btn-profile'><i class='bx bx-building-house'></i> " . htmlspecialchars($row['coll_organisation_name']) . "</a></td>";
                        echo "<td><span class='badge'>" . htmlspecialchars($row['coll_organisation_type']) . "</span></td>";
                        echo "<td>" . htmlspecialchars($row['coll_contact_person']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['coll_phone']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['coll_email']) . "</td>";
                        echo "</tr>";
                        $no++;
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>